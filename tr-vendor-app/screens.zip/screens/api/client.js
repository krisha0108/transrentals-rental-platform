// src/api/client.js
import axios from "axios";
import { Platform } from "react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";

/**
 * Decide base URL dynamically:
 * - Uses override saved in AsyncStorage (so you can change in-app later)
 * - Falls back to ENV or default prod
 * - Handles Android emulator localhost mapping if needed
 */
const DEFAULT_PROD = "https://app.transrentals.in/api";

function inferLocalBase() {
  // Adjust if you run a device on same LAN — put your machine IP
  // For Android emulator, localhost is 10.0.2.2
  return Platform.OS === "android" ? "http://10.0.2.2:8000/api" : "http://localhost:8000/api";
}

let cachedBaseURL = null;
export async function getBaseURL() {
  if (cachedBaseURL) return cachedBaseURL;

  // 1) App-level override (changeable at runtime)
  const saved = await AsyncStorage.getItem("api_base_url");
  if (saved) {
    cachedBaseURL = saved;
    return cachedBaseURL;
  }

  // 2) ENV (optional)
  const ENV_URL = process.env.API_BASE_URL; // if you inject envs
  if (ENV_URL) {
    cachedBaseURL = ENV_URL.endsWith("/api") ? ENV_URL : `${ENV_URL}/api`;
    return cachedBaseURL;
  }

  // 3) default
  cachedBaseURL = DEFAULT_PROD;

  // If you’re on dev, uncomment to auto-use local:
  // cachedBaseURL = __DEV__ ? inferLocalBase() : DEFAULT_PROD;

  return cachedBaseURL;
}

export async function setBaseURL(newUrl) {
  cachedBaseURL = newUrl;
  await AsyncStorage.setItem("api_base_url", newUrl);
}

// Axios instance builder (rebuilds when baseURL changes)
async function createInstance() {
  const baseURL = await getBaseURL();
  const instance = axios.create({ baseURL, timeout: 20000 });

  // Attach vendor token automatically if present
  instance.interceptors.request.use(async (config) => {
    const token = await AsyncStorage.getItem("vendor_token");
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  });

  return instance;
}

// Simple wrappers
export async function apiGet(path, config = {}) {
  const api = await createInstance();
  return api.get(path, config);
}

export async function apiPost(path, data, config = {}) {
  const api = await createInstance();
  return api.post(path, data, config);
}

export async function apiPut(path, data, config = {}) {
  const api = await createInstance();
  return api.put(path, data, config);
}

export async function apiDelete(path, config = {}) {
  const api = await createInstance();
  return api.delete(path, config);
}

/** Example specific call (you can add all endpoints here) */
export async function fetchQuotation(bookingId) {
  // matches your old: GET /quotation/{bookingId}
  const res = await apiGet(`/quotation/${bookingId}`);
  return res.data;
}
