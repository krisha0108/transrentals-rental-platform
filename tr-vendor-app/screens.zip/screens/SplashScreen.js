import React, { useEffect, useRef, useState } from 'react';
import { View, Image, Animated, StyleSheet, Dimensions } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useNavigation } from '@react-navigation/native';

const SplashScreen = () => {
  const fadeAnim1 = useRef(new Animated.Value(0)).current;
  const fadeAnim2 = useRef(new Animated.Value(0)).current;
  const [showSecondLogo, setShowSecondLogo] = useState(false);
  const navigation = useNavigation();

  useEffect(() => {
    // First logo fade in
    Animated.timing(fadeAnim1, {
      toValue: 1,
      duration: 1000,
      useNativeDriver: true,
    }).start(() => {
      // Then fade out
      Animated.timing(fadeAnim1, {
        toValue: 0,
        duration: 1000,
        useNativeDriver: true,
      }).start(() => {
        setShowSecondLogo(true);
        // Second logo fade in
        Animated.timing(fadeAnim2, {
          toValue: 1,
          duration: 1000,
          useNativeDriver: true,
        }).start(() => {
          // Second logo fade out after delay
          setTimeout(() => {
            Animated.timing(fadeAnim2, {
              toValue: 0,
              duration: 1000,
              useNativeDriver: true,
            }).start(async () => {
              // Perform session check here
              try {
                const token = await AsyncStorage.getItem('vendor_token');
                if (token) {
                  navigation.replace('VendorDashboard');
                } else {
                  navigation.replace('Onboarding');
                }
              } catch (e) {
                console.log('Session check failed:', e);
                navigation.replace('Onboarding');
              }
            });
          }, 2000);
        });
      });
    });
  }, []);

  return (
    <View style={styles.container}>
      <Animated.Image
        source={require('../assets/logo_tr_favicon.png')}
        style={[styles.logoFevicon, { opacity: fadeAnim1 }]}
        resizeMode="contain"
      />
      {showSecondLogo && (
        <Animated.Image
          source={require('../assets/mainaLogov.png')}
          style={[styles.logo, { opacity: fadeAnim2, position: 'absolute' }]}
          resizeMode="contain"
        />
      )}
    </View>
  );
};

const { width, height } = Dimensions.get('window');

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
  },
  logoFevicon: {
    width: '40%',
  },
  logo: {
    width: '80%',
    
  },
});

export default SplashScreen;
