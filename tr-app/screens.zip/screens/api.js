// api.js
import axios from "axios";

const dev = false; // set to false for production

const API_BASE_URL = dev
  ? 'http://192.168.29.222:8000/api' // Localhost for Android emulator
  : 'http://192.168.29.222:8000/api'; // Live URL

const api = axios.create({
  baseURL: API_BASE_URL,
//   timeout: 10000, // optional timeout
//   headers: {
//     'Content-Type': 'application/json',
//   },
});

export default api;
