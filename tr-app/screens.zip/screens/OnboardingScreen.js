import React, { useState, useRef, useEffect } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  Dimensions,
  Animated,
  Image,
  Alert,
  Platform,
  PermissionsAndroid,
} from 'react-native';
import messaging from '@react-native-firebase/messaging';

const { width } = Dimensions.get('window');

const slides = [
  {
    title: '“All-in-One Rental Platform”',
    description: 'Rent anything — bikes, cars, buses, trucks, and even equipment. Simplify your journey with one powerful app.',
    image: require('../assets/slider1.png'),
  },
  {
    title: '“Tell Us What You Need”',
    description: 'Post your rental requirement and receive competitive quotes from verified vendors.',
    image: require('../assets/slide-2-hero.png'),
  },
  {
    title: '“Compare, Book & Relax”',
    description: 'Review Quotes, Pick The Best One, And We’ll Handle The Rest — With 24/7 Support To Guide You.',
    image: require('../assets/slide-3-hero.png'),
  },
  {
    title: '“Earn While You Ride”',
    description: 'Every Confirmed Booking Earns You BACKR Tokens. Use Them For Discounts, Staking, And More Across Our Ecosystem.',
    image: require('../assets/slide-4-hero.png'),
  },
];

export default function OnboardingScreen({ navigation }) {
  const [current, setCurrent] = useState(0);
  const [permissionGranted, setPermissionGranted] = useState(false);
  const fadeAnim = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    fadeAnim.setValue(0);
    Animated.timing(fadeAnim, {
      toValue: 1,
      duration: 500,
      useNativeDriver: true,
    }).start();
  }, [current]);

  useEffect(() => {
    requestNotificationPermission();
  }, []);

  async function requestNotificationPermission() {
    // Android 13+ needs runtime POST_NOTIFICATIONS permission
    if (Platform.OS === 'android' && Platform.Version >= 33) {
      const granted = await PermissionsAndroid.request(
        PermissionsAndroid.PERMISSIONS.POST_NOTIFICATIONS
      );
      if (granted === PermissionsAndroid.RESULTS.GRANTED) {
        setPermissionGranted(true);
      } else {
        setPermissionGranted(false);
        Alert.alert('Notification permission denied', 'You can enable it later in settings.');
      }
      return;
    }

    // For iOS or Android < 13, use messaging().hasPermission + requestPermission (updated approach)
    try {
      const authStatus = await messaging().hasPermission();
      if (authStatus === messaging.AuthorizationStatus.AUTHORIZED ||
          authStatus === messaging.AuthorizationStatus.PROVISIONAL) {
        setPermissionGranted(true);
        return;
      }

      const newAuthStatus = await messaging().requestPermission();
      if (newAuthStatus === messaging.AuthorizationStatus.AUTHORIZED ||
          newAuthStatus === messaging.AuthorizationStatus.PROVISIONAL) {
        setPermissionGranted(true);
      } else {
        setPermissionGranted(false);
        Alert.alert('Notification permission denied', 'You can enable it later in settings.');
      }
    } catch (error) {
      console.log('Error requesting notification permission:', error);
      setPermissionGranted(false);
    }
  }

  const handleNext = () => {
    if (current < slides.length - 1) {
      setCurrent(current + 1);
    } else {
      navigation.replace('Login');
    }
  };

  return (
    <View style={styles.container}>
      <TouchableOpacity style={styles.skipButton} onPress={() => navigation.replace('Login')}>
        <Text style={styles.skipText}>Skip</Text>
      </TouchableOpacity>

      <Animated.View style={[styles.content, { opacity: fadeAnim }]}>
        <View style={styles.logoContainer}>
          <Image source={slides[current].image} style={styles.logoCircle} resizeMode="contain" />
        </View>

        <View style={styles.textWrapper}>
          <Text style={styles.heading}>{slides[current].title}</Text>
          <Text style={styles.paragraph}>{slides[current].description}</Text>
        </View>

        <View style={styles.pagination}>
          {slides.map((_, index) => (
            <View
              key={index}
              style={[styles.dot, current === index && styles.dotActive]}
            />
          ))}
        </View>

        <View style={styles.nextButtonWrapper}>
          <TouchableOpacity style={styles.nextButton} onPress={handleNext}>
            <Text style={styles.nextButtonText}>
              {current === slides.length - 1 ? 'Finish' : 'Next'}
            </Text>
          </TouchableOpacity>
        </View>
      </Animated.View>
    </View>
  );
}


const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: '0',
    display:'flex',
    justifyContent:'center',
    alignItems:'center',
    backgroundColor: '#f9f7f7',
  },
  skipButton: {
    position: 'absolute',
    top: 60,
    right: 20,
    zIndex: 1,
  },
  skipText: {
    fontSize: 22,
    fontWeight: '600',
    color: '#404040',
  },
  content: {
    marginTop: 100,
    paddingTop: 80,
    paddingHorizontal: 40,
    paddingBottom: 30,
  },
  logoContainer: {
height: 150,
    alignItems: 'bottom',
    marginBottom: 45,
  },
  logoCircle: {
    width: '100%',
    // height: 199,
    borderRadius: 12,
  },
  textWrapper: {
    alignItems: 'center',
    marginBottom: 30,
    width: '100%',
     textAlign: 'center',
  },
  heading: {
    width: '80%',
    fontSize: 22,
    fontWeight: 'bold',
    color: '#404040',
    marginTop: 5,
    marginBottom: 5,
    textAlign: 'center',
  },
  paragraph: {
    fontSize: 18,
    color: '#404040',
    textAlign: 'center',
    width: '300',
    lineHeight: 22,
   
  },
  pagination: {
    flexDirection: 'row',
    justifyContent: 'center',
    marginTop: 10,
    gap: 10,
  },
  dot: {
    height: 9,
    width: 9,
    backgroundColor: '#d9d9d9',
    borderRadius: 5,
  },
  dotActive: {
    width: 36,
    backgroundColor: '#09B368',
  },
  nextButtonWrapper: {
    marginTop: 50,
    alignItems: 'flex-end',
  },
  nextButton: {
    backgroundColor: '#09B368',
    paddingVertical: 12,
    paddingHorizontal: 40,
    borderRadius: 8,
  },
  nextButtonText: {
    color: '#fff',
    fontSize: 18,
    fontWeight: '600',
  },
});
