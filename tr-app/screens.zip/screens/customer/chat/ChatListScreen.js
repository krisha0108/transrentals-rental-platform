import React, { useState, useEffect } from 'react';
import {StyleSheet, View, Text, FlatList, TouchableOpacity, TextInput, RefreshControl  } from 'react-native';
import axios from 'axios';
import AsyncStorage from '@react-native-async-storage/async-storage';
import Ionicons from 'react-native-vector-icons/Ionicons';
import ShimmerPlaceholder from 'react-native-shimmer-placeholder';
import { useNavigation } from '@react-navigation/native';
import { SafeAreaView } from 'react-native-safe-area-context';
const ContactList = ({ navigation }) => {
  const [contacts, setContacts] = useState([]);
  const [search, setSearch] = useState('');
  const [refreshing, setRefreshing] = useState(false);
  const [loading, setLoading] = useState(true);  // Track loading state
  
  // Fetch contacts
  const fetchContacts = async () => {
    const token = await AsyncStorage.getItem('token');
    console.log('Token from AsyncStorage:', token);
    const customerId = await AsyncStorage.getItem('customer_id');
  
    if (!token) {
      console.log('No token found. Please log in again.');
      return navigation.replace('Login');
    }
  
    try {
      setLoading(true);  // Set loading to true when fetching data
      const response = await axios.get(`https://app.transrentals.in/api/chats/contact-list`, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
        params: { customer_id: customerId },
      });
  
      // console.log('Contacts from backend:', response.data);  // Log to verify the contact list
// Convert the object to an array
const contactsArray = Object.values(response.data);
// console.log('Converted contacts array:', contactsArray);

setContacts(contactsArray); // Set the contacts as an array
setLoading(false); 

    } catch (error) {
      if (error.response && error.response.status === 401) {
        // console.log('Unauthorized. Token expired or invalid.');
        // Redirect to login screen if the token is invalid
        navigation.replace('LoginScreen');
      } else {
        // console.error('Error fetching contacts:', error);
        setLoading(false);
      }
    }
  };
  const markMessagesAsRead = async (contactId, contactType) => {
  try {
    const token = await AsyncStorage.getItem('token');
    if (!token) {
      console.log('No token found. Please log in again.');
      navigation.replace('Login');
      return;
    }

    await axios.post(
      'https://app.transrentals.in/api/chat/mark-read',
      {
        receiver_id: contactId,
        receiver_type: 'vendor',
      },
      {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      }
    );
    console.log(`Messages from contact ${contactId} marked as read.`);
  } catch (error) {
    console.error('Failed to mark messages as read:', error);
  }
};
// Refresh handler
const onRefresh = () => {
  setRefreshing(true);
  fetchContacts().finally(() => setRefreshing(false));
};

  useEffect(() => {
    // console.log('Contacts:', contacts); // Log contacts array to verify its structure
    fetchContacts();
  }, []);

  const handleChatSelect = async (contactId, contactName, contactType) => {
  // Mark messages as read on server
  await markMessagesAsRead(contactId, contactType);

  // Then navigate to chat screen
  navigation.navigate('ChatDetail', {
    contactId,
    contactName,
    contactType,
  });
};

  
  // Helper function to get the first letter of the contact's name
  const getFirstLetter = (name) => name.charAt(0).toUpperCase();

  return (
    <SafeAreaView>
    <View style={{ flex: 1, backgroundColor: 'white' }}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <Ionicons name="arrow-back" size={24} color="#404040" />
        </TouchableOpacity>
        <Text style={styles.headerText}>Chat</Text>
      </View>

      <TextInput
        style={styles.searchInput}
        placeholder="Search Chats"
        value={search}
        onChangeText={setSearch}
      />

<FlatList
        data={Array.isArray(contacts) ? contacts.filter(contact => contact.name && contact.name.toLowerCase().includes(search.toLowerCase())) : []}
        renderItem={({ item }) => (
          <TouchableOpacity style={styles.contactItem} onPress={() => handleChatSelect(item.id, item.name, item.type)}>
            <View style={styles.profileContainer}>
              {/* Profile Image (First Letter) */}
              <View style={styles.profileImage}>
                <Text style={styles.profileImageText}>{getFirstLetter(item.name)}</Text>
              </View>
            </View>
            <View style={styles.contactInfo}>
              <Text style={styles.contactName}>{item.name}</Text>
              <Text style={styles.lastMessage}>{item.last_message}</Text>
            </View>
            <View style={styles.contactDetails}>
            {item.unread_count > 0 && (
                <View style={styles.unreadCountContainer}>
                  <Text style={styles.unreadCount}>{item.unread_count}</Text>
                </View>
              )}
              <Text style={styles.lastMessageTime}>{new Date(item.last_message_time).toLocaleTimeString()}</Text>
              
            </View>
          </TouchableOpacity>
        )}
        keyExtractor={item => item.id.toString()}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} />}
        ListEmptyComponent={
           // Show skeleton view while loading
           loading ? (
            <View style={styles.skeletonContainer}>
              <ShimmerPlaceholder style={styles.skeletonProfile} />
              <ShimmerPlaceholder style={styles.skeletonText} />
              <ShimmerPlaceholder style={styles.skeletonText} />
            </View>
          ) : null  // If not loading, display the list of contacts
        }
      />
    </View>
        </SafeAreaView>
  );
};


const styles = StyleSheet.create({
  header: {
    height: 60,
    backgroundColor: '#F9F7F7',
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 20,
    elevation: 5,  // Adds shadow to the header
  },
  headerText: {
    color: '#404040',
    fontSize: 20,
    marginLeft: 10,  // Adjust space between back button and title
  },
  searchInput: {
    margin: 10,
    padding: 10,
    borderWidth: 1,
    borderColor: '#ddd',
    borderRadius: 5,
    backgroundColor: '#f5f5f5',  // Light gray background for search
    color: 'black',
  },
  contactItem: {
    flexDirection: 'row',
    padding: 15,
    borderBottomWidth: 1,
    borderBottomColor: '#ddd',
    borderRadius: 8,
    backgroundColor: '#fff',  // Background color for contact items
    marginBottom: 10,
    shadowColor: "#000", // Shadow for contact items
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 3,
    elevation: 3,  // Android shadow
  },
  profileContainer: {
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 15,
  },
  profileImage: {
    width: 40,
    height: 40,
    backgroundColor: '#6B7280',  // Purple color for the profile image circle
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
  },
  profileImageText: {
    color: '#fff',
    fontWeight: 'bold',
  },
  contactInfo: {
    flex: 1,
    justifyContent: 'center',
  },
  contactName: {
    fontSize: 16,
    fontWeight: 'bold',
  },
  lastMessage: {
    fontSize: 14,
    color: '#555',
  },
  contactDetails: {
    alignItems: 'flex-end',
    justifyContent: 'center',
  },
  lastMessageTime: {
    fontSize: 12,
    color: '#999',
  },
  unreadCountContainer: {
    backgroundColor: '#22C55E',
    borderRadius: 10,
    paddingHorizontal: 6,
    paddingVertical: 2,
    marginTop: 5,
  },
  unreadCount: {
    color: 'white',
    fontSize: 12,
  },
  skeletonContainer: {
    flexDirection: 'row',
    padding: 15,
  },
  skeletonProfile: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#e0e0e0',
    marginRight: 15,
  },
  skeletonText: {
    width: '80%',
    height: 10,
    marginBottom: 5,
    backgroundColor: '#e0e0e0',
  },
});



export default ContactList;
