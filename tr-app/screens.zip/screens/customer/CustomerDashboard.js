/******************************************************************************************
 * CustomerDashboard.js – Aesthetic, Royal & Fully Responsive Dashboard
 *
 * Theme: Dark/Minimalist with Teal Green (#09B368) + Gold Accents
 ******************************************************************************************/


import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  SafeAreaView,
  ScrollView,
  Image,
  TextInput,
  Modal,
  FlatList,
  Animated,
  Dimensions,
  Alert,
  Platform,
  StatusBar,
  useWindowDimensions,
  PermissionsAndroid,
  Linking,
  RefreshControl 
} from 'react-native';
import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
} from 'react-native-responsive-screen';
import Icon from 'react-native-vector-icons/Feather';
import DateTimePicker from '@react-native-community/datetimepicker';
import AsyncStorage from '@react-native-async-storage/async-storage';
import LinearGradient from 'react-native-linear-gradient';
import { useNavigation } from '@react-navigation/native';
import { WebView } from 'react-native-webview';
import VendorCard from '../../components/VendorCard'; // update path accordingly
import Geolocation from 'react-native-geolocation-service';
import api from '../api';

// ────── COLORS ──────
const BRAND_TEAL = '#09B368';
const GOLD = '#FFD700';
const RED = '#FF3B30';
const TEXT_PRIMARY = '#212121';
const TEXT_SECONDARY = '#666';
const BG = '#F8F9FA';
const CARD = '#FFFFFF';

// ────── RESPONSIVE HELPERS ──────
const CARD_WIDTH = wp('42%');
const height = wp('100%');
const CATEGORY_TILE = (wp('100%') - wp('5%') * 2) / 4 - wp('2%');

// ────── MOCK DATA ──────

const CATEGORIES = [
  {
    id: '1',
    label: 'Bike',
    sub: 'Bikes & \n Scooters',
    image: require('../../assets/bike.png'),
    screen: 'BikeRentalScreen',
  },
  {
    id: '2',
    label: 'Standard Car',
    sub: 'Self Drive & \nChauffeur',
    image: require('../../assets/standard_car.png'),
    screen: 'CarRentalScreen',
  },
  {
    id: '3',
    label: 'Luxury Car',
    sub: 'Luxury & \nUrgent',
    image: require('../../assets/luxury_car.png'),
    screen: 'LuxuryScreen',
  },
  {
    id: '4',
    label: 'Self-Drive',
    sub: 'Cars & \nSUVs',
    image: require('../../assets/self_drives.png'),
    screen: 'SelfDriveScreen',
  },
  {
    id: '5',
    label: 'Bus',
    sub: '12-50 Seater',
    image: require('../../assets/bus.png'),
    screen: 'BusRentalScreen',
  },
  {
    id: '6',
    label: 'Truck',
    sub: 'Movers & Logistics',
    image: require('../../assets/truck.png'),
    screen: 'TruckRentalScreen',
  },
  {
    id: '7',
    label: 'Equipment',
    sub: 'Crane, Loader, etc.',
    image: require('../../assets/equipment.png'),
    screen: 'EquipmentScreen',
  },
  {
    id: '8',
    label: 'Packers & Movers',
    sub: 'House & Office Shifting',
    image: require('../../assets/packers_movers.png'),
    screen: 'PackerMoverScreen',
  },
];

const POPULAR_TRIPS = [
  { from: 'Bangalore', to: 'Goa', price: '₹8/km', tag: 'Beach Vibe', category: 'Cars', img: ('../../assets/slide011.png') },
  { from: 'Bangalore', to: 'Ooty', price: '₹9/km', tag: 'Hill Station', category: 'Cars', img: ('../../assets/ooty.jpg') },
  { from: 'Mumbai', to: 'Pune', price: '₹7/km', tag: 'Business Route', category: 'Bus', img: ('../../assets/pune.jpg') },
  { from: 'Delhi', to: 'Agra', price: '₹10/km', tag: 'Historical Tour', category: 'Cars', img: ('../../assets/tajmahal.jpg') },
];


const TESTIMONIALS = [
  { id: 't1', name: 'Priya S.', text: 'Best rates & super-fast quotes! ⭐⭐⭐⭐⭐', avatar: ('../../assets/avatar1.png') },
  { id: 't2', name: 'Vikram R.', text: 'Luxury car on time for my wedding. Highly recommended.', avatar: ('../../assets/avatar2.png') },
];

const HOW_IT_WORKS = [
  { step: '1', title: 'Post Requirement', icon: 'edit-3' },
  { step: '2', title: 'Receive Quotes', icon: 'message-square' },
  { step: '3', title: 'Book & Ride', icon: 'check-circle' },
];

export default function CustomerDashboard() {
const [isLoading, setIsLoading] = useState(true);
const [isRefreshing, setIsRefreshing] = useState(false);


  const navigation = useNavigation();
  const [vendors, setVendors] = useState([]);
  const [userName, setUserName] = useState('');
  const { width: winWidth } = useWindowDimensions();
const [webStories, setWebStories] = useState([]);
const [webStoryVisible, setWebStoryVisible] = useState(false);
const [selectedStoryUrl, setSelectedStoryUrl] = useState('');
  // ────── STATE ──────
  const [location, setLocation] = useState('Detecting...');
  const [selectedCategory, setSelectedCategory] = useState(null);
  const [fromLocation, setFromLocation] = useState('');
  const [toLocation, setToLocation] = useState('');
  const [pickupDate, setPickupDate] = useState(new Date());
  const [showPicker, setShowPicker] = useState(false);
  const [modalVisible, setModalVisible] = useState(false);
  const [unreadCount, setUnreadCount] = useState(0);
  const [activeTab, setActiveTab] = useState('Upcoming');  
const [currentWebStoryIndex, setCurrentWebStoryIndex] = useState(0);
const [recentQuotes, setRecentQuotes] = useState([]);
const [customerLocation, setCustomerLocation] = useState(null);
const [locationPermissionGranted, setLocationPermissionGranted] = useState(false);
  // ────── ANIMATIONS ──────
  const scrollY = useRef(new Animated.Value(0)).current;
  const headerOpacity = scrollY.interpolate({ inputRange: [0, 120], outputRange: [1, 0], extrapolate: 'clamp' });
  const headerScale = scrollY.interpolate({ inputRange: [0, 120], outputRange: [1, 0.93], extrapolate: 'clamp' });
  const fabAnim = useRef(new Animated.Value(1)).current;
  const modalSlide = useRef(new Animated.Value(height)).current;
const [upcomingTrips, setUpcomingTrips] = useState([]);
const hasActivity = upcomingTrips.length > 0 || recentQuotes.length > 0;

  // ────── STORY SYSTEM ──────
  const [storyModalVisible, setStoryModalVisible] = useState(false);
  const [currentStoryIdx, setCurrentStoryIdx] = useState(0);
  const [storyProgress, setStoryProgress] = useState(0);
  const storyTimer = useRef(null);
const [dashboardStats, setDashboardStats] = useState({
  active_bookings: 0,
  total_earnings: 0,
});
const fetchDashboardStats = async () => {
  try {
    const customerData = await AsyncStorage.getItem('customer');
    if (!customerData) {
      console.log(':no_entry_sign: No customer data in AsyncStorage');
      return;
    }
    const customer = JSON.parse(customerData);
    const identifier = customer?.id || customer?.email || customer?.phone;
    console.log(':incoming_envelope: Sending dashboard stats request with identifier:', identifier);
    const res = await fetch('https://app.transrentals.in/api/customer-dashboard-stats', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
      },
      body: JSON.stringify({ identifier }),
    });
    const text = await res.text();
    console.log(':package: Raw dashboard stats response:', text);
    const json = JSON.parse(text);
    if (json.success) {
      console.log(':white_check_mark: Parsed dashboard stats:', json);
      setDashboardStats({
        active_bookings: json.active_bookings ?? 0,
        total_earnings: json.total_earnings ?? 0,
      });
    } else {
      console.warn(':warning: Dashboard stats failed:', json);
    }
  } catch (err) {
    console.error(':x: Dashboard stats error:', err.message);
  }
};
const fetchBackrStats = async () => {
  try {
    const customerData = await AsyncStorage.getItem('customer');
    if (!customerData) return;
    const customer = JSON.parse(customerData);
    // same as BackrTokensScreen
    const res = await fetch('https://app.transrentals.in/api/backr?customer_id=' + customer.id);
    const json = await res.json();
    // json.tokens.earned_tokens is what you want
    const earned = json?.tokens?.earned_tokens ?? 0;
    console.log(':dart: backr for dashboard:', earned);
    setDashboardStats(prev => ({
      ...prev,
      total_earnings: earned,   // :point_left: put token earnings here
    }));
  } catch (e) {
    console.log('backr fetch for dashboard failed', e.message);
  }
};

  const requestLocationPermission = async () => {
  if (Platform.OS === 'android') {
    const granted = await PermissionsAndroid.request(
      PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION,
      {
        title: 'Location Permission',
        message: 'We need your location to show your current position.',
        buttonNeutral: 'Ask Me Later',
        buttonNegative: 'Cancel',
        buttonPositive: 'OK',
      }
    );
    return granted === PermissionsAndroid.RESULTS.GRANTED;
  }
  return true;
};

const getAddressFromCoords = async (lat, lon) => {
  try {
    const res = await fetch(
      `https://nominatim.openstreetmap.org/reverse?format=json&lat=${lat}&lon=${lon}`,
      {
        headers: {
          'User-Agent': 'TransRentals/1.0 (https://transrentals.in/)', // Required by OpenStreetMap
        },
      }
    );
    const text = await res.text();
    if (text.trim().startsWith('<')) return { city: '', state: '', country: '' };
    const data = JSON.parse(text);
    const address = data.address || {};
    return {
      city: address.state_district || address.town || address.village || address.city || address.county || '',
      state: address.state || '',
      country: address.country || '',
    };
  } catch (error) {
    console.log('Reverse geocoding error:', error);

    return { city: '', state: '', country: '' };
  }
};

const getCurrentLocation = async () => {
  Geolocation.getCurrentPosition(
    async (position) => {
      const { latitude, longitude } = position.coords;
      setCustomerLocation({ latitude, longitude });

      const { city } = await getAddressFromCoords(latitude, longitude);
      setLocation(city || 'Unknown');

      // Optional: Update backend
      try {
        const customerId = await AsyncStorage.getItem('customer_id');
        if (customerId) {
         await api.post('/customer/update-customer-location', {
  customer_id: customerId,
  latitude,
  longitude,
  city,
});

        }
      } catch (err) {
        console.log('Backend update error:', err);
      }
    },
    (error) => {
      console.log('Location fetch error:', error);
    },
    { enableHighAccuracy: true, timeout: 15000, maximumAge: 10000 }
  );
};
const fetchVendors = async () => {
  console.log('[fetchVendors] 🚀 Fetching featured vendors...');

  try {
    const response = await api.get('/vendors/featured');
    
    console.log('[fetchVendors] 📦 Raw Response:', response);

    const { data } = response;

    if (!data) {
      console.warn('[fetchVendors] ⚠️ No data returned from API.');
      return;
    }

    if (data.success && Array.isArray(data.vendors)) {
      console.log(`[fetchVendors] ✅ ${data.vendors.length} vendor(s) fetched successfully.`);
      setVendors(data.vendors);

      // Optional: Log first vendor details for preview
      if (data.vendors.length > 0) {
        console.log('[fetchVendors] 🔍 First Vendor:', data.vendors[0]);
      }
    } else {
      console.warn('[fetchVendors] ❌ API responded but success flag is false or vendors is not an array.');
      console.log('[fetchVendors] 💬 Response:', data);
    }
  } catch (error) {
    console.error('[fetchVendors] 🛑 Error fetching vendors:', error.message);
    if (error.response) {
      console.error('[fetchVendors] 🔍 Error Response:', error.response.data);
    }
  }
};

const fetchWebStories = async () => {
  try {
    const response = await fetch('https://transrentals.in/wander/wp-json/web-stories/v1/web-story?_embed');
    const data = await response.json();

    const formatted = data.map(story => ({
      id: story.id.toString(),
      title: story.title.rendered,
      url: story.link,
      image: story._embedded?.['wp:featuredmedia']?.[0]?.source_url || 'https://transrentals.in/logo.png',
      avatar: 'https://transrentals.in/logo.png',
      user: 'TransRentals',
      duration: 4000,
    }));

    setWebStories(formatted);
  } catch (error) {
    console.error('Failed to fetch web stories:', error);
  }
};
const fetchRecentQuotes = async () => {
  try {
    const customerData = await AsyncStorage.getItem('customer');
    if (!customerData) return;

    const customer = JSON.parse(customerData);
    const email = customer?.email;

    const { data } = await api.post('/customer-recent-quotes', { email });

    if (data.success) {
      setRecentQuotes(data.quotes);
    }
  } catch (error) {
    console.log('Error fetching recent quotes:', error.message);
  }
};


const openWebStory = (index) => {
  setCurrentWebStoryIndex(index);
  setWebStoryVisible(true);
};
  // ────── LIFECYCLE ──────
  useEffect(() => {
    // Fade-in the whole screen
    Animated.timing(fabAnim, { toValue: 1, duration: 600, useNativeDriver: true }).start();

    // Slide-up modal (initial hidden position)
    Animated.spring(modalSlide, { toValue: 0, friction: 8, useNativeDriver: true }).start();

    initApp();

    (async () => {
  const granted = await requestLocationPermission();
  setLocationPermissionGranted(granted);
  if (granted) {
    getCurrentLocation();
  }
})();

  }, []);

  // Story timer
  useEffect(() => {
    if (!storyModalVisible) { clearStoryTimer(); return; }
    startStoryTimer();
    return () => clearStoryTimer();
  }, [storyModalVisible, currentStoryIdx]);

  const clearStoryTimer = () => { if (storyTimer.current) clearInterval(storyTimer.current); };
  const startStoryTimer = () => {
    clearStoryTimer();
    setStoryProgress(0);
    const story = STORIES[currentStoryIdx];
    const duration = story?.duration ?? 3500;
    const step = 50;
    const steps = Math.floor(duration / step);
    let cnt = 0;
    storyTimer.current = setInterval(() => {
      cnt++;
      setStoryProgress(cnt / steps);
      if (cnt >= steps) {
        if (currentStoryIdx < STORIES.length - 1) setCurrentStoryIdx(i => i + 1);
        else setStoryModalVisible(false);
      }
    }, step);
  };
useEffect(() => {
  fetchWebStories();
}, []);
  const openStory = (idx) => {
    setCurrentStoryIdx(idx);
    setStoryProgress(0);
    setStoryModalVisible(true);
    // Start timer immediately to avoid a race with the effect
    try { startStoryTimer(); } catch (e) { /* ignore if not available */ }
  };
const fetchUpcomingBookings = async () => {
  console.log('[fetchUpcomingBookings] 🚀 Starting function...');

  try {
    const customerData = await AsyncStorage.getItem('customer');
    console.log('[fetchUpcomingBookings] 📦 Retrieved customerData:', customerData);

    if (!customerData) {
      console.warn('[fetchUpcomingBookings] ⚠️ No customer data found in AsyncStorage.');
      return;
    }

    const customer = JSON.parse(customerData);
    const email = customer?.email;
const phone = customer?.phone;
    if (!email) {
      console.warn('[fetchUpcomingBookings] ⚠️ Customer email missing.');
      return;
    }

    console.log('[fetchUpcomingBookings] 📧 Email to be used in API call:', email);

    const response = await api.post('/customer-upcoming-bookings', { phone });

    console.log('[fetchUpcomingBookings] ✅ API Response:', response);

    const { data } = response;

    if (!data) {
      console.warn('[fetchUpcomingBookings] ❌ No data returned from API.');
      return;
    }

    if (data.success) {
      console.log(`[fetchUpcomingBookings] 📥 Bookings received: ${data.bookings.length}`);

      const formatted = data.bookings.map(b => {
        const formattedBooking = {
          id: b.id.toString(),
          from: b.location_name ?? 'N/A',
          to: b.destination ?? 'N/A',
          date: new Date(b.journey_datetime).toLocaleDateString('en-IN', {
            day: 'numeric',
            month: 'short',
          }),
          status: b.service_name,
          driver: b.service_name || 'Pending',
          type: b.service?.type || 'Unknown',
        };

        console.log('[fetchUpcomingBookings] 🔄 Formatted Booking:', formattedBooking);
        return formattedBooking;
      });

      setUpcomingTrips(formatted);
      console.log('[fetchUpcomingBookings] ✅ Upcoming trips set successfully.');
    } else {
      console.warn('[fetchUpcomingBookings] ❌ API returned success: false.');
      console.log('[fetchUpcomingBookings] 🔍 API Response Data:', data);
    }
  } catch (error) {
    console.error('[fetchUpcomingBookings] 🛑 Error occurred:', error.message);
    if (error.response) {
      console.error('[fetchUpcomingBookings] 🔍 Error Response:', error.response.data);
    }
  }
};

  // ────── APP INIT ──────
 const initApp = async (isRefresh = false) => {
  try {
    if (!isRefresh) setIsLoading(true);
    else setIsRefreshing(true);

    setLocation('Bangalore');
    setFromLocation('Bangalore');
    setUnreadCount(3);
      fetchDashboardStats();
     fetchBackrStats();


    const customerData = await AsyncStorage.getItem('customer');
    if (customerData) {
      const customer = JSON.parse(customerData);
      setUserName(customer.name || 'User');
    }

    await Promise.all([
      fetchUpcomingBookings(),
      fetchRecentQuotes(),
      fetchVendors(),
      fetchWebStories()
    ]);
  } catch (error) {
    console.error('Error in initApp:', error);
  } finally {
    setIsLoading(false);
    setIsRefreshing(false);
  }
};

useEffect(() => {
  if (upcomingTrips.length === 0 && recentQuotes.length > 0) {
    setActiveTab('Quotes');
  } else if (recentQuotes.length === 0 && upcomingTrips.length > 0) {
    setActiveTab('Upcoming');
  }
},[upcomingTrips, recentQuotes]);
  // ────── MODAL HANDLERS ──────
  // Keep JS-friendly signatures (no TS annotations inside .js file)
  const openModal = (cat) => { setSelectedCategory(cat); setModalVisible(true); };
  const closeModal = () => setModalVisible(false);
  const postRequirement = () => {
    Animated.sequence([
      Animated.spring(fabAnim, { toValue: 0.85, useNativeDriver: true }),
      Animated.spring(fabAnim, { toValue: 1, useNativeDriver: true }),
    ]).start(() => {
      Alert.alert('Success', 'Requirement posted! Vendors will send quotes shortly.');
      closeModal();
      navigation.navigate('MyBookings');
    });
  };

  // ────── RENDER HELPERS ──────
  // Booking card used in the Activity list
  const BookingCard = ({ item }) => (
    <TouchableOpacity
      style={styles.bookingCard}
  onPress={() => {
  if (activeTab === 'Upcoming') {
navigation.navigate('BookingDetail', { bookingId: item.id });
  } else if (activeTab === 'Quotes') {
    navigation.navigate('ViewQuote', { quoteId: item.id });
  }
}}
      accessibilityLabel={`Booking ${item.from} to ${item.to}`}
    >
      <View style={styles.bookingLeft}>
        {activeTab === 'Quotes' ? (
          <>
            <Text style={styles.quotePrice}>{item.price}</Text>
            <Text style={styles.quoteVendor}>{item.vendor} • {item.vehicle}</Text>
              <Text style={styles.quoteRoute}>{item.from} → {item.to}</Text>
            <View style={styles.quoteFooter}>
              <Icon name="clock" size={14} color={GOLD} />
              {/* <Text style={styles.quoteRating}>{item.rating}</Text> */}
              <Text style={styles.quoteTime}>{item.time}</Text>
            </View>
          </>
        ) : (
          <>
            <Text style={styles.bookingRoute}>{item.from} → {item.to}</Text>
            <Text style={styles.bookingSub}>{item.date} | {item.type}</Text>
            <View style={styles.statusRow}>
              <Icon name="check-circle" size={16} color={BRAND_TEAL} />
              <Text style={styles.bookingStatus}>{item.status}</Text>
            </View>
          </>
        )}
      </View>
      <Icon name="arrow-right" size={20} color={BRAND_TEAL} />
    </TouchableOpacity>
  );

const QuickStats = () => (
  <View style={styles.statsRow}>
    <View style={styles.statBox}>
      <Text style={styles.statValue}>{dashboardStats.active_bookings}</Text>
      <Text style={styles.statLabel}>Active Bookings</Text>
    </View>
   <View style={styles.statBox}>
  <Text style={styles.statValue}>
    {Number(dashboardStats.total_earnings || 0).toLocaleString('en-IN')}
  </Text>
  <Text style={styles.statLabel}>Backr Earned</Text>
</View>
    <View style={styles.statBox}>
      <Text style={styles.statValue}>{vendors.length}</Text>
      <Text style={styles.statLabel}>Vendors</Text>
    </View>
  </View>
);

 const HowItWorksSection = () => (
  <View style={styles.section}>
    <Text style={styles.sectionTitle}>How TransRentals Works</Text>
    <View style={styles.howItWorksContainer}>
      {HOW_IT_WORKS.map((step, index) => (
        <View key={step.step} style={styles.howStepCard}>
          {/* Step Number with Gradient */}
          <LinearGradient
            colors={['#09B368', '#07A55E']}
            style={styles.stepNumberCircle}
          >
            <Text style={styles.stepNumber}>{step.step}</Text>
          </LinearGradient>

          {/* Step Content */}
          <View style={styles.stepContent}>

            <View style={styles.stepIconTitleRow}>
            <View style={styles.stepIconContainer}>
              <Icon name={step.icon} size={wp('5%')} color="#09B368" />
            </View>
            <Text style={styles.stepTitle}>{step.title}</Text>
               </View>
            <Text style={styles.stepDescription}>
              {getStepDescription(step.step)}
            </Text>
       
          </View>

          {/* Connecting Line (except for last step) */}
          {index < HOW_IT_WORKS.length - 1 && (
            <View style={styles.connectingLine} />
          )}
        </View>
      ))}
    </View>
  </View>
);

// Helper function for step descriptions
const getStepDescription = (step) => {
  const descriptions = {
    '1': 'Tell us what you need - vehicle type, dates, and route',
    '2': 'Receive competitive quotes from verified vendors',
    '3': 'Compare, choose, and confirm your booking instantly'
  };
  return descriptions[step] || 'Simple and hassle-free process';
};

  const TestimonialsSection = () => (
    <View style={styles.section}>
      <Text style={styles.sectionTitle}>What Our Riders Say</Text>
      <FlatList
        data={TESTIMONIALS}
        horizontal
        showsHorizontalScrollIndicator={false}
        keyExtractor={i => i.id}
        contentContainerStyle={{ paddingRight: wp('4%'), marginBottom: wp('2%'), }}
        renderItem={({ item }) => (
          <View style={styles.testimonialCard}>
            <Image source={item.avatar} style={styles.testAvatar} />
            <Text style={styles.testName}>{item.name}</Text>
            <Text style={styles.testText} numberOfLines={3}>{item.text}</Text>
          </View>
        )}
      />
    </View>
  );
const SAFETY_TIPS = [
  { label: 'Verified Drivers', icon: 'user-check' },
  { label: 'Live Tracking', icon: 'map-pin' },
  { label: '24×7 Support', icon: 'headphones' },
  { label: 'Secure Payments', icon: 'lock' },
];

const SafetyTips = () => (
  <View style={styles.section}>
    <Text style={styles.sectionTitle}>Safety First</Text>
    <View style={styles.tipsGrid}>
      {SAFETY_TIPS.map((tip, i) => (
        <View key={i} style={styles.tipBox}>
          <Icon name={tip.icon} size={wp('6%')} color={GOLD} />
          <Text style={styles.tipText}>{tip.label}</Text>
        </View>
      ))}
    </View>
  </View>
);
  // ────── MAIN RETURN ──────
{isLoading ? (
  <>
    {/* Category Skeleton */}
    <View style={styles.section}>
      <Text style={styles.sectionTitle}>Find Your Perfect Ride</Text>
      <View style={styles.catGrid}>
        {[...Array(8)].map((_, i) => (
          <View key={i} style={[styles.catTile, { opacity: 0.3 }]}>
            <View style={styles.catImageBox} />
            <View style={{ width: wp('10%'), height: hp('1.5%'), backgroundColor: '#ccc', borderRadius: 4, marginTop: 6 }} />
            <View style={{ width: wp('12%'), height: hp('1.5%'), backgroundColor: '#ccc', borderRadius: 4, marginTop: 4 }} />
          </View>
        ))}
      </View>
    </View>

    {/* Vendor Skeleton */}
    <View style={styles.section}>
      <Text style={styles.sectionTitle}>Explore Our Fleet & Partners</Text>
      <ScrollView horizontal showsHorizontalScrollIndicator={false}>
        {[...Array(3)].map((_, i) => (
          <View key={i} style={[styles.vendorCard, { backgroundColor: '#e0e0e0' }]} />
        ))}
      </ScrollView>
    </View>

    {/* Activity Skeleton */}
    <View style={styles.section}>
      <Text style={styles.sectionTitle}>Your Activity</Text>
      {[...Array(2)].map((_, i) => (
        <View key={i} style={[styles.bookingCard, { backgroundColor: '#f0f0f0', opacity: 0.3 }]} />
      ))}
    </View>
  </>
) : (
  <>
    {/* All your normal content (already written) */}
  </>
)}  
  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor="#1C1C1C" />

      {/* FIXED ANIMATED HEADER */}
      <Animated.View style={[styles.fixedHeader, { opacity: headerOpacity, transform: [{ scale: headerScale }] }]}>
        <View style={styles.topBar}>
          <View>
           <TouchableOpacity onPress={() => navigation.navigate('SettingScreen')}>
      <Text style={styles.greeting}>
        Hello, <Text style={{ fontWeight: '800' }}>{userName}</Text> 
      </Text>
    </TouchableOpacity>
            {locationPermissionGranted && location && location !== 'Detecting...' && location !== 'Unknown' && (
    <TouchableOpacity
      style={styles.locationBox}
      onPress={() => Alert.alert('Location', 'Pick on map')}
    >
      <Icon name="map-pin" size={wp('4%')} color={BRAND_TEAL} />
      <Text style={styles.locationText}>{location}</Text>
      <Icon name="chevron-down" size={wp('4%')} color={TEXT_SECONDARY} />
    </TouchableOpacity>
  )}
          </View>
          <TouchableOpacity style={styles.notifBtn} onPress={() => navigation.navigate('Notifications')}>
            <Icon name="bell" size={wp('6.5%')} color={TEXT_PRIMARY} />
            {unreadCount > 0 && (
              <View style={styles.badge}>
                <Text style={styles.badgeTxt}>{unreadCount}</Text>
              </View>
            )}
          </TouchableOpacity>
        </View>
      </Animated.View>

    <Animated.ScrollView
  showsVerticalScrollIndicator={false}
  onScroll={Animated.event(
    [{ nativeEvent: { contentOffset: { y: scrollY } } }],
    { useNativeDriver: false }
  )}
  scrollEventThrottle={16}
  contentContainerStyle={{ paddingTop: hp('14%') }}
  refreshControl={
    <RefreshControl
      refreshing={isRefreshing}
      onRefresh={() => initApp(true)}
      colors={[BRAND_TEAL]}
      tintColor={BRAND_TEAL}
    />
  }
>
        {/* STORIES BAR */}
        <View style={styles.storiesWrap}>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.storiesScroll}>
           
       {webStories.map((s, i) => (
  <TouchableOpacity key={s.id} style={styles.storyItem} onPress={() => openWebStory(i)}>
    <View style={styles.storyRing}>
      <Image
        source={{ uri: s.image }}
        style={{ width: wp('18%'), height: wp('18%'), borderRadius: wp('50%'), backgroundColor: "#ca1e1eff"}}
      />
    </View>
    <Text numberOfLines={2} ellipsizeMode="tail" style={styles.storyLabel}>
      {s.title.length > 24 ? s.title.slice(0, 10) + '...' : s.title}
    </Text>
  </TouchableOpacity>
))}

          </ScrollView>
        </View>

        {/* CATEGORIES GRID */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Find Your Perfect Ride</Text>
          <View style={styles.catGrid}>
            {CATEGORIES.map(c => (
              <TouchableOpacity key={c.id} style={styles.catTile} onPress={() => {
  if (c.screen) {
    navigation.navigate(c.screen);
  } else {
    Alert.alert('Coming Soon', `We're still working on ${c.label} rentals.`);
  }
}}>
               <View style={styles.catImageBox}>
  <Image source={c.image} style={styles.catImage} resizeMode="contain" />
</View>
                <Text style={styles.catLabel}>{c.label}</Text>
                <Text style={styles.catSub}>{c.sub}</Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>

        {/* VENDOR SPOTLIGHT */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Explore Our Fleet & Partners</Text>
       <FlatList
  data={vendors}
  horizontal
  showsHorizontalScrollIndicator={false}
  keyExtractor={item => item.id.toString()}
  contentContainerStyle={{ paddingRight: wp('4%') }}
  renderItem={({ item }) => (
    <TouchableOpacity
      onPress={() => navigation.navigate('VendorDetails', { id: item.id })}
    >
      <VendorCard vendor={item} />
    </TouchableOpacity>
  )}
/>
        </View>

        {/* QUICK STATS */}
        <QuickStats />

        {/* ACTIVITY (Upcoming / Quotes) */}
    {hasActivity && (
  <View style={styles.section}>
    <View style={styles.actHeader}>
      <Text style={styles.sectionTitle}>Your Activity</Text>
      <TouchableOpacity onPress={() => navigation.navigate('MyBookings')}>
        <Text style={styles.seeAll}>View All</Text>
      </TouchableOpacity>
    </View>

    <View style={styles.segmentCtrl}>
      {upcomingTrips.length > 0 && (
        <TouchableOpacity
          style={[styles.segment, activeTab === 'Upcoming' && styles.segmentActive]}
          onPress={() => setActiveTab('Upcoming')}
        >
          <Text style={[styles.segmentTxt, activeTab === 'Upcoming' && styles.segmentTxtActive]}>Upcoming</Text>
        </TouchableOpacity>
      )}
    {recentQuotes.length > 0 && (
    <TouchableOpacity
      style={[styles.segment, activeTab === 'Quotes' && styles.segmentActive]}
      onPress={() => setActiveTab('Quotes')}
    >
      <Text style={[styles.segmentTxt, activeTab === 'Quotes' && styles.segmentTxtActive]}>Quotes</Text>
    </TouchableOpacity>
  )}
    </View>

    {(activeTab === 'Upcoming' ? upcomingTrips : recentQuotes).length === 0 ? (
      <View style={styles.empty}>
        <Icon name="archive" size={wp('12%')} color="#ccc" />
        <Text style={styles.emptyTxt}>
          No {activeTab === 'Upcoming' ? 'trips' : 'quotes'} yet!
        </Text>
      </View>
    ) : (
      (activeTab === 'Upcoming' ? upcomingTrips : recentQuotes).map(item => (
        <BookingCard key={item.id} item={item} />
      ))
    )}
  </View>
)}
        {/* HOW IT WORKS */}
        <HowItWorksSection />

        {/* POPULAR ROUTES */}
        {/* <View style={styles.section}>
          <Text style={styles.sectionTitle}>Next Adventure Routes</Text>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ paddingHorizontal: wp('4%') }}>
            {POPULAR_TRIPS.map((t, i) => (
              <TouchableOpacity
                key={i}
                style={styles.popCard}
                onPress={() => openModal(CATEGORIES.find(c => c.label === t.category))}
              >
                <Image source={t.img} style={styles.popImg} />
                <LinearGradient colors={['transparent', 'rgba(0,0,0,0.75)']} style={styles.popOverlay}>
                  <Text style={styles.popTag}>{t.tag}</Text>
                  <Text style={styles.popRoute}>{t.from} → {t.to}</Text>
                  <Text style={styles.popPrice}>{t.price} Onwards</Text>
                </LinearGradient>
              </TouchableOpacity>
            ))}
          </ScrollView>
        </View> */}

        {/* TESTIMONIALS */}
        <TestimonialsSection />

        {/* SAFETY TIPS */}
        <SafetyTips />

        <View style={{ height: hp('12%') }} />
      </Animated.ScrollView>

      {/* FAB */}
      

      {/* BOTTOM NAV */}




      <View style={styles.bottomNav}>
        {[

          { icon: 'home', label: 'Home', active: true, screen: null },
          { icon: 'book-open', label: 'Bookings', screen: 'MyBookings' },
          { icon: 'message-square', label: 'Quotes', screen: null },
          { icon: 'user', label: 'Profile', screen: 'Profile' },
        ].map((n, i) => (
          <TouchableOpacity
            key={i}
            style={n.active ? styles.navActive : styles.navItem}
            onPress={() => n.screen && navigation.navigate(n.screen)}
          >
            <Icon name={n.icon} size={wp('6.5%')} color={n.active ? BRAND_TEAL : TEXT_SECONDARY} />
            <Text style={n.active ? styles.navActiveTxt : styles.navTxt}>{n.label}</Text>
          </TouchableOpacity>
        ))}
      </View>

      {/* REQUIREMENT MODAL */}
      <Modal visible={modalVisible} animationType="slide" transparent>
        <Animated.View style={[styles.modalOverlay, { transform: [{ translateY: modalSlide }] }]}>
          <View style={styles.modalSheet}>
            <View style={styles.modalHead}>
              <View>
                <Text style={styles.modalTitle}>{selectedCategory?.label || 'New Rental'}</Text>
                <Text style={styles.modalSub}>Request quotes for {selectedCategory?.sub || 'any service'}</Text>
              </View>
              <TouchableOpacity onPress={closeModal}><Icon name="x" size={wp('7%')} color="#999" /></TouchableOpacity>
            </View>

            <ScrollView contentContainerStyle={{ paddingBottom: hp('3%') }}>
              {/* Service Picker */}
              <View style={styles.inputGroup}>
                <Text style={styles.label}>Service Type</Text>
                <TouchableOpacity style={styles.dropdown} onPress={() => Alert.alert('Picker', 'Open service list')}>
                  <Text style={styles.dropdownTxt}>{selectedCategory?.label || 'Tap to select…'}</Text>
                  <Icon name="chevron-down" size={wp('5%')} color={TEXT_PRIMARY} />
                </TouchableOpacity>
              </View>

              {/* Pickup */}
              <View style={styles.inputGroup}>
                <Text style={styles.label}>Pickup Location</Text>
                <View style={styles.inputRow}>
                  <Icon name="map-pin" size={wp('5%')} color={BRAND_TEAL} />
                  <TextInput style={styles.input} placeholder="e.g., Koramangala, Bangalore" value={fromLocation} onChangeText={setFromLocation} />
                </View>
              </View>

              {/* Drop (optional) */}
              <View style={styles.inputGroup}>
                <Text style={styles.label}>Drop Location (optional)</Text>
                <View style={styles.inputRow}>
                  <Icon name="map" size={wp('5%')} color={TEXT_SECONDARY} />
                  <TextInput style={styles.input} placeholder="e.g., MG Road, Bangalore" value={toLocation} onChangeText={setToLocation} />
                </View>
              </View>

              {/* Date */}
              <View style={styles.inputGroup}>
                <Text style={styles.label}>Pickup Date & Time</Text>
                <TouchableOpacity style={styles.dateBtn} onPress={() => setShowPicker(true)}>
                  <Icon name="calendar" size={wp('5%')} color={BRAND_TEAL} />
                  <Text style={styles.dateTxt}>{pickupDate.toLocaleString()}</Text>
                </TouchableOpacity>
              </View>

              {showPicker && (
                <DateTimePicker
                  value={pickupDate}
                  mode="datetime"
                  display={Platform.OS === 'ios' ? 'spinner' : 'default'}
                  onChange={(e, d) => {
                    setShowPicker(Platform.OS === 'ios');
                    if (d) setPickupDate(d);
                  }}
                />
              )}
            </ScrollView>

            <TouchableOpacity style={styles.postBtn} onPress={postRequirement}>
              <Text style={styles.postBtnTxt}>Get Custom Quotes</Text>
            </TouchableOpacity>
          </View>
        </Animated.View>
      </Modal>

      {webStoryVisible && (
      <Modal visible={webStoryVisible} animationType="slide" onRequestClose={() => setWebStoryVisible(false)}>
  <SafeAreaView style={{ flex: 1, backgroundColor: '#000' }}>
    <FlatList
      data={webStories}
      horizontal
      pagingEnabled
      initialScrollIndex={currentWebStoryIndex}
      keyExtractor={(item) => item.id}
      showsHorizontalScrollIndicator={false}
      getItemLayout={(data, index) => (
        { length: Dimensions.get('window').width, offset: Dimensions.get('window').width * index, index }
      )}
      renderItem={({ item }) => (
        <WebView
          source={{ uri: item.url }}
          style={{ width: Dimensions.get('window').width, height: '100%' }}
          startInLoadingState
          renderLoading={() => (
            <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
              <Text style={{ color: '#fff' }}>Loading...</Text>
            </View>
          )}
        />
      )}
    />
    <TouchableOpacity
      onPress={() => setWebStoryVisible(false)}
      style={{
        position: 'absolute',
        top: Platform.OS === 'ios' ? 50 : 20,
        left: 20,
        backgroundColor: 'rgba(0,0,0,0.5)',
        padding: 10,
        borderRadius: 20,
      }}
    >
      <Icon name="x" size={24} color="#fff" />
    </TouchableOpacity>
  </SafeAreaView>
</Modal>

)}
    </SafeAreaView>
  );
}

/* ────────────────────── STYLES (Responsive) ────────────────────── */
const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: BG },

  // Header
  fixedHeader: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    backgroundColor: CARD,
    zIndex: 10,
    paddingTop: Platform.select({ ios: hp('2%'), android: (StatusBar.currentHeight ?? 0) + hp('0%') }),
    paddingHorizontal: wp('4%'),
    paddingBottom: hp('1%'),
    borderBottomLeftRadius: 20,
    borderBottomRightRadius: 20,
    elevation: 6,
  },
  topBar: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  greeting: { fontSize: wp('5.5%'), fontWeight: '700', color: TEXT_PRIMARY },
  locationBox: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#f0f0f0', paddingHorizontal: wp('3%'), paddingVertical: hp('0.5%'), borderRadius: 30, marginTop: hp('1%') },
  locationText: { marginLeft: wp('1.5%'), fontSize: wp('3.8%'), color: TEXT_PRIMARY, fontWeight: '600' },
  notifBtn: { padding: wp('1%') },
  badge: { position: 'absolute', top: -wp('1%'), right: -wp('1%'), backgroundColor: RED, borderRadius: wp('3%'), minWidth: wp('5%'), height: wp('5%'), justifyContent: 'center', alignItems: 'center' },
  badgeTxt: { color: '#fff', fontSize: wp('2.8%'), fontWeight: 'bold' },

  // Stories
  storiesWrap: { marginTop: hp('0.5%'), paddingLeft: wp('4%') },
  storiesScroll: { paddingRight: wp('8%') },
  storyAdd: { alignItems: 'center', marginRight: wp('4%') },
  storyRing: { width: wp('21%'), height: wp('21%'), borderRadius: wp('50%'), justifyContent: 'center', alignItems: 'center', borderWidth: 2, borderColor: "#35ad31ff", backgroundColor: '#fff' },
  storyItem: { alignItems: 'center', marginRight: wp('4%'),  },
  storyLabel: { marginTop: hp('0.5%'), fontSize: wp('3.5%'), color: TEXT_SECONDARY, fontWeight: '500' },

  // Section generic
  section: { marginTop: hp('3.5%'), paddingHorizontal: wp('4%'),  },
  sectionTitle: { fontSize: wp('5%'), fontWeight: '700', color: TEXT_PRIMARY, marginBottom: hp('1.5%') },
  seeAll: { fontSize: wp('3.8%'), color: BRAND_TEAL, fontWeight: '600' },
quoteRoute: {
  fontSize: wp('3.8%'),
  color: TEXT_SECONDARY,
  marginTop: hp('0.5%'),
},
  // Categories
  catGrid: { flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'space-around', alignContent:"center", alignItems: "center" },
  catTile: { width: CATEGORY_TILE, alignItems: 'center', marginBottom: hp('2%') },
  catIcon: { width: wp('12%'), height: wp('13%'), borderRadius: 16, justifyContent: 'center', alignItems: 'center', marginBottom: hp('1%'), borderWidth: 1, borderColor: '#eee' },
  catLabel: { fontSize: wp('3.6%'), fontWeight: '700', color: TEXT_PRIMARY, textAlign: 'center' },
  catSub: { fontSize: wp('2.8%'), color: TEXT_SECONDARY, marginTop: hp('0.3%'), textAlign: 'center' },
  catImageBox: {
  width: wp('16%'),
  height: wp('16%'),
  borderRadius: 12,
  justifyContent: 'center',
  alignItems: 'center',
  marginBottom: hp('1%'),
  backgroundColor: '#f2f2f2',
  borderWidth: 1,
  borderColor: '#eee',
},
catImage: {
  width: '95%',
  height: '95%',
   borderRadius: 12,
},
  // Vendor Spotlight
  vendorCard: { width: CARD_WIDTH, height: hp('18%'), marginRight: wp('4%'), borderRadius: 16, overflow: 'hidden', elevation: 4, marginBottom: hp('1%') },
  vendorGrad: { flex: 1, padding: wp('4%'), justifyContent: 'space-between' },
  vendorHead: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  ratingBox: { flexDirection: 'row', alignItems: 'center', backgroundColor: GOLD + '20', borderRadius: 12, paddingHorizontal: wp('2%'), paddingVertical: hp('0.4%') },
  ratingTxt: { marginLeft: wp('1%'), fontSize: wp('3%'), fontWeight: '600', color: GOLD },
  vendorName: { fontSize: wp('4.2%'), fontWeight: 'bold', color: TEXT_PRIMARY },
  vendorVeh: { fontSize: wp('3%'), color: TEXT_SECONDARY },

  // Quick Stats
  statsRow: { flexDirection: 'row', justifyContent: 'space-between', marginTop: hp('2%'), paddingHorizontal: wp('4%') },
  statBox: { alignItems: 'center', flex: 1 },
  statValue: { fontSize: wp('5.5%'), fontWeight: '800', color: BRAND_TEAL },
  statLabel: { fontSize: wp('3%'), color: TEXT_SECONDARY, marginTop: hp('0.3%') },

  // Activity
  actHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: hp('1.5%') },
  segmentCtrl: { flexDirection: 'row', backgroundColor: '#e8e8e8', borderRadius: 12, padding: wp('1%'), marginBottom: hp('2%') },
  segment: { flex: 1, alignItems: 'center', paddingVertical: hp('1%'), borderRadius: 10 },
  segmentActive: { backgroundColor: CARD, elevation: 2 },
  segmentTxt: { fontSize: wp('3.5%'), fontWeight: '600', color: TEXT_SECONDARY },
  segmentTxtActive: { color: TEXT_PRIMARY },

  bookingCard: { backgroundColor: CARD, borderRadius: 16, padding: wp('4%'), flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: hp('1.5%'), elevation: 2 },
  bookingLeft: { flex: 1 },
  bookingRoute: { fontSize: wp('4%'), fontWeight: '700', color: TEXT_PRIMARY },
  bookingSub: { fontSize: wp('3%'), color: TEXT_SECONDARY, marginTop: hp('0.2%') },
  statusRow: { flexDirection: 'row', alignItems: 'center', marginTop: hp('0.5%') },
  bookingStatus: { fontSize: wp('3.5%'), fontWeight: '600', color: BRAND_TEAL, marginLeft: wp('1%') },

  quotePrice: { fontSize: wp('5%'), fontWeight: 'bold', color: RED },
  quoteVendor: { fontSize: wp('3.6%'), color: TEXT_PRIMARY, marginTop: hp('0.2%') },
  quoteFooter: { flexDirection: 'row', alignItems: 'center', marginTop: hp('0.5%') },
  quoteRating: { marginLeft: wp('1%'), fontSize: wp('3.4%'), color: TEXT_PRIMARY },
  quoteTime: { marginLeft: wp('1%'), fontSize: wp('3%'), color: TEXT_SECONDARY },

  empty: { alignItems: 'center', paddingVertical: hp('4%'), backgroundColor: CARD, borderRadius: 16, marginTop: hp('1%') },
  emptyTxt: { marginTop: hp('1%'), fontSize: wp('4%'), color: TEXT_SECONDARY },

  // How It Works
  howRow: { flexDirection: 'row', justifyContent: 'space-between' },
  howStep: { alignItems: 'center', flex: 1 },
  howIconWrap: { width: wp('14%'), height: wp('14%'), borderRadius: wp('7%'), backgroundColor: BRAND_TEAL + '15', justifyContent: 'center', alignItems: 'center', marginBottom: hp('1%') },
  howStepNum: { fontSize: wp('4%'), fontWeight: '800', color: BRAND_TEAL },
  howTitle: { fontSize: wp('3.4%'), color: TEXT_PRIMARY, textAlign: 'center', marginTop: hp('0.5%') },
vendorImage: { width: '100%', height: hp('10%'), borderRadius: 12, marginBottom: hp('1%') },

  // Popular Routes
  popCard: { width: wp('70%'), height: hp('22%'), marginRight: wp('4%'), borderRadius: 18, overflow: 'hidden', elevation: 5 },
  popImg: { width: '100%', height: '100%' },
  popOverlay: { ...StyleSheet.absoluteFillObject, justifyContent: 'flex-end', padding: wp('4%') },
  popTag: { color: GOLD, fontSize: wp('3%'), fontWeight: '700' },
  popRoute: { color: '#fff', fontSize: wp('4.5%'), fontWeight: 'bold' },
  popPrice: { color: '#eee', fontSize: wp('3.6%'), marginTop: hp('0.3%') },

  // Testimonials
  testimonialCard: { width: wp('60%'), backgroundColor: CARD, borderRadius: 16, padding: wp('4%'), marginRight: wp('4%'), elevation: 3 },
  testAvatar: { width: wp('12%'), height: wp('12%'), borderRadius: wp('6%'), marginBottom: hp('1%') },
  testName: { fontSize: wp('3.8%'), fontWeight: '600', color: TEXT_PRIMARY },
  testText: { fontSize: wp('3.4%'), color: TEXT_SECONDARY, marginTop: hp('0.5%') },

  // Safety Tips
  tipsGrid: { flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'space-between' },
  tipBox: { width: wp('44%'), backgroundColor: CARD, borderRadius: 14, padding: wp('4%'), alignItems: 'center', marginBottom: hp('2%'), elevation: 2 },
  tipText: { marginTop: hp('1%'), fontSize: wp('3.6%'), color: TEXT_PRIMARY, textAlign: 'center' },

  // FAB
  fab: { position: 'absolute', bottom: hp('10%'), alignSelf: 'center' },
  fabBtn: { backgroundColor: BRAND_TEAL, flexDirection: 'row', alignItems: 'center', paddingHorizontal: wp('6%'), paddingVertical: hp('1.8%'), borderRadius: 40, elevation: 8 },
  fabTxt: { color: '#fff', fontSize: wp('4.2%'), fontWeight: 'bold', marginLeft: wp('2%') },

  // Bottom Nav
  bottomNav: { flexDirection: 'row', backgroundColor: CARD, paddingVertical: hp('1.5%'), justifyContent: 'space-around', borderTopWidth: 1, borderTopColor: '#eee', position: 'absolute', bottom: 0, left: 0, right: 0, paddingBottom: Platform.OS === 'ios' ? hp('4%') : hp('1.5%') },
  navActive: { alignItems: 'center' },
  navItem: { alignItems: 'center' },
  navActiveTxt: { color: BRAND_TEAL, fontSize: wp('3%'), marginTop: hp('0.4%'), fontWeight: '700' },
  navTxt: { color: TEXT_SECONDARY, fontSize: wp('3%'), marginTop: hp('0.4%') },

  // Modal
  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.7)', justifyContent: 'flex-end' },
  modalSheet: { backgroundColor: CARD, borderTopLeftRadius: 30, borderTopRightRadius: 30, padding: wp('6%'), maxHeight: hp('85%') },
  modalHead: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: hp('2%') },
  modalTitle: { fontSize: wp('5.5%'), fontWeight: 'bold', color: TEXT_PRIMARY },
  modalSub: { fontSize: wp('3.8%'), color: TEXT_SECONDARY, marginTop: hp('0.5%') },
  inputGroup: { marginBottom: hp('2.5%') },
  label: { fontSize: wp('3.8%'), fontWeight: '600', color: TEXT_PRIMARY, marginBottom: hp('1%') },
  inputRow: { flexDirection: 'row', alignItems: 'center', borderWidth: 1, borderColor: '#ddd', borderRadius: 12, backgroundColor: '#f9f9f9', paddingHorizontal: wp('3%') },
  input: { flex: 1, paddingVertical: hp('1.8%'), fontSize: wp('4%'), color: TEXT_PRIMARY },
  dropdown: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', borderWidth: 1, borderColor: '#ddd', borderRadius: 12, padding: wp('4%'), backgroundColor: '#f9f9f9' },
  dropdownTxt: { fontSize: wp('4%'), color: TEXT_PRIMARY },
  dateBtn: { flexDirection: 'row', alignItems: 'center', borderWidth: 1, borderColor: BRAND_TEAL, borderRadius: 12, padding: wp('4%'), backgroundColor: BRAND_TEAL + '10' },
  dateTxt: { marginLeft: wp('2%'), fontSize: wp('4%'), color: TEXT_PRIMARY, fontWeight: '600' },
  postBtn: { backgroundColor: BRAND_TEAL, paddingVertical: hp('2.2%'), borderRadius: 16, alignItems: 'center', marginTop: hp('1%') },
  postBtnTxt: { color: '#fff', fontSize: wp('4.5%'), fontWeight: 'bold' },

  // Story Modal
  storyOverlay: { flex: 1, backgroundColor: '#000', justifyContent: 'center' },
  progressContainer: { flexDirection: 'row', position: 'absolute', top: Platform.select({ ios: hp('7%'), android: (StatusBar.currentHeight ?? 0) + hp('2%') }), left: wp('4%'), right: wp('4%') },
  progressBar: { flex: 1, height: 3, backgroundColor: 'rgba(255,255,255,0.3)', marginHorizontal: 2, borderRadius: 2, overflow: 'hidden' },
  progressFill: { height: '100%', backgroundColor: '#fff' },
  filled: { backgroundColor: '#fff' },
  storyTop: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', position: 'absolute', top: Platform.select({ ios: hp('7%'), android: (StatusBar.currentHeight ?? 0) + hp('2%') }), left: wp('4%'), right: wp('4%') },
  storyUserRow: { flexDirection: 'row', alignItems: 'center' },
  storyAvatar: { width: wp('8%'), height: wp('8%'), borderRadius: wp('4%'), marginRight: wp('2%') },
  storyUser: { color: '#fff', fontWeight: 'bold', fontSize: wp('3.8%') },
  storyTitle: { position: 'absolute', bottom: hp('12%'), left: wp('6%'), right: wp('6%'), color: '#fff', fontSize: wp('6%'), fontWeight: '900', textAlign: 'center' },
  storyHalf: { flex: 1 },
// Add these styles to your StyleSheet:

howItWorksContainer: {
  marginTop: hp('2%'),
  paddingHorizontal: wp('2%'),
},

howStepCard: {
  flexDirection: 'row',
  alignItems: 'flex-start',
  marginBottom: hp('3%'),
  position: 'relative',
},

stepNumberCircle: {
  width: wp('10%'),
  height: wp('10%'),
  borderRadius: wp('5%'),
  justifyContent: 'center',
  alignItems: 'center',
  marginRight: wp('4%'),
  zIndex: 2,
  elevation: 5,
  shadowColor: '#09B368',
  shadowOffset: { width: 0, height: 4 },
  shadowOpacity: 0.3,
  shadowRadius: 8,
},

stepNumber: {
  color: '#FFF',
  fontSize: wp('4.5%'),
  fontWeight: 'bold',
},

stepContent: {
  flex: 1,
  backgroundColor: CARD,
  padding: wp('3%'),
  borderRadius: 12,
  elevation: 4,
  shadowColor: '#000',
  shadowOffset: { width: 0, height: 2 },
  shadowOpacity: 0.1,
  shadowRadius: 12,
  borderWidth: 1,
  borderColor: '#f0f0f0',
},

stepIconTitleRow: {
  flexDirection: 'row',
  alignItems: 'center',
  gap: wp('3%'),
},
stepIconContainer: {
  width: wp('10%'),
  height: wp('10%'),
  borderRadius: wp('6%'),
  backgroundColor: 'rgba(9, 179, 104, 0.1)',
  justifyContent: 'center',
  alignItems: 'center',
  
},

stepTitle: {
  fontSize: wp('4.2%'),
  fontWeight: '700',
  color: TEXT_PRIMARY,

},

stepDescription: {
  marginTop: hp('1%'),
  fontSize: wp('3.6%'),
  color: TEXT_SECONDARY,
  lineHeight: hp('2.5%'),
},

connectingLine: {
  position: 'absolute',
  top: wp('10%'),
  left: wp('4.5%'),
  width: 2,
  height: '120%',
  backgroundColor: 'rgba(9, 179, 104, 0.2)',
  zIndex: 1,
},

getStartedButton: {
  marginTop: hp('3%'),
  borderRadius: 16,
  overflow: 'hidden',
  elevation: 6,
  shadowColor: '#09B368',
  shadowOffset: { width: 0, height: 4 },
  shadowOpacity: 0.3,
  shadowRadius: 8,
},

gradientButton: {
  flexDirection: 'row',
  alignItems: 'center',
  justifyContent: 'center',
  paddingVertical: hp('2.2%'),
  paddingHorizontal: wp('6%'),
},
skeletonPulse: {
  backgroundColor: '#ddd',
  opacity: 0.4,
  borderRadius: 6,
},
});