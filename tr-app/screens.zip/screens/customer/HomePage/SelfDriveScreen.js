

import React, { useEffect, useState, useRef } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  ScrollView,
  StyleSheet,
  SafeAreaView,
  Platform,
  ActivityIndicator,
  Image,
} from 'react-native';
import Icon from 'react-native-vector-icons/Feather';
import Ionicons from 'react-native-vector-icons/Ionicons';
import axios from 'axios';
import AsyncStorage from '@react-native-async-storage/async-storage';
import DateTimePicker from '@react-native-community/datetimepicker';
import { useNavigation } from '@react-navigation/native';

const BG = '#F5F5F7';
const GREEN = '#09B368';

const transmissions = [
  { id: 'automatic', name: 'Automatic', sub: 'Easy to drive' },
  { id: 'manual', name: 'Manual', sub: 'Performance, control' },
];

const vehicleTypes = [
  { id: '1', name: 'Hatchback', sub: 'City & daily',   icon: require('../../../assets/hatchback.png') },
  { id: '2', name: 'Sedan',     sub: 'Comfort rides',  icon: require('../../../assets/sedan.png') },
  { id: '3', name: 'MUV',       sub: 'Group / family', icon: require('../../../assets/muv.png') },
  { id: '4', name: 'SUV',       sub: 'Highway / trips',icon: require('../../../assets/suv.png') },
];

const fuelTypes = [
  { id: 'diesel',   name: 'Diesel' },
  { id: 'petrol',   name: 'Petrol' },
  { id: 'electric', name: 'Electric' },
  { id: 'cng',      name: 'CNG' },
];

// ✅ Doorstep options exactly as you wanted
// keep your visual options as-is
const Doorstep = [
  { id: '1', label: 'Yes', icon: require('../../../assets/Yes.png') },
  { id: '2', label: 'No',  icon: require('../../../assets/No.png') },
];

 const DOORSTEP_MAP = { '1': 1, '2': 0 }; // Map UI ids ('1'|'2') to API values (1|0) const DOORSTEP_MAP = { '1': 1, '2': 0 };

// Map UI codes to API IDs
const TRANS_IDS = { automatic: 1, manual: 2 };
const FUEL_IDS  = { diesel: 1, petrol: 2, electric: 3, cng: 4 };

const faqList = [
  { q: 'Do I need to pay deposit?', a: 'Some vendors may ask for a refundable security deposit depending on the car.' },
  { q: 'Can I get it delivered?',   a: 'Yes, turn ON doorstep and vendor will call you for exact address.' },
  { q: 'Can I take it outstation?', a: 'Mention it in “other details”, vendor will quote accordingly.' },
];

export default function SelfDriveBookingScreen() {
  const navigation = useNavigation();

  // remote data
  const [allLocations, setAllLocations] = useState([]);
  const [query, setQuery] = useState('');
  const [showSuggestions, setShowSuggestions] = useState(false);

  // form
  const [pickupLocation, setPickupLocation] = useState('');
  const [pickupLocationId, setPickupLocationId] = useState(null);
  const [destination, setDestination] = useState('');
  const [selectedTransmission, setSelectedTransmission] = useState('automatic');
  const [selectedVehicleType, setSelectedVehicleType] = useState('1'); // '1' hatchback by default
  const [selectedFuel, setSelectedFuel] = useState('diesel');
  const [selectedDoorstep, setSelectedDoorstep] = useState('2'); // '1' = Yes, '2' = No (default No)
  const [passengers, setPassengers] = useState('4');
  const [otherDetails, setOtherDetails] = useState('');

  // dates
  const [startDate, setStartDate] = useState(new Date());
  const [returnDate, setReturnDate] = useState(new Date(Date.now() + 2 * 60 * 60 * 1000));

  // android date picker
  const [androidPickerVisible, setAndroidPickerVisible] = useState(false);
  const [androidPickerMode, setAndroidPickerMode] = useState('date');
  const [androidPickingTarget, setAndroidPickingTarget] = useState('start');

  // ios pickers
  const [showStartPickerIOS, setShowStartPickerIOS] = useState(false);
  const [showReturnPickerIOS, setShowReturnPickerIOS] = useState(false);

  const [expandedFaq, setExpandedFaq] = useState(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => { fetchLocations(); }, []);

  const fetchLocations = async () => {
    try {
      const res = await axios.get('https://app.transrentals.in/api/locations', { timeout: 5000 });
      if (res.data?.status) setAllLocations(res.data.locations);
    } catch (error) {
      console.log('Error fetching locations:', error?.response?.data || error);
    }
  };

  const textSafe = (t) => (t || '').toLowerCase();

  const filteredLocations = query.length
    ? allLocations.filter(
        (l) => typeof l.name === 'string' && l.name.toLowerCase().includes(textSafe(query)),
      )
    : allLocations.slice(0, 35);

  const handleInputChange = (text) => {
    setQuery(text);
    setPickupLocation(text);
    setPickupLocationId(null);
    setShowSuggestions(true);
  };

  const handleLocationSelect = (loc) => {
    setPickupLocation(loc.name);
    setPickupLocationId(loc.id);
    setQuery('');
    setShowSuggestions(false);
  };

  // ANDROID date flow
  const openAndroidPicker = (target) => {
    setAndroidPickingTarget(target);
    setAndroidPickerMode('date');
    setAndroidPickerVisible(true);
  };

  const onAndroidChange = (event, selected) => {
    if (event.type === 'dismissed') {
      setAndroidPickerVisible(false);
      return;
    }
    if (!selected) {
      setAndroidPickerVisible(false);
      return;
    }

    if (androidPickerMode === 'date') {
      if (androidPickingTarget === 'start') {
        const newStart = new Date(selected);
        const merged = new Date(
          newStart.getFullYear(),
          newStart.getMonth(),
          newStart.getDate(),
          startDate.getHours(),
          startDate.getMinutes(),
        );
        setStartDate(merged);
        if (returnDate < merged) setReturnDate(new Date(merged.getTime() + 2 * 60 * 60 * 1000));
      } else {
        const newEnd = new Date(selected);
        const merged = new Date(
          newEnd.getFullYear(),
          newEnd.getMonth(),
          newEnd.getDate(),
          returnDate.getHours(),
          returnDate.getMinutes(),
        );
        setReturnDate(merged);
      }
      setAndroidPickerMode('time');
      setAndroidPickerVisible(true);
      return;
    }

    if (androidPickerMode === 'time') {
      if (androidPickingTarget === 'start') {
        const upd = new Date(startDate);
        upd.setHours(selected.getHours());
        upd.setMinutes(selected.getMinutes());
        setStartDate(upd);
        if (returnDate < upd) setReturnDate(new Date(upd.getTime() + 2 * 60 * 60 * 1000));
      } else {
        const upd = new Date(returnDate);
        upd.setHours(selected.getHours());
        upd.setMinutes(selected.getMinutes());
        setReturnDate(upd);
      }
      setAndroidPickerVisible(false);
    }
  };

  const popularSelfDrive = [
    { id: '1', name: 'Mahindra Thar', image: require('../../../assets/MahindraThar.png') },
    { id: '2', name: 'Fortuner',      image: require('../../../assets/Fortuner.png') },
    { id: '3', name: 'Audi A4',       image: require('../../../assets/AudiA4.png') },
    { id: '4', name: 'Willys Jeep',   image: require('../../../assets/Willysjee.png') },
  ];

  // submit
  const handleSubmit = async () => {
    // basic validations
    if (!pickupLocation) {
      alert('Please select pickup city');
      return;
    }
    const pax = parseInt(passengers, 10);
    if (isNaN(pax) || pax <= 0) {
      alert('Please enter a valid number of passengers');
      return;
    }
    if (returnDate <= startDate) {
      alert('Return time must be after start time');
      return;
    }

    setIsSubmitting(true);
    try {
      const customerId = await AsyncStorage.getItem('customer_id');
      const token = await AsyncStorage.getItem('token');

      // resolve location id if user typed full city name
      let finalLocationId = pickupLocationId;
      if (!finalLocationId && pickupLocation) {
        const match = allLocations.find(
          (l) => l.name?.toLowerCase() === pickupLocation?.toLowerCase(),
        );
        if (match) finalLocationId = match.id;
      }

      if (!finalLocationId) {
        alert('Please pick a city from the suggestions.');
        setIsSubmitting(false);
        return;
      }

      // map selections to API IDs
      const transmissionId = TRANS_IDS[selectedTransmission] || 1;
      const fuelId = FUEL_IDS[selectedFuel] || 1;
      const carTypeId = parseInt(String(selectedVehicleType), 10) || 1;

      // ✅ Send exactly 1 or 2 as backend expects
 

      const payload = {
        customer_id: customerId,
        service_id: 2,
        service_name: 'Selfdrive Car',
        location_id: finalLocationId,
        location_name: pickupLocation,
        destination: destination?.trim() || '',
        journey_datetime: startDate.toISOString(),
        return_datetime: returnDate.toISOString(),
        car_type: carTypeId,
        transmission: transmissionId,
        fuel_type: fuelId,
    is_doorstep_delivery: selectedDoorstep === '1' ? '1' : '0', // <-- fixed
        total_passangers: pax,
        other_info: otherDetails?.trim() || '',
      };
console.log('selfdrive payload', payload);
console.log('Sending is_doorstep_delivery:', payload.is_doorstep_delivery, typeof payload.is_doorstep_delivery);
// Should log: "Sending is_doorstep_delivery: '1' string"


      const res = await axios.post(
        'https://app.transrentals.in/api/store-selfdrive-booking',
        payload,
        {
          headers: {
            ...(token ? { Authorization: `Bearer ${token}` } : {}),
            Accept: 'application/json',
          },
        },
      );

      if (res.data?.status) {
        navigation.navigate('BookingConfirmation');
      } else {
        alert(res.data?.message || 'Could not submit booking, please check fields.');
      }
    } catch (err) {
      console.log('selfdrive submit err', err?.response?.data || err);
      alert(err?.response?.data?.message || 'Something went wrong. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const dropdownTouching = useRef(false);

  return (
    <SafeAreaView style={styles.safe}>
      {/* top bar */}
      <View style={styles.topBar}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backBtn}>
          <Icon name="arrow-left" size={22} color="#0F172A" />
        </TouchableOpacity>
        <Text style={styles.topTitle}>Self Drive Car</Text>
        <View style={{ width: 40 }} />
      </View>

      <ScrollView
        showsVerticalScrollIndicator={false}
        nestedScrollEnabled
        keyboardShouldPersistTaps="handled"
        onScrollBeginDrag={() => {
          if (!dropdownTouching.current) setShowSuggestions(false);
        }}
      >
        {/* FORM CARD */}
        <View style={styles.formCard}>
          <View style={styles.formHeaderRow}>
            <View>
              <Text style={styles.formTitle}>Book self drive car</Text>
              <Text style={styles.formDesc}>Fill once, vendors will send quotes.</Text>
            </View>
            <View style={styles.securePill}>
              <Ionicons name="car" size={14} color="#fff" />
              <Text style={styles.securePillText}>Instant</Text>
            </View>
          </View>

          {/* LOCATION BLOCK */}
          <View style={styles.locationBlock}>
            <Text style={styles.smallLabel}>Pickup city / hub</Text>
            <View style={styles.locationRow}>
              <Ionicons name="location-outline" size={18} color="#0F172A" />
              <TextInput
                value={query.length ? query : pickupLocation}
                onChangeText={handleInputChange}
                placeholder="Enter pickup city"
                placeholderTextColor="#94A3B8"
                style={styles.locationInput}
                onFocus={() => setShowSuggestions(true)}
                onBlur={() => setTimeout(() => setShowSuggestions(false), 150)}
              />
              {pickupLocation ? (
                <TouchableOpacity
                  onPress={() => {
                    setPickupLocation('');
                    setPickupLocationId(null);
                    setQuery('');
                    setShowSuggestions(false);
                  }}
                >
                  <Ionicons name="close-circle" size={22} color="#CBD5F5" />
                </TouchableOpacity>
              ) : null}
            </View>

            {/* suggestions */}
            {showSuggestions && (
              <View style={styles.suggestionBox}>
                <ScrollView
                  style={{ maxHeight: 210 }}
                  nestedScrollEnabled
                  keyboardShouldPersistTaps="always"
                  onTouchStart={() => (dropdownTouching.current = true)}
                  onTouchEnd={() => (dropdownTouching.current = false)}
                >
                  {filteredLocations.length ? (
                    filteredLocations.map((loc) => (
                      <TouchableOpacity
                        key={loc.id}
                        style={styles.suggestionItem}
                        onPress={() => handleLocationSelect(loc)}
                      >
                        <Text style={styles.suggestionText}>{loc.name}</Text>
                      </TouchableOpacity>
                    ))
                  ) : (
                    <Text style={styles.noResult}>No location found</Text>
                  )}
                </ScrollView>
              </View>
            )}

            {/* destination */}
            <Text style={[styles.smallLabel, { marginTop: 14 }]}>
              Drop / where will you go? (optional)
            </Text>
            <View style={styles.locationRow}>
              <Ionicons name="flag-outline" size={18} color="#0F172A" />
              <TextInput
                value={destination}
                onChangeText={setDestination}
                placeholder="Airport, hotel, office…"
                placeholderTextColor="#94A3B8"
                style={styles.locationInput}
              />
            </View>
          </View>

          {/* DATES */}
          <View style={styles.dateRow}>
            {/* START */}
            <TouchableOpacity
              style={styles.dateCard}
              onPress={() => {
                if (Platform.OS === 'android') openAndroidPicker('start');
                else setShowStartPickerIOS(true);
              }}
            >
              <Text style={styles.dateLabel}>START</Text>
              <View style={styles.dateContent}>
                <View style={styles.dateIconWrap}>
                  <Ionicons name="calendar-outline" size={16} color="#0F172A" />
                </View>
                <View style={{ flex: 1 }}>
                  <Text style={styles.dateMainText}>
                    {startDate.toLocaleDateString('en-US', {
                      day: '2-digit',
                      month: 'short',
                      year: 'numeric',
                    })}
                  </Text>
                  <Text style={styles.dateSubText}>
                    {startDate.toLocaleTimeString('en-US', {
                      hour: '2-digit',
                      minute: '2-digit',
                    })}
                  </Text>
                </View>
              </View>
            </TouchableOpacity>

            {/* END */}
            <TouchableOpacity
              style={styles.dateCard}
              onPress={() => {
                if (Platform.OS === 'android') openAndroidPicker('end');
                else setShowReturnPickerIOS(true);
              }}
            >
              <Text style={styles.dateLabel}>RETURN</Text>
              <View style={styles.dateContent}>
                <View style={styles.dateIconWrap}>
                  <Ionicons name="calendar-outline" size={16} color="#0F172A" />
                </View>
                <View style={{ flex: 1 }}>
                  <Text style={styles.dateMainText}>
                    {returnDate.toLocaleDateString('en-US', {
                      day: '2-digit',
                      month: 'short',
                      year: 'numeric',
                    })}
                  </Text>
                  <Text style={styles.dateSubText}>
                    {returnDate.toLocaleTimeString('en-US', {
                      hour: '2-digit',
                      minute: '2-digit',
                    })}
                  </Text>
                </View>
              </View>
            </TouchableOpacity>
          </View>

          {/* iOS pickers */}
          {showStartPickerIOS && Platform.OS === 'ios' && (
            <View style={styles.iosDatePickerContainer}>
              <DateTimePicker
                value={startDate}
                mode="datetime"
                display="spinner"
                onChange={(e, d) => {
                  if (!d) return;
                  setStartDate(d);
                  if (returnDate < d) {
                    setReturnDate(new Date(d.getTime() + 2 * 60 * 60 * 1000));
                  }
                }}
                minimumDate={new Date()}
              />
              <View style={styles.iosButtonContainer}>
                <TouchableOpacity style={styles.iosButton} onPress={() => setShowStartPickerIOS(false)}>
                  <Text style={styles.iosButtonText}>Done</Text>
                </TouchableOpacity>
              </View>
            </View>
          )}

          {showReturnPickerIOS && Platform.OS === 'ios' && (
            <View style={styles.iosDatePickerContainer}>
              <DateTimePicker
                value={returnDate}
                mode="datetime"
                display="spinner"
                onChange={(e, d) => {
                  if (!d) return;
                  setReturnDate(d);
                }}
                minimumDate={startDate}
              />
              <View style={styles.iosButtonContainer}>
                <TouchableOpacity style={styles.iosButton} onPress={() => setShowReturnPickerIOS(false)}>
                  <Text style={styles.iosButtonText}>Done</Text>
                </TouchableOpacity>
              </View>
            </View>
          )}

          {/* TRANSMISSION */}
          <View style={{ marginTop: 16 }}>
            <View style={styles.rowHead}>
              <Text style={styles.label}>Transmission</Text>
              <Text style={styles.labelHint}>Pick what you prefer</Text>
            </View>
            <View style={styles.pillWrap}>
              {transmissions.map((t) => {
                const active = selectedTransmission === t.id;
                return (
                  <TouchableOpacity
                    key={t.id}
                    onPress={() => setSelectedTransmission(t.id)}
                    style={[styles.pill, active && styles.pillActive]}
                    activeOpacity={0.75}
                  >
                    <Text style={[styles.pillText, active && styles.pillTextActive]}>
                      {t.name}
                    </Text>
                  </TouchableOpacity>
                );
              })}
            </View>
          </View>

          {/* VEHICLE TYPE — HORIZONTAL */}
          <View style={{ marginTop: 18 }}>
            <View style={styles.rowHead}>
              <Text style={styles.label}>Vehicle type</Text>
              <Text style={styles.labelHint}>City, trip or family</Text>
            </View>
            <ScrollView
              horizontal
              showsHorizontalScrollIndicator={false}
              style={{ marginHorizontal: -16, paddingHorizontal: 16 }}
              contentContainerStyle={{ gap: 12 }}
            >
              {vehicleTypes.map((v) => {
                const active = selectedVehicleType === v.id;
                return (
                  <TouchableOpacity
                    key={v.id}
                    onPress={() => setSelectedVehicleType(v.id)}
                    style={[styles.vCardH, active && styles.vCardHActive]}
                    activeOpacity={0.8}
                  >
                    <View style={styles.vIconH}>
                      <Image source={v.icon} style={{ width: 34, height: 34, resizeMode: 'contain' }} />
                    </View>
                    <View style={{ flex: 1 }}>
                      <Text style={[styles.vNameH, active && styles.vNameHActive]}>{v.name}</Text>
                      <Text style={[styles.vSubH, active && styles.vSubHActive]}>{v.sub}</Text>
                    </View>
                    {active ? (
                      <Ionicons name="checkmark-circle" size={20} color={GREEN} />
                    ) : (
                      <Ionicons name="chevron-forward" size={18} color="#94A3B8" />
                    )}
                  </TouchableOpacity>
                );
              })}
            </ScrollView>
          </View>

          {/* FUEL TYPE */}
          <View style={{ marginTop: 18 }}>
            <View style={styles.rowHead}>
              <Text style={styles.label}>Fuel type</Text>
              <Text style={styles.labelHint}>Tell vendor your need</Text>
            </View>
            <View style={styles.segment}>
              {fuelTypes.map((f, idx) => {
                const active = selectedFuel === f.id;
                return (
                  <TouchableOpacity
                    key={f.id}
                    onPress={() => setSelectedFuel(f.id)}
                    style={[
                      styles.segmentItem,
                      active && styles.segmentItemActive,
                      idx === 0 && { borderTopLeftRadius: 12, borderBottomLeftRadius: 12 },
                      idx === fuelTypes.length - 1 && { borderTopRightRadius: 12, borderBottomRightRadius: 12 },
                    ]}
                    activeOpacity={0.8}
                  >
                    <Text style={[styles.segmentText, active && styles.segmentTextActive]}>{f.name}</Text>
                  </TouchableOpacity>
                );
              })}
            </View>
          </View>

          {/* ✅ DOORSTEP DELIVERY (icons + sends 1/2) */}
          <View style={{ marginTop: 18 }}>
            <View style={styles.rowHead}>
              <Text style={styles.label}>Doorstep delivery</Text>
              <Text style={styles.labelHint}>Get car delivered to you</Text>
            </View>
            <View style={styles.doorRow}>
              {Doorstep.map((d) => {
                const active = selectedDoorstep === d.id;
                return (
                  <TouchableOpacity
                    key={d.id}
                    style={[styles.doorCard, active && styles.doorCardActive]}
                    onPress={() => setSelectedDoorstep(d.id)}
                    activeOpacity={0.85}
                  >
                    <View style={styles.doorIcon}>
                      <Image source={d.icon} style={{ width: 28, height: 28, resizeMode: 'contain' }} />
                    </View>
                    <Text style={[styles.doorTitle, active && styles.doorTitleActive]}>{d.label}</Text>
                    <Text style={[styles.doorSub, active && styles.doorSubActive]}>
                      {d.id === '1' ? 'Vendor will call for address' : 'I’ll pick from hub'}
                    </Text>
                  </TouchableOpacity>
                );
              })}
            </View>
          </View>

          {/* PASSENGERS */}
          <View style={{ marginTop: 18 }}>
            <View style={styles.rowHead}>
              <Text style={styles.label}>Passengers</Text>
              <Text style={styles.labelHint}>How many people?</Text>
            </View>
            <View style={styles.locationRow}>
              <Ionicons name="people-outline" size={18} color="#0F172A" />
              <TextInput
                value={String(passengers)}
                onChangeText={setPassengers}
                placeholder="e.g., 4"
                placeholderTextColor="#94A3B8"
                style={styles.locationInput}
                keyboardType="numeric"
              />
            </View>
          </View>

          {/* OTHER DETAILS */}
          <Text style={[styles.label, { marginTop: 18 }]}>Other details (duration, special request…)</Text>
          <TextInput
            style={styles.textArea}
            value={otherDetails}
            onChangeText={setOtherDetails}
            multiline
            placeholder="Example: need 3 days, pick from Navrangpura, 2 drivers visiting…"
            placeholderTextColor="#9CA3AF"
          />

          {/* SUBMIT */}
          <TouchableOpacity
            style={[styles.submitBtn, isSubmitting && { opacity: 0.4 }]}
            onPress={handleSubmit}
            disabled={isSubmitting}
          >
            {isSubmitting ? <ActivityIndicator color="#fff" /> : <Text style={styles.submitText}>Submit booking</Text>}
          </TouchableOpacity>
        </View>

        {/* POPULAR SELF DRIVE CARS */}
        <View style={styles.groupCard}>
          <Text style={styles.sectionTitleInside}>Popular self drive cars</Text>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: 10 }}>
            {popularSelfDrive.map((c) => (
              <View key={c.id} style={styles.luxuryCard}>
                <Image source={c.image} style={styles.luxuryImg} />
                <Text style={styles.luxuryName}>{c.name}</Text>
              </View>
            ))}
          </ScrollView>
        </View>

        {/* POPULAR CITIES */}
        <View style={styles.groupCard}>
          <Text style={styles.sectionTitleInside}>Popular cities</Text>
          <View style={styles.cityWrap}>
            {['Ahmedabad', 'Bangalore', 'Mumbai', 'Udaipur', 'Jaipur', 'Goa', 'Hyderabad', 'Delhi', 'Pune'].map(
              (c, i) => (
                <View key={i} style={styles.cityChip}>
                  <Ionicons name="location-outline" size={14} color={GREEN} />
                  <Text style={styles.cityText}>{c}</Text>
                </View>
              ),
            )}
          </View>
        </View>

        {/* FAQ DARK */}
        <View style={styles.faqSec}>
          <Text style={styles.faqTitle}>FAQs about self drive cars</Text>
          {faqList.map((f, idx) => {
            const open = expandedFaq === idx;
            return (
              <View key={idx} style={styles.faqItem}>
                <TouchableOpacity style={styles.faqHead} onPress={() => setExpandedFaq(open ? null : idx)}>
                  <Text style={styles.faqQ}>{f.q}</Text>
                  <Ionicons name={open ? 'chevron-up' : 'chevron-down'} size={18} color="#E2E8F0" />
                </TouchableOpacity>
                {open ? <Text style={styles.faqA}>{f.a}</Text> : null}
              </View>
            );
          })}
        </View>
      </ScrollView>

      {/* ANDROID PICKER */}
      {androidPickerVisible && Platform.OS === 'android' && (
        <DateTimePicker
          value={androidPickingTarget === 'start' ? startDate : returnDate}
          mode={androidPickerMode}
          display="default"
          onChange={onAndroidChange}
          minimumDate={androidPickingTarget === 'start' ? new Date() : startDate}
        />
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: BG },
  container: { backgroundColor: 'transparent' },

  topBar: {
    height: 52,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    backgroundColor: BG,
  },
  backBtn: {
    width: 40,
    height: 40,
    borderRadius: 999,
    backgroundColor: '#FFFFFF',
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOpacity: 0.03,
    shadowRadius: 8,
    shadowOffset: { width: 0, height: 3 },
  },
  topTitle: { fontSize: 17, fontWeight: '700', color: '#0F172A' },

  formCard: {
    backgroundColor: '#FFFFFF',
    marginHorizontal: 14,
    borderRadius: 22,
    paddingVertical: 12,
    paddingHorizontal: 16,
    shadowColor: '#000',
    shadowOpacity: 0.04,
    shadowRadius: 14,
    shadowOffset: { width: 0, height: 6 },
    marginTop: 10,
  },
  formHeaderRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 10,
    alignItems: 'center',
  },
  formTitle: { fontSize: 18, fontWeight: '700', color: '#0F172A' },
  formDesc: { fontSize: 12, color: '#94A3B8', marginTop: 2 },
  securePill: {
    backgroundColor: GREEN,
    borderRadius: 999,
    paddingHorizontal: 10,
    paddingVertical: 4,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  securePillText: { color: '#fff', fontSize: 12, fontWeight: '600' },

  locationBlock: {
    backgroundColor: '#F8FAFC',
    borderRadius: 16,
    borderWidth: 1,
    borderColor: 'rgba(15,23,42,0.04)',
    padding: 12,
    marginBottom: 12,
  },
  smallLabel: { fontSize: 11.5, color: '#94A3B8', marginBottom: 4 },
  locationRow: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    borderWidth: 1,
    borderColor: 'rgba(148,163,184,0.25)',
    paddingHorizontal: 12,
    minHeight: 54,
    gap: 8,
  },
  locationInput: { flex: 1, fontSize: 15, color: '#0F172A', paddingVertical: 6 },

  suggestionBox: {
    position: 'absolute',
    top: 100,
    left: 0,
    right: 0,
    backgroundColor: '#FFFFFF',
    borderRadius: 14,
    borderWidth: 0.6,
    borderColor: '#E2E8F0',
    zIndex: 99,
    elevation: 10,
  },
  suggestionItem: { paddingHorizontal: 12, paddingVertical: 9, borderBottomWidth: 0.4, borderColor: '#EDF2F7' },
  suggestionText: { color: '#0F172A' },
  noResult: { padding: 10, textAlign: 'center', color: '#94A3B8' },

  dateRow: { flexDirection: 'row', gap: 12 },
  dateCard: {
    flex: 1,
    backgroundColor: '#FFFFFF',
    borderRadius: 14,
    borderWidth: 1,
    borderColor: 'rgba(148,163,184,0.25)',
    paddingHorizontal: 12,
    paddingVertical: 8,
  },
  dateLabel: {
    fontSize: 12,
    fontWeight: '600',
    color: '#94A3B8',
    textTransform: 'uppercase',
    marginBottom: 6,
  },
  dateContent: { flexDirection: 'row', gap: 8, alignItems: 'center' },
  dateIconWrap: { width: 30, height: 30, borderRadius: 10, backgroundColor: '#F1F5F9', justifyContent: 'center', alignItems: 'center' },
  dateMainText: { fontSize: 14, fontWeight: '700', color: '#0F172A' },
  dateSubText: { fontSize: 11, color: '#94A3B8' },
  iosDatePickerContainer: {
    backgroundColor: '#fff',
    borderRadius: 12,
    marginTop: 8,
    padding: 10,
    shadowColor: '#000',
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  iosButtonContainer: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
    paddingTop: 8,
    marginTop: 8,
    borderTopWidth: 1,
    borderTopColor: '#f0f0f0',
  },
  iosButton: { backgroundColor: GREEN, paddingHorizontal: 14, paddingVertical: 6, borderRadius: 6 },
  iosButtonText: { color: '#fff', fontWeight: '600' },

  rowHead: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 6 },
  label: { fontSize: 15, fontWeight: '700', color: '#0F172A' },
  labelHint: { fontSize: 11, color: '#94A3B8' },

  // transmission pills
  pillWrap: { flexDirection: 'row', gap: 8, flexWrap: 'wrap' },
  pill: { paddingHorizontal: 14, paddingVertical: 8, backgroundColor: '#EDF2F7', borderRadius: 999, borderWidth: 1, borderColor: 'transparent' },
  pillActive: { backgroundColor: 'rgba(9,179,104,0.14)', borderColor: 'rgba(9,179,104,0.4)' },
  pillText: { color: '#0F172A', fontSize: 13, fontWeight: '500' },
  pillTextActive: { color: '#055F3B' },

  // vehicle horizontal
  vCardH: {
    width: 210,
    backgroundColor: '#F8FAFC',
    borderRadius: 16,
    borderWidth: 1,
    borderColor: 'transparent',
    padding: 12,
    flexDirection: 'row',
    gap: 10,
    alignItems: 'center',
  },
  vCardHActive: {
    backgroundColor: '#FFFFFF',
    borderColor: 'rgba(9,179,104,0.35)',
    shadowColor: '#000',
    shadowOpacity: 0.03,
    shadowRadius: 10,
    shadowOffset: { width: 0, height: 4 },
  },
  vIconH: { width: 44, height: 44, borderRadius: 14, backgroundColor: '#FFFFFF', justifyContent: 'center', alignItems: 'center' },
  vNameH: { fontSize: 14, fontWeight: '600', color: '#0F172A' },
  vNameHActive: { color: '#055F3B' },
  vSubH: { fontSize: 11, color: '#94A3B8' },
  vSubHActive: { color: '#0F172A' },

  // fuel segmented
  segment: { flexDirection: 'row', backgroundColor: '#E2E8F0', borderRadius: 12, overflow: 'hidden' },
  segmentItem: { flex: 1, paddingVertical: 8, justifyContent: 'center', alignItems: 'center' },
  segmentItemActive: { backgroundColor: '#FFFFFF' },
  segmentText: { fontSize: 13, color: '#475569', fontWeight: '500' },
  segmentTextActive: { color: '#055F3B', fontWeight: '600' },

  // doorstep cards
  doorRow: { flexDirection: 'row', gap: 10 },
  doorCard: { flex: 1, backgroundColor: '#F8FAFC', borderRadius: 14, borderWidth: 1, borderColor: 'transparent', padding: 10 },
  doorCardActive: { backgroundColor: '#FFFFFF', borderColor: 'rgba(9,179,104,0.35)' },
  doorIcon: { width: 34, height: 34, borderRadius: 12, backgroundColor: '#FFFFFF', justifyContent: 'center', alignItems: 'center', marginBottom: 6 },
  doorTitle: { fontSize: 14, fontWeight: '600', color: '#0F172A' },
  doorTitleActive: { color: '#055F3B' },
  doorSub: { fontSize: 11.5, color: '#94A3B8', marginTop: 2 },
  doorSubActive: { color: '#0F172A' },

  textArea: {
    backgroundColor: '#F8FAFC',
    borderRadius: 10,
    borderWidth: 1,
    borderColor: 'rgba(15,23,42,0.05)',
    minHeight: 84,
    padding: 10,
    textAlignVertical: 'top',
    fontSize: 12.5,
  },

  submitBtn: { marginTop: 16, backgroundColor: GREEN, borderRadius: 999, paddingVertical: 11, alignItems: 'center', marginBottom: 5 },
  submitText: { color: '#FFFFFF', fontSize: 15, fontWeight: '700' },

  // faq + extras
  faqSec: { backgroundColor: '#0F172A', marginTop: 18, padding: 16, paddingBottom: 26 },
  faqTitle: { fontSize: 18, fontWeight: '700', color: '#FFFFFF', marginBottom: 12 },
  faqItem: { borderBottomColor: 'rgba(226,232,240,0.1)', borderBottomWidth: 1, paddingVertical: 10 },
  faqHead: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  faqQ: { color: '#FFFFFF', fontSize: 14, flex: 1, marginRight: 10 },
  faqA: { color: '#CBD5F5', fontSize: 12.5, marginTop: 6, lineHeight: 18 },

  groupCard: { backgroundColor: '#FFFFFF', marginHorizontal: 14, marginTop: 16, borderRadius: 20, padding: 14 },
  sectionTitleInside: { fontSize: 18, fontWeight: '700', color: '#0F172A', marginBottom: 10 },
  luxuryCard: { width: 120, backgroundColor: '#F8FAFC', borderRadius: 16, padding: 10, alignItems: 'center' },
  luxuryImg: { width: 70, height: 40, resizeMode: 'contain' },
  luxuryName: { marginTop: 6, fontSize: 13, fontWeight: '600', color: '#0F172A', textAlign: 'center' },

  cityWrap: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  cityChip: {
    flexDirection: 'row',
    gap: 4,
    backgroundColor: 'rgba(9,179,104,0.1)',
    borderRadius: 999,
    paddingHorizontal: 12,
    paddingVertical: 5,
    alignItems: 'center',
  },
  cityText: { fontSize: 14, color: '#0F172A', fontWeight: '500' },
});
