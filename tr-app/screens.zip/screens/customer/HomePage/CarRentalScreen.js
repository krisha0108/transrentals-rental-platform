
import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  TouchableOpacity,
  TextInput,
  Image,
  Modal,
  Platform,
  SafeAreaView,
  Dimensions,
  Animated,
  ActivityIndicator,
} from 'react-native';
import Icon from 'react-native-vector-icons/Feather';
import Ionicons from 'react-native-vector-icons/Ionicons';
import { useNavigation } from '@react-navigation/native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import axios from 'axios';
import DateTimePicker from '@react-native-community/datetimepicker';

const { width } = Dimensions.get('window');
const GREEN = '#09B368';
const BG = '#F5F5F7';

// ✅ backend-aligned car types (IDs 1–4)
const CAR_TYPES = [
  { id: '1', name: 'Hatchback', img: require('../../../assets/carrrrr.png') },
  { id: '2', name: 'Sedan',     img: require('../../../assets/7SeaterCarOnRent.png') },
  { id: '3', name: 'MUV',       img: require('../../../assets/InnovaCrystaCarOnRent.png') },
  { id: '4', name: 'SUV',       img: require('../../../assets/InnovaCarOnRent.png') },
];

// airport types = full-width pills below
const AIRPORT_TYPES = [
  { id: 'pickup', label: 'Pickup from Airport', icon: 'airplane-outline' },
  { id: 'drop', label: 'Drop to Airport', icon: 'navigate-outline' },
];

const faqs = [
  {
    question: 'Can I book outstation cab?',
    answer: 'Yes. Choose round trip or one way, select date & we send quotes.',
  },
  {
    question: 'Are drivers included?',
    answer: 'Yes, for Chauffeur-driven cars driver is included. Fuel/toll extra as per quote.',
  },
  {
    question: 'Can I get airport pickup?',
    answer: 'Yes. Select “Airport”, choose pickup/drop, add flight timing in notes.',
  },
  {
    question: 'How do I pay?',
    answer: 'Vendors send quotes → you confirm → pay online / to driver as per quote.',
  },
];

const quoteData = [
  {
    id: '1',
    number: '1',
    heading: 'Enquire',
    body: `Tell us pickup city, trip type (roundtrip/oneway/airport), dates & car type.`,
  },
  {
    id: '2',
    number: '2',
    heading: 'Get Quote',
    body: `Multiple car vendors send you their best price & car options.`,
  },
  {
    id: '3',
    number: '3',
    heading: 'Book',
    body: `Pick one quote, pay booking amount and your car is locked.`,
  },
];

export default function CarRentalScreen() {
  const navigation = useNavigation();

  const [expandedIndex, setExpandedIndex] = useState(null);
  const [activeQuoteIndex, setActiveQuoteIndex] = useState(0);
  const scrollX = useRef(new Animated.Value(0)).current;

  const [customerData, setCustomerData] = useState(null);
  const [allLocations, setAllLocations] = useState([]);
  const [query, setQuery] = useState('');
  const [pickupLocation, setPickupLocation] = useState('');
  const [pickupLocationId, setPickupLocationId] = useState(null);
  const [showSuggestions, setShowSuggestions] = useState(false);

  const [tripType, setTripType] = useState('roundtrip'); // roundtrip | oneway | airport
  const [airportDirection, setAirportDirection] = useState('pickup');
  const [destination, setDestination] = useState('');

  // ✅ Single source of truth for car type (default Sedan -> '2')
  const [carType, setCarType] = useState('2');

  const [totalPassengers, setTotalPassengers] = useState('');
  const [otherDetails, setOtherDetails] = useState('');
  const [isPhoneModal, setIsPhoneModal] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const [startDate, setStartDate] = useState(new Date());
  const [returnDate, setReturnDate] = useState(
    new Date(Date.now() + 4 * 60 * 60 * 1000),
  );

  const [androidPickerVisible, setAndroidPickerVisible] = useState(false);
  const [androidPickerMode, setAndroidPickerMode] = useState('date');
  const [androidPickingTarget, setAndroidPickingTarget] = useState('start');

  const [showStartDatePicker, setShowStartDatePicker] = useState(false);
  const [showReturnDatePicker, setShowReturnDatePicker] = useState(false);

  useEffect(() => {
    (async () => {
      const data = await AsyncStorage.getItem('customer');
      if (data) setCustomerData(JSON.parse(data));
    })();
    fetchLocations();
  }, []);

  const fetchLocations = async () => {
    try {
      const res = await axios.get('https://app.transrentals.in/api/locations', {
        timeout: 5000,
      });
      if (res.data?.status) {
        setAllLocations(res.data.locations);
      }
    } catch (err) {
      console.log('location error', err?.response?.data || err);
    }
  };

  const textSafe = (t) => (t || '').toLowerCase();

  const filteredLocations = query.length
    ? allLocations.filter(
        (l) =>
          typeof l.name === 'string' &&
          l.name.toLowerCase().includes(textSafe(query)),
      )
    : allLocations.slice(0, 35);

  const handleInputChange = (text) => {
    setQuery(text);
    setPickupLocation(text);
    setPickupLocationId(null);
    setShowSuggestions(true);
  };

  const handleLocationSelect = (loc) => {
    setPickupLocation(loc.name);
    setPickupLocationId(loc.id);
    setQuery('');
    setShowSuggestions(false);
  };

  const toggleFAQ = (i) => {
    setExpandedIndex((prev) => (prev === i ? null : i));
  };

  const openAndroidPicker = (target) => {
    setAndroidPickingTarget(target);
    setAndroidPickerMode('date');
    setAndroidPickerVisible(true);
  };

  const onAndroidChange = (event, selected) => {
    if (event.type === 'dismissed') {
      setAndroidPickerVisible(false);
      return;
    }
    if (!selected) {
      setAndroidPickerVisible(false);
      return;
    }

    if (androidPickerMode === 'date') {
      if (androidPickingTarget === 'start') {
        const newStart = new Date(selected);
        const merged = new Date(
          newStart.getFullYear(),
          newStart.getMonth(),
          newStart.getDate(),
          startDate.getHours(),
          startDate.getMinutes(),
        );
        setStartDate(merged);
        if (returnDate < merged) {
          setReturnDate(new Date(merged.getTime() + 4 * 60 * 60 * 1000));
        }
      } else {
        const newEndDate = new Date(selected);
        const merged = new Date(
          newEndDate.getFullYear(),
          newEndDate.getMonth(),
          newEndDate.getDate(),
          returnDate.getHours(),
          returnDate.getMinutes(),
        );
        setReturnDate(merged);
      }
      setAndroidPickerMode('time');
      setAndroidPickerVisible(true);
      return;
    }

    if (androidPickerMode === 'time') {
      if (androidPickingTarget === 'start') {
        const upd = new Date(startDate);
        upd.setHours(selected.getHours());
        upd.setMinutes(selected.getMinutes());
        setStartDate(upd);
        if (returnDate < upd) {
          setReturnDate(new Date(upd.getTime() + 4 * 60 * 60 * 1000));
        }
      } else {
        const upd = new Date(returnDate);
        upd.setHours(selected.getHours());
        upd.setMinutes(selected.getMinutes());
        setReturnDate(upd);
      }
      setAndroidPickerVisible(false);
    }
  };

  const onStartDateChangeIOS = (event, selectedDate) => {
    if (!selectedDate) return;
    setStartDate(selectedDate);
    if (returnDate < selectedDate) {
      setReturnDate(new Date(selectedDate.getTime() + 4 * 60 * 60 * 1000));
    }
  };
  const onReturnDateChangeIOS = (event, selectedDate) => {
    if (!selectedDate) return;
    setReturnDate(selectedDate);
  };

  const handleSubmit = async () => {
    if (!pickupLocation) {
      alert('Please select pickup city');
      return;
    }
    if (tripType !== 'airport' && !destination) {
      alert('Please enter destination');
      return;
    }
    if (tripType === 'airport' && !airportDirection) {
      alert('Please select airport booking type');
      return;
    }
    if (!carType) {
      alert('Please select car type');
      return;
    }
    if (!totalPassengers) {
      alert('Please enter passengers');
      return;
    }

    if (customerData && !customerData.phone) {
      setIsPhoneModal(true);
      return;
    }

    setIsSubmitting(true);
    try {
      const customerId = await AsyncStorage.getItem('customer_id');
      const token = await AsyncStorage.getItem('token');

      // 🔒 Require the user to pick a city from suggestions so we have a real ID and name.
      if (!pickupLocationId) {
        alert('Please pick the pickup city from the suggestions list to attach its ID.');
        setShowSuggestions(true);
        setQuery(pickupLocation || '');
        return;
      }

      // 👉 Map your Car service (adjust if your backend expects a different service)
      const SERVICE_ID = 2;
      const SERVICE_NAME = 'Standard Car';

      // ✅ Backend-aligned payload
      const basePayload = {
        customer_id: customerId ?? '',
        service_id: SERVICE_ID,             // required
        service_name: SERVICE_NAME,         // required
        location_id: pickupLocationId,
        location_name: pickupLocation,      // required
        destination,
        journey_datetime: startDate.toISOString(),
        car_type: String(carType),          // '1' | '2' | '3' | '4'
        total_passangers: Number(totalPassengers), // exact legacy key
        other_info: (otherDetails || '').trim(),
      };

      let url = '';
      let payload = { ...basePayload };

      if (tripType === 'roundtrip') {
        url = 'https://app.transrentals.in/api/store-roundtrip-booking';
        payload.trip_type = 3;
        payload.return_datetime = returnDate.toISOString();
      } else if (tripType === 'oneway') {
        url = 'https://app.transrentals.in/api/store-oneway-booking';
        payload.trip_type = 1;
      } else if (tripType === 'airport') {
        url = 'https://app.transrentals.in/api/store-airport-booking';
        payload.trip_type = 2;
 // map UI value to backend expected value
  const airportMap = {
    pickup: 1, // pickup from airport
    drop: 2,   // drop to airport
  };

  payload.booking_type = airportMap[airportDirection];
}      

      console.log('🚀 Submitting to:', url);
      console.log('🧾 Payload:', payload);

      const res = await axios.post(url, payload, {
        headers: {
          Accept: 'application/json',
          'Content-Type': 'application/json',
          ...(token ? { Authorization: `Bearer ${token}` } : {}),
        },
      });

    if (res.data?.booking_id || res.data?.status) {
  // clear old values
  setDestination('');
  setOtherDetails('');

  // navigate to confirmation screen
  navigation.navigate('BookingConfirmation', {
    booking_id: res.data?.booking_id || 'unknown',
  });
}
else {
        console.log('❌ Backend response:', JSON.stringify(res.data, null, 2));
        alert(res.data?.message || 'Booking could not be submitted. Check required fields.');
      }
    } catch (err) {
      console.log('❌ Booking error:', err?.response?.data || err?.message);
      alert(
        err?.response?.data?.message ||
        'Failed to submit booking. Please try again.'
      );
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleScroll = Animated.event(
    [{ nativeEvent: { contentOffset: { x: scrollX } } }],
    {
      useNativeDriver: false,
      listener: (event) => {
        const offsetX = event.nativeEvent.contentOffset.x;
        const index = Math.round(offsetX / width);
        setActiveQuoteIndex(index);
      },
    },
  );

  const renderQuoteItem = ({ item, index }) => {
    const inputRange = [
      (index - 1) * width,
      index * width,
      (index + 1) * width,
    ];

    const scale = scrollX.interpolate({
      inputRange,
      outputRange: [0.9, 1, 0.9],
      extrapolate: 'clamp',
    });
    const translateY = scrollX.interpolate({
      inputRange,
      outputRange: [10, 0, 10],
    });

    return (
      <Animated.View
        style={[
          styles.quoteCard,
          {
            width: width - 45,
            transform: [{ scale }, { translateY }],
          },
        ]}
      >
        <View style={styles.quoteTextWrapperMain}>
          <View style={styles.quoteNumberCircle}>
            <Text style={styles.quoteNumber}>{item.number}</Text>
          </View>
          <Text style={styles.quoteHeading}>{item.heading}</Text>
        </View>
        <View style={styles.quoteBodyMain}>
          <Text style={styles.quoteBody}>{item.body}</Text>
        </View>
      </Animated.View>
    );
  };

  return (
    <SafeAreaView style={styles.safe}>
      <View style={styles.topBar}>
        <TouchableOpacity
          onPress={() => navigation.goBack()}
          style={styles.backBtn}
        >
          <Icon name="arrow-left" size={22} color="#0F172A" />
        </TouchableOpacity>
        <Text style={styles.topTitle}>Car Rental</Text>
        <View style={{ width: 40 }} />
      </View>

      <ScrollView
        style={styles.container}
        showsVerticalScrollIndicator={false}
        nestedScrollEnabled={true}
        keyboardShouldPersistTaps="handled"
        onScrollBeginDrag={() => setShowSuggestions(false)}
      >
        {/* form card */}
        <View style={styles.formCard}>
          <View style={styles.formHeaderRow}>
            <View>
              <Text style={styles.formTitle}>Plan your ride</Text>
              <Text style={styles.formDesc}>
                Fill this form once, get multiple quotes.
              </Text>
            </View>
            <View style={styles.securePill}>
              <Ionicons name="shield-checkmark" size={14} color="#fff" />
              <Text style={styles.securePillText}>Secure</Text>
            </View>
          </View>

          {/* Trip type - Goibibo style */}
          <Text style={styles.label}>Trip type</Text>
          <View style={styles.tripTypeBar}>
            {[
              { id: 'oneway', label: 'One-way', sub: 'Get dropped off' },
              { id: 'roundtrip', label: 'Round trip', sub: 'Keep cab till return' },
              { id: 'airport', label: 'Airport', sub: 'Pickup / Drop' },
            ].map((item) => {
              const active = tripType === item.id;
              return (
                <TouchableOpacity
                  key={item.id}
                  onPress={() => setTripType(item.id)}
                  activeOpacity={0.9}
                  style={[styles.tripTypeTab, active && styles.tripTypeTabActive]}
                >
                  <View style={styles.tripTypeIconCircle}>
                    <Ionicons
                      name={
                        item.id === 'oneway'
                          ? 'arrow-forward'
                          : item.id === 'roundtrip'
                          ? 'repeat'
                          : 'airplane'
                      }
                      size={15}
                      color="#0F172A"
                    />
                  </View>
                  <Text
                    style={[
                      styles.tripTypeTitle,
                      active && styles.tripTypeTitleActive,
                    ]}
                  >
                    {item.label}
                  </Text>
                  <Text style={styles.tripTypeSub}>{item.sub}</Text>
                </TouchableOpacity>
              );
            })}
          </View>

          {/* Location block */}
          <View style={styles.locationBlock}>
            {/* FROM */}
            <Text style={styles.smallLabel}>
              From (Area, Street or Landmark)
            </Text>
            <TouchableOpacity
              activeOpacity={0.9}
              style={styles.locationRow}
            >
              <Ionicons name="location-outline" size={18} color="#0F172A" />
              <TextInput
                value={query.length ? query : pickupLocation}
                onChangeText={handleInputChange}
                placeholder="Enter pickup location"
                placeholderTextColor="#94A3B8"
                style={styles.locationInput}
              />
              {pickupLocation ? (
                <TouchableOpacity
                  onPress={() => {
                    setPickupLocation('');
                    setPickupLocationId(null);
                    setQuery('');
                    setShowSuggestions(false);
                  }}
                >
                  <Ionicons name="close-circle" size={24} color="#CBD5F5" />
                </TouchableOpacity>
              ) : null}
            </TouchableOpacity>

            {/* suggestions */}
            {showSuggestions && (
              <View style={styles.suggestionBox}>
                <ScrollView
                  style={{ maxHeight: 200 }}
                  nestedScrollEnabled={true}
                  keyboardShouldPersistTaps="handled"
                >
                  {filteredLocations.length ? (
                    filteredLocations.map((loc) => (
                      <TouchableOpacity
                        key={loc.id}
                        style={styles.suggestionItem}
                        onPress={() => handleLocationSelect(loc)}
                      >
                        <Text style={styles.suggestionText}>{loc.name}</Text>
                      </TouchableOpacity>
                    ))
                  ) : (
                    <Text style={styles.noResult}>No location found</Text>
                  )}
                </ScrollView>
              </View>
            )}

            {/* TO */}
            <Text style={[styles.smallLabel, { marginTop: 14 }]}>
              {tripType === 'airport'
                ? 'To / From (Airport / Hotel / Area)'
                : 'To (Area, Street or Landmark)'}
            </Text>
            <TouchableOpacity
              activeOpacity={0.9}
              style={styles.locationRow}
            >
              <Ionicons
                name={tripType === 'airport' ? 'navigate-outline' : 'flag-outline'}
                size={18}
                color="#0F172A"
              />
              <TextInput
                value={destination}
                onChangeText={setDestination}
                placeholder={
                  tripType === 'airport'
                    ? 'Airport name / Hotel / Area'
                    : 'Enter drop location'
                }
                placeholderTextColor="#94A3B8"
                style={styles.locationInput}
              />
            </TouchableOpacity>

            {/* add stop (placeholder) */}
            {tripType !== 'airport' && (
              <TouchableOpacity
                style={styles.addStopBtn}
                activeOpacity={0.85}
              >
                {/* left empty for now */}
              </TouchableOpacity>
            )}
          </View>

          {/* airport extra */}
          {tripType === 'airport' && (
            <View style={{ marginTop: 14 ,marginBottom: 14}}>
              <Text style={styles.label}>Select Airport Booking Type</Text>
              <View style={styles.airportTypeRow}>
                {AIRPORT_TYPES.map((item) => {
                  const active = item.id === airportDirection;
                  return (
                    <TouchableOpacity
                      key={item.id}
                      onPress={() => setAirportDirection(item.id)}
                      style={[
                        styles.airportTypeCard,
                        active && styles.airportTypeCardActive,
                      ]}
                      activeOpacity={0.9}
                    >
                      <View style={styles.airportTypeIconWrap}>
                        <Ionicons
                          name={item.icon}
                          size={16}
                          color={active ? '#0F172A' : '#94A3B8'}
                        />
                      </View>
                      <View style={{ flex: 1 }}>
                        <Text
                          style={[
                            styles.airportTypeLabel,
                            active && styles.airportTypeLabelActive,
                          ]}
                        >
                          {item.label}
                        </Text>
                        <Text style={styles.airportTypeSub}>
                          {item.id === 'pickup'
                            ? 'Driver will wait at airport'
                            : 'Driver will drop you to airport'}
                        </Text>
                      </View>
                      {active && (
                        <View style={styles.airportTypeTick}>
                          <Ionicons name="checkmark" size={13} color="#fff" />
                        </View>
                      )}
                    </TouchableOpacity>
                  );
                })}
              </View>
            </View>
          )}

          {/* DATE ROW */}
          <View style={styles.dateRow}>
            {/* TRIP START CARD */}
            <TouchableOpacity
              style={styles.dateCard}
              onPress={() => {
                if (Platform.OS === 'android') {
                  openAndroidPicker('start');
                } else {
                  setShowStartDatePicker(true);
                }
              }}
              activeOpacity={0.9}
            >
              <Text style={styles.dateLabel}>TRIP START</Text>
              <View style={styles.dateContent}>
                <View style={styles.dateIconWrap}>
                  <Ionicons name="calendar-outline" size={16} color="#0F172A" />
                </View>
                <View style={{ flex: 1 }}>
                  <Text style={styles.dateMainText}>
                    {startDate.toLocaleDateString('en-US', {
                      day: '2-digit',
                      month: 'short',
                      year: 'numeric',
                    })}
                  </Text>
                  <Text style={styles.dateSubText}>
                    {startDate.toLocaleDateString('en-US', { weekday: 'short' })}{' '}
                    •{' '}
                    {startDate.toLocaleTimeString('en-US', {
                      hour: '2-digit',
                      minute: '2-digit',
                    })}
                  </Text>
                </View>
              </View>
            </TouchableOpacity>

            {/* TRIP END CARD */}
            {tripType === 'roundtrip' ? (
              <TouchableOpacity
                style={styles.dateCard}
                onPress={() => {
                  if (Platform.OS === 'android') {
                    openAndroidPicker('end');
                  } else {
                    setShowReturnDatePicker(true);
                  }
                }}
                activeOpacity={0.9}
              >
                <Text style={styles.dateLabel}>TRIP END</Text>
                <View style={styles.dateContent}>
                  <View style={styles.dateIconWrap}>
                    <Ionicons name="calendar-outline" size={16} color="#0F172A" />
                  </View>
                  <View style={{ flex: 1 }}>
                    <Text style={styles.dateMainText}>
                      {returnDate.toLocaleDateString('en-US', {
                        day: '2-digit',
                        month: 'short',
                        year: 'numeric',
                      })}
                    </Text>
                    <Text style={styles.dateSubText}>
                      {returnDate.toLocaleDateString('en-US', {
                        weekday: 'long',
                      })}
                    </Text>
                  </View>
                </View>
              </TouchableOpacity>
            ) : (
              <View style={{ flex: 1 }} />
            )}
          </View>

          {/* iOS pickers */}
          {showStartDatePicker && Platform.OS === 'ios' && (
            <View style={styles.iosDatePickerContainer}>
              <DateTimePicker
                value={startDate}
                mode="datetime"
                display="spinner"
                onChange={onStartDateChangeIOS}
                minimumDate={new Date()}
              />
              <View style={styles.iosButtonContainer}>
                <TouchableOpacity
                  style={styles.iosButton}
                  onPress={() => setShowStartDatePicker(false)}
                >
                  <Text style={styles.iosButtonText}>Done</Text>
                </TouchableOpacity>
              </View>
            </View>
          )}

          {showReturnDatePicker && Platform.OS === 'ios' && (
            <View style={styles.iosDatePickerContainer}>
              <DateTimePicker
                value={returnDate}
                mode="datetime"
                display="spinner"
                onChange={onReturnDateChangeIOS}
                minimumDate={startDate}
              />
              <View style={styles.iosButtonContainer}>
                <TouchableOpacity
                  style={styles.iosButton}
                  onPress={() => setShowReturnDatePicker(false)}
                >
                  <Text style={styles.iosButtonText}>Done</Text>
                </TouchableOpacity>
              </View>
            </View>
          )}

          {/* car type */}
          <Text style={[styles.label, { marginTop: 16 }]}>Car type</Text>
          <ScrollView
            horizontal
            showsHorizontalScrollIndicator={false}
            style={{ marginTop: 6 }}
          >
            {CAR_TYPES.map((c, idx) => {
              const active = carType === c.id;
              return (
                <TouchableOpacity
                  key={idx}
                  style={[styles.bikeChip, active && styles.bikeChipActive]}
                  onPress={() => setCarType(c.id)}
                  activeOpacity={0.85}
                >
                  <Image source={c.img} style={styles.bikeChipImg} />
                  <Text
                    style={[
                      styles.bikeChipText,
                      active && styles.bikeChipTextActive,
                    ]}
                  >
                    {c.name}
                  </Text>
                </TouchableOpacity>
              );
            })}
          </ScrollView>

          {/* passengers */}
          <Text style={[styles.label, { marginTop: 16 }]}>
            Total passengers
          </Text>
          <View style={styles.inputPill}>
            <Ionicons name="people-outline" size={15} color="#64748B" />
            <TextInput
              value={totalPassengers}
              onChangeText={setTotalPassengers}
              placeholder="e.g. 4"
              placeholderTextColor="#9CA3AF"
              keyboardType="numeric"
              style={styles.inputText}
            />
          </View>

          {/* other details */}
          <Text style={[styles.label, { marginTop: 16 }]}>
            Other details (luggage, flight no…)
          </Text>
          <TextInput
            style={styles.textArea}
            value={otherDetails}
            onChangeText={setOtherDetails}
            placeholder="Example: 2 big bags, 1 cabin, 6 AM flight, need English-speaking driver."
            placeholderTextColor="#9CA3AF"
            multiline
          />

          <TouchableOpacity
            style={[styles.submitBtn, isSubmitting && { opacity: 0.4 }]}
            onPress={handleSubmit}
            disabled={isSubmitting}
          >
            {isSubmitting ? (
              <ActivityIndicator color="#fff" />
            ) : (
              <Text style={styles.submitText}>Submit</Text>
            )}
          </TouchableOpacity>
        </View>

        {/* FAQ */}
        <View style={styles.faqSec}>
          <Text style={styles.faqTitle}>FAQs about car rental</Text>
          {faqs.map((item, idx) => {
            const open = expandedIndex === idx;
            return (
              <View key={idx} style={styles.faqItem}>
                <TouchableOpacity
                  style={styles.faqHead}
                  onPress={() => toggleFAQ(idx)}
                >
                  <Text style={styles.faqQ}>{item.question}</Text>
                  <Ionicons
                    name={open ? 'chevron-up' : 'chevron-down'}
                    size={18}
                    color="#E2E8F0"
                  />
                </TouchableOpacity>
                {open && <Text style={styles.faqA}>{item.answer}</Text>}
              </View>
            );
          })}
        </View>
      </ScrollView>

      {/* PHONE MODAL */}
      <Modal
        visible={isPhoneModal}
        transparent
        animationType="fade"
        onRequestClose={() => setIsPhoneModal(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalCard}>
            <Text style={styles.modalTitle}>Phone required</Text>
            <Text style={styles.modalBody}>
              Add your phone number once and book faster next time.
            </Text>
            <TouchableOpacity
              style={styles.modalBtn}
              onPress={() => {
                setIsPhoneModal(false);
                navigation.navigate('EditProfileScreen');
              }}
            >
              <Text style={styles.modalBtnText}>Go to Profile</Text>
            </TouchableOpacity>
            <TouchableOpacity
              onPress={() => setIsPhoneModal(false)}
              style={{ marginTop: 10 }}
            >
              <Text style={{ color: '#94A3B8' }}>Maybe later</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>

      {/* ANDROID PICKER */}
      {androidPickerVisible && Platform.OS === 'android' && (
        <DateTimePicker
          value={androidPickingTarget === 'start' ? startDate : returnDate}
          mode={androidPickerMode}
          display="default"
          onChange={onAndroidChange}
          minimumDate={
            androidPickingTarget === 'start' ? new Date() : startDate
          }
        />
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: BG },
  container: { backgroundColor: 'transparent' },
  topBar: {
    height: 52,
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    justifyContent: 'space-between',
    backgroundColor: BG,
  },
  backBtn: {
    width: 40,
    height: 40,
    borderRadius: 999,
    backgroundColor: '#FFFFFF',
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOpacity: 0.03,
    shadowRadius: 8,
    shadowOffset: { width: 0, height: 3 },
  },
  topTitle: { fontSize: 17, fontWeight: '700', color: '#0F172A' },

  formCard: {
    backgroundColor: '#FFFFFF',
    marginHorizontal: 14,
    borderRadius: 22,
    paddingVertical: 12,
    paddingHorizontal: 16,
    shadowColor: '#000',
    shadowOpacity: 0.04,
    shadowRadius: 14,
    shadowOffset: { width: 0, height: 6 },
  },
  formHeaderRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  formTitle: { fontSize: 18, fontWeight: '700', color: '#0F172A' },
  formDesc: { fontSize: 12, color: '#94A3B8', marginTop: 2 },
  securePill: {
    backgroundColor: GREEN,
    borderRadius: 999,
    paddingHorizontal: 10,
    paddingVertical: 4,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    marginBottom: 25,
  },
  securePillText: { color: '#fff', fontSize: 12, fontWeight: '600' },

  label: {
    fontSize: 15,
    fontWeight: '700',
    color: '#0F172A',
    marginBottom: 5,
  },

  // Trip type bar
  tripTypeBar: {
    flexDirection: 'row',
    backgroundColor: '#EFF3F6',
    borderRadius: 14,
    overflow: 'hidden',
    marginBottom: 14,
  },
  tripTypeTab: {
    flex: 1,
    paddingVertical: 10,
    paddingHorizontal: 10,
    minHeight: 70,
    justifyContent: 'center',
  },
  tripTypeTabActive: {
    backgroundColor: '#FFFFFF',
    borderWidth: 1,
    borderColor: 'rgba(9,179,104,0.25)',
    borderRadius: 14,
    elevation: 1,
  },
  tripTypeIconCircle: {
    width: 26,
    height: 26,
    borderRadius: 13,
    backgroundColor: 'rgba(9,179,104,0.12)',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 4,
  },
  tripTypeTitle: {
    fontSize: 15,
    fontWeight: '600',
    color: '#0F172A',
  },
  tripTypeTitleActive: {
    color: '#0F172A',
  },
  tripTypeSub: {
    fontSize: 11,
    color: '#94A3B8',
    marginTop: 2,
  },

  // location block
  locationBlock: {
    backgroundColor: '#F8FAFC',
    borderRadius: 16,
    borderWidth: 1,
    borderColor: 'rgba(15,23,42,0.04)',
    padding: 12,
    marginBottom: 12,
  },
  smallLabel: {
    fontSize: 13,
    color: '#94A3B8',
    marginBottom: 4,
  },
  locationRow: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    borderWidth: 1,
    borderColor: 'rgba(148,163,184,0.25)',
    paddingHorizontal: 12,
    minHeight: 54,
    gap: 8,
  },
  locationInput: {
    flex: 1,
    fontSize: 15,
    color: '#0F172A',
    paddingVertical: 6,
  },

  addStopBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    marginTop: 10,
  },
  addStopText: {
    color: GREEN,
    fontWeight: '600',
    fontSize: 13,
  },

  // suggestions
  suggestionBox: {
    position: 'absolute',
    top: 100,
    left: 0,
    right: 0,
    backgroundColor: '#FFFFFF',
    borderRadius: 14,
    borderWidth: 0.5,
    borderColor: '#E2E8F0',
    zIndex: 99,
    elevation: 10,
  },
  suggestionItem: {
    paddingHorizontal: 12,
    paddingVertical: 9,
    borderBottomWidth: 0.5,
    borderColor: '#EDF2F7',
  },
  suggestionText: { color: '#0F172A' },
  noResult: { padding: 10, textAlign: 'center', color: '#94A3B8' },

  // airport selection
  airportTypeRow: {
    flexDirection: 'column',
    gap: 10,
  },
  airportTypeCard: {
    flexDirection: 'row',
    backgroundColor: '#F8FAFC',
    borderRadius: 14,
    padding: 12,
    borderWidth: 1,
    borderColor: 'transparent',
    alignItems: 'center',
    gap: 12,
  },
  airportTypeCardActive: {
    backgroundColor: 'rgba(9,179,104,0.08)',
    borderColor: 'rgba(9,179,104,0.35)',
  },
  airportTypeIconWrap: {
    width: 32,
    height: 32,
    borderRadius: 999,
    backgroundColor: '#FFFFFF',
    justifyContent: 'center',
    alignItems: 'center',
  },
  airportTypeLabel: { fontSize: 15, color: '#0F172A', fontWeight: '600' },
  airportTypeLabelActive: { color: '#065F46' },
  airportTypeSub: { fontSize: 11, color: '#94A3B8', marginTop: 1 },
  airportTypeTick: {
    width: 20,
    height: 20,
    borderRadius: 999,
    backgroundColor: '#09B368',
    justifyContent: 'center',
    alignItems: 'center',
  },

  // date cards
  dateRow: {
    flexDirection: 'row',
    gap: 12,
  },
  dateCard: {
    flex: 1,
    backgroundColor: '#FFFFFF',
    borderRadius: 14,
    borderWidth: 1,
    borderColor: 'rgba(148,163,184,0.25)',
    paddingHorizontal: 12,
    paddingVertical: 8,
    shadowColor: '#000',
    shadowOpacity: 0.01,
    shadowRadius: 6,
    shadowOffset: { width: 0, height: 3 },
  },
  dateLabel: {
    fontSize: 12,
    fontWeight: '600',
    color: '#94A3B8',
    textTransform: 'uppercase',
    marginBottom: 6,
    letterSpacing: 0.4,
  },
  dateContent: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  dateIconWrap: {
    width: 30,
    height: 30,
    borderRadius: 10,
    backgroundColor: '#F1F5F9',
    justifyContent: 'center',
    alignItems: 'center',
  },
  dateMainText: {
    fontSize: 14,
    fontWeight: '700',
    color: '#0F172A',
  },
  dateSubText: {
    fontSize: 11,
    color: '#94A3B8',
    marginTop: 1,
  },

  // iOS picker container
  iosDatePickerContainer: {
    backgroundColor: '#fff',
    borderRadius: 12,
    marginTop: 8,
    padding: 10,
    shadowColor: '#000',
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  iosButtonContainer: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
    paddingTop: 8,
    borderTopWidth: 1,
    borderTopColor: '#f0f0f0',
    marginTop: 8,
  },
  iosButton: {
    backgroundColor: '#09B368',
    paddingHorizontal: 16,
    paddingVertical: 6,
    borderRadius: 6,
  },
  iosButtonText: { color: '#fff', fontWeight: '600' },

  // input pill
  inputPill: {
    flexDirection: 'row',
    backgroundColor: '#F8FAFC',
    borderRadius: 12,
    borderColor: 'rgba(15,23,42,0.05)',
    borderWidth: 1,
    paddingHorizontal: 15,
    paddingVertical: 6,
    gap: 6,
    minHeight: 56,
    alignItems: 'center',
  },
  inputText: { flex: 1, fontSize: 12.5, color: '#0F172A', paddingVertical: 2 },

  // car type chips
  bikeChip: {
    width: 130,
    backgroundColor: '#F8FAFC',
    borderRadius: 14,
    padding: 8,
    marginRight: 10,
    alignItems: 'center',
    gap: 6,
    borderWidth: 1,
    borderColor: 'transparent',
  },
  bikeChipActive: {
    backgroundColor: '#FFFFFF',
    borderColor: 'rgba(9,179,104,0.35)',
    shadowColor: '#000',
    shadowOpacity: 0.02,
    shadowRadius: 12,
    shadowOffset: { width: 0, height: 6 },
  },
  bikeChipImg: { width: 70, height: 45, resizeMode: 'contain' },
  bikeChipText: { fontSize: 13, textAlign: 'center', color: '#475569' },
  bikeChipTextActive: { color: '#0F172A', fontWeight: '600' },

  textArea: {
    backgroundColor: '#F8FAFC',
    borderRadius: 10,
    borderWidth: 1,
    borderColor: 'rgba(15,23,42,0.05)',
    minHeight: 84,
    padding: 10,
    textAlignVertical: 'top',
    fontSize: 12.5,
  },
  submitBtn: {
    marginTop: 15,
    backgroundColor: GREEN,
    borderRadius: 999,
    paddingVertical: 11,
    alignItems: 'center',
  },
  submitText: { color: '#FFFFFF', fontSize: 15, fontWeight: '700' },

  // quotes
  quoteTitle: {
    marginTop: 20,
    marginLeft: 23,
    fontSize: 16,
    fontWeight: '700',
    color: '#000',
  },
  quoteTextWrapperMain: {
    width: '100%',
    flexDirection: 'row',
    alignContent: 'center',
    marginBottom: 10,
  },
  quoteCard: {
    marginHorizontal: 20,
    marginTop: 10,
    backgroundColor: 'white',
    borderRadius: 10,
    paddingVertical: 25,
    paddingHorizontal: 20,
    shadowColor: '#000',
    shadowOpacity: 0.25,
    shadowRadius: 3.55,
    shadowOffset: { width: 0, height: 0 },
    elevation: 4,
  },
  quoteNumberCircle: {
    width: 60,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 10,
    position: 'absolute',
    opacity: 0.8,
    bottom: -70,
  },
  quoteNumber: { fontWeight: '700', fontSize: 100, color: '#DDF7E8' },
  quoteHeading: {
    fontWeight: '700',
    fontSize: 17,
    color: '#404040',
    marginLeft: 65,
    marginTop: 5,
  },
  quoteBody: {
    fontWeight: '400',
    fontSize: 15,
    color: '#4D4C4C',
    lineHeight: 18,
    textAlign: 'center',
    marginTop: 10,
  },
  quoteBodyMain: { width: '100%' },
  paginationDots: {
    marginTop: 15,
    flexDirection: 'row',
    justifyContent: 'center',
    marginBottom: 20,
  },
  dot: {
    width: 10,
    height: 10,
    borderRadius: 5,
    backgroundColor: '#D9D9D9',
    marginHorizontal: 5,
  },
  activeDot: { backgroundColor: '#2FCD72' },

  // FAQ
  faqSec: { backgroundColor: '#0F172A', marginTop: 16, padding: 16 },
  faqTitle: {
    fontSize: 18,
    fontWeight: '700',
    color: '#FFFFFF',
    marginBottom: 12,
  },
  faqItem: {
    borderBottomColor: 'rgba(226,232,240,0.1)',
    borderBottomWidth: 1,
    paddingVertical: 10,
  },
  faqHead: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  faqQ: { color: '#FFFFFF', fontSize: 14, flex: 1, marginRight: 10 },
  faqA: { color: '#CBD5F5', fontSize: 12.5, marginTop: 6, lineHeight: 18 },

  // modal
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(15,23,42,0.4)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalCard: {
    width: 300,
    backgroundColor: '#FFFFFF',
    borderRadius: 18,
    padding: 16,
    alignItems: 'center',
  },
  modalTitle: { fontSize: 16, fontWeight: '700', color: '#0F172A', marginBottom: 6 },
  modalBody: { textAlign: 'center', color: '#94A3B8', fontSize: 12.5, marginBottom: 14 },
  modalBtn: { backgroundColor: GREEN, borderRadius: 999, paddingHorizontal: 20, paddingVertical: 10 },
  modalBtnText: { color: '#fff', fontWeight: '700' },
});
