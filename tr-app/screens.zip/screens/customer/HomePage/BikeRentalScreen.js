
import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  TouchableOpacity,
  TextInput,
  Image,
  Modal,
  Platform,
  SafeAreaView,
  Dimensions,
  Animated,
  ActivityIndicator,
} from 'react-native';
import Icon from 'react-native-vector-icons/Feather';
import Ionicons from 'react-native-vector-icons/Ionicons';
import { useNavigation } from '@react-navigation/native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import axios from 'axios';
import DateTimePicker from '@react-native-community/datetimepicker';

const { width } = Dimensions.get('window');
const GREEN = '#09B368';
const BG = '#F5F5F7';

// FAQ
const faqs = [
  {
    question: 'How can I book a bike rental?',
    answer:
      'Pick city, dates and duration → vendors send quotes → you confirm and ride.',
  },
  {
    question: 'What types of bikes are available?',
    answer:
      'Scooters, commuters, sports, cruisers, ADV, dirt. Depends on your city.',
  },
  {
    question: 'Do I need a valid driving license?',
    answer: 'Yes, original DL is mandatory at pickup.',
  },
  {
    question: 'Is fuel included?',
    answer: 'Generally no. Fuel is per usage. Check with vendor.',
  },
];

// bike chips (horizontal)
const bikeData = [
  { id: '1', name: 'Sport Bike', image: require('../../../assets/SportBikeHome2.png') },
  { id: '2', name: 'Scooter', image: require('../../../assets/ScooterHome.png') },
  { id: '3', name: 'Cruiser', image: require('../../../assets/cruiserHome.png') },
  { id: '4', name: 'Street / Naked', image: require('../../../assets/NakedBikeHome.png') },
  { id: '5', name: 'Adventure', image: require('../../../assets/AdventureTourersHome.png') },
  { id: '6', name: 'Dirt Bike', image: require('../../../assets/DirtBikeHome.png') },
];

// quote slider (same as car)
const quoteData = [
  {
    id: '1',
    number: '1',
    heading: 'Enquire',
    body: `Tell us pickup city, dates, duration & what bike you want.`,
  },
  {
    id: '2',
    number: '2',
    heading: 'Get Quote',
    body: `Vendors near you send their price + model + delivery options.`,
  },
  {
    id: '3',
    number: '3',
    heading: 'Ride',
    body: `Pick a quote, pay token and pickup / get doorstep delivery.`,
  },
];

// popular cities (kept)
const popularCities = [
  'Ahmedabad',
  'Bangalore',
  'Goa',
  'Udaipur',
  'Jaipur',
  'Pune',
  'Mumbai',
  'Nashik',
  'Chennai',
  'Hyderabad',
];

export default function BikeRentalScreen() {
  const navigation = useNavigation();

  // UI
  const [expandedIndex, setExpandedIndex] = useState(null);
  const scrollX = useRef(new Animated.Value(0)).current;
  const [activeQuoteIndex, setActiveQuoteIndex] = useState(0);

  // data
  const [customerData, setCustomerData] = useState(null);
  const [allLocations, setAllLocations] = useState([]);
  const [query, setQuery] = useState('');
  const [pickupLocation, setPickupLocation] = useState('');
  const [pickupLocationId, setPickupLocationId] = useState(null);
  const [destination, setDestination] = useState('');
  const [showSuggestions, setShowSuggestions] = useState(false);

  // booking
  const [selectedDuration, setSelectedDuration] = useState('Daily');
  const [selectedBikeType, setSelectedBikeType] = useState('2'); // default Scooter
  const [otherDetails, setOtherDetails] = useState('');
  const [isPhoneModal, setIsPhoneModal] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // dates
  const [startDate, setStartDate] = useState(new Date());
  const [returnDate, setReturnDate] = useState(
    new Date(Date.now() + 2 * 60 * 60 * 1000),
  );

  // ANDROID date/time picker controls
  const [androidPickerVisible, setAndroidPickerVisible] = useState(false);
  const [androidPickerMode, setAndroidPickerMode] = useState('date');
  const [androidPickingTarget, setAndroidPickingTarget] = useState('start');

  // iOS pickers
  const [showStartDatePicker, setShowStartDatePicker] = useState(false);
  const [showReturnDatePicker, setShowReturnDatePicker] = useState(false);

  useEffect(() => {
    (async () => {
      const data = await AsyncStorage.getItem('customer');
      if (data) setCustomerData(JSON.parse(data));
    })();
    fetchLocations();
  }, []);

  const fetchLocations = async () => {
    try {
      const res = await axios.get('https://app.transrentals.in/api/locations', {
        timeout: 5000,
      });
      if (res.data?.status) {
        setAllLocations(res.data.locations);
      }
    } catch (err) {
      console.log('location error', err?.response?.data || err);
    }
  };

  // helpers
  const textSafe = (t) => (t || '').toLowerCase();

  const filteredLocations = query.length
    ? allLocations.filter(
        (l) =>
          typeof l.name === 'string' &&
          l.name.toLowerCase().includes(textSafe(query)),
      )
    : allLocations.slice(0, 35);

  const handleInputChange = (text) => {
    setQuery(text);
    setPickupLocation(text);
    setPickupLocationId(null);
    setShowSuggestions(true);
  };

const handleLocationSelect = (loc) => {
  setPickupLocation(loc.name);
  setPickupLocationId(loc.id);
  setQuery('');
  setShowSuggestions(false);  // ✅ good
};

  const toggleFAQ = (i) => {
    setExpandedIndex((prev) => (prev === i ? null : i));
  };

  // ANDROID flow
  const openAndroidPicker = (target) => {
    setAndroidPickingTarget(target);
    setAndroidPickerMode('date');
    setAndroidPickerVisible(true);
  };

  const onAndroidChange = (event, selected) => {
    if (event.type === 'dismissed') {
      setAndroidPickerVisible(false);
      return;
    }
    if (!selected) {
      setAndroidPickerVisible(false);
      return;
    }

    if (androidPickerMode === 'date') {
      if (androidPickingTarget === 'start') {
        const newStart = new Date(selected);
        const merged = new Date(
          newStart.getFullYear(),
          newStart.getMonth(),
          newStart.getDate(),
          startDate.getHours(),
          startDate.getMinutes(),
        );
        setStartDate(merged);
        if (returnDate < merged) {
          setReturnDate(new Date(merged.getTime() + 2 * 60 * 60 * 1000));
        }
      } else {
        const newEndDate = new Date(selected);
        const merged = new Date(
          newEndDate.getFullYear(),
          newEndDate.getMonth(),
          newEndDate.getDate(),
          returnDate.getHours(),
          returnDate.getMinutes(),
        );
        setReturnDate(merged);
      }
      // now show time
      setAndroidPickerMode('time');
      setAndroidPickerVisible(true);
      return;
    }

    if (androidPickerMode === 'time') {
      if (androidPickingTarget === 'start') {
        const upd = new Date(startDate);
        upd.setHours(selected.getHours());
        upd.setMinutes(selected.getMinutes());
        setStartDate(upd);

        if (returnDate < upd) {
          setReturnDate(new Date(upd.getTime() + 2 * 60 * 60 * 1000));
        }
      } else {
        const upd = new Date(returnDate);
        upd.setHours(selected.getHours());
        upd.setMinutes(selected.getMinutes());
        setReturnDate(upd);
      }
      setAndroidPickerVisible(false);
    }
  };

  // iOS
  const onStartDateChangeIOS = (event, selectedDate) => {
    if (!selectedDate) return;
    setStartDate(selectedDate);
    if (returnDate < selectedDate) {
      setReturnDate(new Date(selectedDate.getTime() + 2 * 60 * 60 * 1000));
    }
  };
  const onReturnDateChangeIOS = (event, selectedDate) => {
    if (!selectedDate) return;
    setReturnDate(selectedDate);
  };

  // submit
  const handleSubmit = async () => {
    if (!pickupLocation) {
      alert('Please select pickup city');
      return;
    }
    if (!selectedDuration) {
      alert('Please select duration');
      return;
    }
    if (!selectedBikeType) {
      alert('Please select bike type');
      return;
    }

    if (customerData && !customerData.phone) {
      setIsPhoneModal(true);
      return;
    }

    // map duration → number
    const durationMap = {
      Hourly: 1,
      Daily: 1,
      Weekly: 7,
      Monthly: 30,
    };
    const finalDuration =
      durationMap[selectedDuration] !== undefined
        ? durationMap[selectedDuration]
        : 1;

    setIsSubmitting(true);
    try {
      const customerId = await AsyncStorage.getItem('customer_id');
      const token = await AsyncStorage.getItem('token');

      let finalLocationId = pickupLocationId;
      if (!finalLocationId && pickupLocation) {
        const match = allLocations.find(
          (l) => l.name?.toLowerCase() === pickupLocation?.toLowerCase(),
        );
        if (match) finalLocationId = match.id;
      }

      const payload = {
        customer_id: customerId ?? '',
        service_id: 1,
        service_name: 'Bike Rental',
        location_id: finalLocationId,
        location_name: pickupLocation,
        destination,
        journey_datetime: startDate.toISOString(),
        return_datetime: returnDate.toISOString(),
        bike_duration: finalDuration,
        bike_type: selectedBikeType,
        other_info: otherDetails?.trim() || '',
      };

      let res;
      if (token) {
        res = await axios.post(
          'https://app.transrentals.in/api/customer-bike-booking',
          payload,
          {
            headers: {
              Authorization: `Bearer ${token}`,
              Accept: 'application/json',
            },
          },
        );
      } else {
        res = await axios.post(
          'https://app.transrentals.in/api/customer-bike-booking',
          payload,
          {
            headers: {
              Accept: 'application/json',
            },
          },
        );
      }

     if (res.data?.booking_id || res.data?.status) {
  // clear old values
  setDestination('');
  setOtherDetails('');

  // navigate to confirmation screen
  navigation.navigate('BookingConfirmation', {
    booking_id: res.data?.booking_id || 'unknown',
  });
}
 else {
        alert('Booking could not be submitted. Check required fields.');
      }
    } catch (err) {
      console.log('booking error', err?.response?.data || err);
      alert(
        err?.response?.data?.message ||
          'Failed to submit booking. Please try again.',
      );
    } finally {
      setIsSubmitting(false);
    }
  };

  // quote slider render
  const renderQuoteItem = ({ item, index }) => {
    const inputRange = [
      (index - 1) * width,
      index * width,
      (index + 1) * width,
    ];

    const scale = scrollX.interpolate({
      inputRange,
      outputRange: [0.9, 1, 0.9],
      extrapolate: 'clamp',
    });
    const translateY = scrollX.interpolate({
      inputRange,
      outputRange: [10, 0, 10],
    });

    return (
      <Animated.View
        style={[
          styles.quoteCard,
          {
            width: width - 45,
            transform: [{ scale }, { translateY }],
          },
        ]}
      >
        <View style={styles.quoteTextWrapperMain}>
          <View style={styles.quoteNumberCircle}>
            <Text style={styles.quoteNumber}>{item.number}</Text>
          </View>
          <Text style={styles.quoteHeading}>{item.heading}</Text>
        </View>
        <View style={styles.quoteBodyMain}>
          <Text style={styles.quoteBody}>{item.body}</Text>
        </View>
      </Animated.View>
    );
  };

  const handleScroll = Animated.event(
    [{ nativeEvent: { contentOffset: { x: scrollX } } }],
    {
      useNativeDriver: false,
      listener: (event) => {
        const offsetX = event.nativeEvent.contentOffset.x;
        const index = Math.round(offsetX / width);
        setActiveQuoteIndex(index);
      },
    },
  );
  const inputRef = useRef(null);

  return (
    <SafeAreaView style={styles.safe}>
      {/* TOP BAR */}
      <View style={styles.topBar}>
        <TouchableOpacity
          onPress={() => navigation.goBack()}
          style={styles.backBtn}
        >
          <Icon name="arrow-left" size={22} color="#0F172A" />
        </TouchableOpacity>
        <Text style={styles.topTitle}>Bike Rental</Text>
        <View style={{ width: 40 }} />
      </View>

      <ScrollView
        style={styles.container}
        showsVerticalScrollIndicator={false}
        nestedScrollEnabled={true}
    keyboardShouldPersistTaps="handled"
      onScrollBeginDrag={() => setShowSuggestions(false)} // 👈 close on scroll

      >
        {/* HERO */}
        {/* <View style={styles.heroWrap}>
          <View style={styles.heroGradient} />
          <View style={styles.heroGlow} />
          <View style={styles.heroContent}>
            <Text style={styles.heroPill}>Self-drive • Delivery • Monthly</Text>
            <Text style={styles.heroHeading}>Ride like it’s yours.</Text>
            <Text style={styles.heroSub}>
              Pickup in minutes, premium bikes, verified vendors.
            </Text>
          </View>
          <Image
            source={require('../../../assets/BikeHome.png')}
            style={styles.heroImg}
          />
        </View> */}

        {/* FORM CARD */}
        <View style={styles.formCard}>
          <View style={styles.formHeaderRow}>
            <View>
              <Text style={styles.formTitle}>Plan your ride</Text>
              <Text style={styles.formDesc}>
                One quick form, multiple quotes from vendors.
              </Text>
            </View>
            <View style={styles.securePill}>
              <Ionicons name="shield-checkmark" size={14} color="#fff" />
              <Text style={styles.securePillText}>Secure</Text>
            </View>
          </View>

          {/* LOCATION BLOCK (same as car) */}
          <View style={styles.locationBlock}>
            {/* FROM */}
            <Text style={styles.smallLabel}>
              From (Area, Street or Landmark)
            </Text>
            <TouchableOpacity activeOpacity={0.9} style={styles.locationRow}>
              <Ionicons name="location-outline" size={18} color="#0F172A" />
           <TextInput
  ref={inputRef}
  value={query.length ? query : pickupLocation}
  onChangeText={handleInputChange}
  placeholder="Enter pickup city"
  placeholderTextColor="#94A3B8"
  style={styles.locationInput}
  onFocus={() => setShowSuggestions(true)}
  onBlur={() => setTimeout(() => setShowSuggestions(false), 150)}
/>

{pickupLocation ? (
  <TouchableOpacity
    onPress={() => {
      setPickupLocation('');
      setPickupLocationId(null);
      setQuery('');
      setShowSuggestions(false); // 👈 close dropdown on cross
      // don't re-focus here, or it will reopen via onFocus
    }}
  >
    <Ionicons name="close-circle" size={24} color="#CBD5F5" />
  </TouchableOpacity>
) : null}

            </TouchableOpacity>

            {/* suggestions */}
            {showSuggestions && (
              <View style={styles.suggestionBox}>
                <ScrollView style={{ maxHeight: 200 }} nestedScrollEnabled={true}
    keyboardShouldPersistTaps="handled">
                  {filteredLocations.length ? (
                    filteredLocations.map((loc) => (
                      <TouchableOpacity
                        key={loc.id}
                        style={styles.suggestionItem}
                        onPress={() => handleLocationSelect(loc)}
                      >
                        <Text style={styles.suggestionText}>{loc.name}</Text>
                      </TouchableOpacity>
                    ))
                  ) : (
                    <Text style={styles.noResult}>No location found</Text>
                  )}
                </ScrollView>
              </View>
            )}

            {/* TO */}
            <Text style={[styles.smallLabel, { marginTop: 14 }]}>
              To / Drop (Optional)
            </Text>
            <TouchableOpacity activeOpacity={0.9} style={styles.locationRow}>
              <Ionicons name="flag-outline" size={18} color="#0F172A" />
              <TextInput
                value={destination}
                onChangeText={setDestination}
                placeholder="Drop / City / Trail"
                placeholderTextColor="#94A3B8"
                style={styles.locationInput}
              />
            </TouchableOpacity>
          </View>

          {/* DATE ROW (same card style as car) */}
          <View style={styles.dateRow}>
            <TouchableOpacity
              style={styles.dateCard}
              onPress={() => {
                if (Platform.OS === 'android') {
                  openAndroidPicker('start');
                } else {
                  setShowStartDatePicker(true);
                }
              }}
              activeOpacity={0.9}
            >
              <Text style={styles.dateLabel}>TRIP START</Text>
              <View style={styles.dateContent}>
                <View style={styles.dateIconWrap}>
                  <Ionicons name="calendar-outline" size={16} color="#0F172A" />
                </View>
                <View style={{ flex: 1 }}>
                  <Text style={styles.dateMainText}>
                    {startDate.toLocaleDateString('en-US', {
                      day: '2-digit',
                      month: 'short',
                      year: 'numeric',
                    })}
                  </Text>
                  <Text style={styles.dateSubText}>
                    {startDate.toLocaleDateString('en-US', {
                      weekday: 'short',
                    })}{' '}
                    •{' '}
                    {startDate.toLocaleTimeString('en-US', {
                      hour: '2-digit',
                      minute: '2-digit',
                    })}
                  </Text>
                </View>
              </View>
            </TouchableOpacity>

            <TouchableOpacity
              style={styles.dateCard}
              onPress={() => {
                if (Platform.OS === 'android') {
                  openAndroidPicker('end');
                } else {
                  setShowReturnDatePicker(true);
                }
              }}
              activeOpacity={0.9}
            >
              <Text style={styles.dateLabel}>TRIP END</Text>
              <View style={styles.dateContent}>
                <View style={styles.dateIconWrap}>
                  <Ionicons name="calendar-outline" size={16} color="#0F172A" />
                </View>
                <View style={{ flex: 1 }}>
                  <Text style={styles.dateMainText}>
                    {returnDate.toLocaleDateString('en-US', {
                      day: '2-digit',
                      month: 'short',
                      year: 'numeric',
                    })}
                  </Text>
                  <Text style={styles.dateSubText}>
                    {returnDate.toLocaleDateString('en-US', {
                      weekday: 'long',
                    })}
                  </Text>
                </View>
              </View>
            </TouchableOpacity>
          </View>

          {/* iOS pickers */}
          {showStartDatePicker && Platform.OS === 'ios' && (
            <View style={styles.iosDatePickerContainer}>
              <DateTimePicker
                value={startDate}
                mode="datetime"
                display="spinner"
                onChange={onStartDateChangeIOS}
                minimumDate={new Date()}
              />
              <View style={styles.iosButtonContainer}>
                <TouchableOpacity
                  style={styles.iosButton}
                  onPress={() => setShowStartDatePicker(false)}
                >
                  <Text style={styles.iosButtonText}>Done</Text>
                </TouchableOpacity>
              </View>
            </View>
          )}

          {showReturnDatePicker && Platform.OS === 'ios' && (
            <View style={styles.iosDatePickerContainer}>
              <DateTimePicker
                value={returnDate}
                mode="datetime"
                display="spinner"
                onChange={onReturnDateChangeIOS}
                minimumDate={startDate}
              />
              <View style={styles.iosButtonContainer}>
                <TouchableOpacity
                  style={styles.iosButton}
                  onPress={() => setShowReturnDatePicker(false)}
                >
                  <Text style={styles.iosButtonText}>Done</Text>
                </TouchableOpacity>
              </View>
            </View>
          )}

          {/* duration */}
          <Text style={[styles.label, { marginTop: 16, marginBottom: 10 }]}>
            Duration
          </Text>
          <View style={styles.durationRow}>
            {['Hourly', 'Daily', 'Weekly', 'Monthly'].map((d) => {
              const active = d === selectedDuration;
              return (
                <TouchableOpacity
                    key={d}
                    onPress={() => setSelectedDuration(d)}
                    style={[
                      styles.durationChip,
                      active && styles.durationChipActive,
                    ]}
                  >
                    <Text
                      style={[
                        styles.durationText,
                        active && styles.durationTextActive,
                      ]}
                    >
                      {d}
                    </Text>
                  </TouchableOpacity>
              );
            })}
          </View>

          {/* bike type */}
          <Text style={[styles.label, { marginTop: 16 }]}>Bike type</Text>
          <ScrollView
            horizontal
            showsHorizontalScrollIndicator={false}
            style={{ marginTop: 6 }}
          >
            {bikeData.map((b, idx) => {
              const active = selectedBikeType === b.id;
              return (
                <TouchableOpacity
                  key={idx}
                  style={[styles.bikeChip, active && styles.bikeChipActive]}
                  onPress={() => setSelectedBikeType(b.id)}
                  activeOpacity={0.85}
                >
                  <Image source={b.image} style={styles.bikeChipImg} />
                  <Text
                    style={[
                      styles.bikeChipText,
                      active && styles.bikeChipTextActive,
                    ]}
                  >
                    {b.name}
                  </Text>
                </TouchableOpacity>
              );
            })}
          </ScrollView>

          {/* other details */}
          <Text style={[styles.label, { marginTop: 16 }]}>
            Other details (delivery, helmet…)
          </Text>
          <TextInput
            style={styles.textArea}
            value={otherDetails}
            onChangeText={setOtherDetails}
            placeholder="Doorstep? Long ride? Extra helmet? Put here."
            placeholderTextColor="#9CA3AF"
            multiline
          />

          <TouchableOpacity
            style={[styles.submitBtn, isSubmitting && { opacity: 0.4 }]}
            onPress={handleSubmit}
            disabled={isSubmitting}
          >
            {isSubmitting ? (
              <ActivityIndicator color="#fff" />
            ) : (
              <Text style={styles.submitText}>Submit</Text>
            )}
          </TouchableOpacity>
        </View>
{/* ACTION ROW */}
        <View style={styles.quickRow}>
          <Text style={styles.sectionTitle}>Popular actions</Text>
          <ScrollView
            horizontal
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={{ paddingHorizontal: 16, gap: 10 }}
          >
            <View style={styles.actionChip}>
              <Ionicons name="bicycle" size={18} color={GREEN} />
              <Text style={styles.actionText}>Self-drive today</Text>
            </View>
            <View style={styles.actionChip}>
              <Ionicons name="calendar-outline" size={18} color={GREEN} />
              <Text style={styles.actionText}>Weekend plan</Text>
            </View>
            <View style={styles.actionChip}>
              <Ionicons name="business-outline" size={18} color={GREEN} />
              <Text style={styles.actionText}>Corporate ride</Text>
            </View>
            <View style={styles.actionChip}>
              <Ionicons name="map-outline" size={18} color={GREEN} />
              <Text style={styles.actionText}>Outstation</Text>
            </View>
          </ScrollView>
        </View>
        {/* HOW TO GET QUOTE */}
        {/* <Text style={styles.quoteTitle}>How To Get Quote From TransRentals?</Text>
        <View>
          <Animated.FlatList
            data={quoteData}
            keyExtractor={(item) => item.id}
            horizontal
            pagingEnabled
            showsHorizontalScrollIndicator={false}
            onScroll={handleScroll}
            scrollEventThrottle={16}
            renderItem={renderQuoteItem}
            contentContainerStyle={{
              paddingHorizontal: 5,
              paddingVertical: 10,
              justifyContent: 'center',
            }}
          />
          <View style={styles.paginationDots}>
            {quoteData.map((_, i) => (
              <View
                key={i}
                style={[
                  styles.dot,
                  i === activeQuoteIndex ? styles.activeDot : null,
                ]}
              />
            ))}
          </View>
        </View> */}

        {/* WHY SECTION */}
        <View style={styles.groupCard}>
          <Text style={styles.sectionTitleInside}>
            Why rent on TransRentals?
          </Text>
          <View style={styles.featureGrid}>
            <View style={styles.featureItem}>
              <View style={styles.iconWrap}>
                <Ionicons
                  name="shield-checkmark-outline"
                  size={20}
                  color={GREEN}
                />
              </View>
              <Text style={styles.featureTitle}>Verified vendors</Text>
              <Text style={styles.featureBody}>
                Only trusted partners, documents checked.
              </Text>
            </View>
            <View style={styles.featureItem}>
              <View style={styles.iconWrap}>
                <Ionicons
                  name="swap-horizontal-outline"
                  size={20}
                  color={GREEN}
                />
              </View>
              <Text style={styles.featureTitle}>Multiple quotes</Text>
              <Text style={styles.featureBody}>
                Compare prices and models before confirming.
              </Text>
            </View>
            <View style={styles.featureItem}>
              <View style={styles.iconWrap}>
                <Ionicons name="wallet-outline" size={20} color={GREEN} />
              </View>
              <Text style={styles.featureTitle}>Transparent billing</Text>
              <Text style={styles.featureBody}>
                No surprise charges — everything upfront.
              </Text>
            </View>
          </View>
        </View>

        {/* CITIES */}
        <View style={styles.groupCard}>
          <Text style={styles.sectionTitleInside}>Popular cities</Text>
          <View style={styles.cityWrap}>
            {popularCities.map((c, i) => (
              <View key={i} style={styles.cityChip}>
                <Ionicons name="location-outline" size={14} color={GREEN} />
                <Text style={styles.cityText}>{c}</Text>
              </View>
            ))}
          </View>
        </View>

        {/* FAQ DARK */}
        <View style={styles.faqSec}>
          <Text style={styles.faqTitle}>FAQs about bike rental</Text>
          {faqs.map((item, idx) => {
            const open = expandedIndex === idx;
            return (
              <View key={idx} style={styles.faqItem}>
                <TouchableOpacity
                  style={styles.faqHead}
                  onPress={() => toggleFAQ(idx)}
                >
                  <Text style={styles.faqQ}>{item.question}</Text>
                  <Ionicons
                    name={open ? 'chevron-up' : 'chevron-down'}
                    size={18}
                    color="#E2E8F0"
                  />
                </TouchableOpacity>
                {open && <Text style={styles.faqA}>{item.answer}</Text>}
              </View>
            );
          })}
        </View>
      </ScrollView>

      {/* PHONE MODAL */}
      <Modal
        visible={isPhoneModal}
        transparent
        animationType="fade"
        onRequestClose={() => setIsPhoneModal(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalCard}>
            <Text style={styles.modalTitle}>Phone required</Text>
            <Text style={styles.modalBody}>
              Add your phone number once and book faster next time.
            </Text>
            <TouchableOpacity
              style={styles.modalBtn}
              onPress={() => {
                setIsPhoneModal(false);
                navigation.navigate('EditProfileScreen');
              }}
            >
              <Text style={styles.modalBtnText}>Go to Profile</Text>
            </TouchableOpacity>
            <TouchableOpacity
              onPress={() => setIsPhoneModal(false)}
              style={{ marginTop: 10 }}
            >
              <Text style={{ color: '#94A3B8' }}>Maybe later</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>

      {/* ANDROID PICKER */}
      {androidPickerVisible && Platform.OS === 'android' && (
        <DateTimePicker
          value={androidPickingTarget === 'start' ? startDate : returnDate}
          mode={androidPickerMode}
          display="default"
          onChange={onAndroidChange}
          minimumDate={
            androidPickingTarget === 'start' ? new Date() : startDate
          }
        />
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: BG },
  container: { backgroundColor: 'transparent' },
  topBar: {
    height: 52,
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    justifyContent: 'space-between',
    backgroundColor: BG,
  },
  backBtn: {
    width: 40,
    height: 40,
    borderRadius: 999,
    backgroundColor: '#FFFFFF',
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOpacity: 0.03,
    shadowRadius: 8,
    shadowOffset: { width: 0, height: 3 },
  },
  topTitle: { fontSize: 17, fontWeight: '700', color: '#0F172A' },

  heroWrap: {
    height: 190,
    marginHorizontal: 14,
    marginTop: 4,
    borderRadius: 20,
    overflow: 'hidden',
    position: 'relative',
  },
  heroGradient: { ...StyleSheet.absoluteFillObject, backgroundColor: '#0F172A' },
  heroGlow: {
    position: 'absolute',
    top: -40,
    right: -50,
    width: 180,
    height: 180,
    backgroundColor: 'rgba(9,179,104,0.35)',
    borderRadius: 999,
  },
  heroContent: { position: 'absolute', left: 18, top: 24, width: width * 0.55 },
  heroPill: {
    backgroundColor: 'rgba(248,250,252,0.2)',
    color: '#fff',
    paddingHorizontal: 12,
    paddingVertical: 4,
    borderRadius: 999,
    fontSize: 11,
    alignSelf: 'flex-start',
    marginBottom: 8,
  },
  heroHeading: { fontSize: 22, fontWeight: '700', color: '#fff' },
  heroSub: {
    fontSize: 12.5,
    color: 'rgba(255,255,255,0.7)',
    marginTop: 6,
    lineHeight: 18,
  },
  heroImg: {
    position: 'absolute',
    right: -10,
    bottom: -6,
    width: 180,
    height: 150,
    resizeMode: 'contain',
  },

  formCard: {
    backgroundColor: '#FFFFFF',
    marginHorizontal: 14,
    // marginTop: -20,
    borderRadius: 22,
    // padding: 12,
    paddingVertical: 12,
    paddingHorizontal: 16,
    shadowColor: '#000',
    shadowOpacity: 0.04,
    shadowRadius: 14,
    shadowOffset: { width: 0, height: 6 },
  },
  formHeaderRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  formTitle: { fontSize: 18, fontWeight: '700', color: '#0F172A' },
  formDesc: { fontSize: 12, color: '#94A3B8', marginTop: 2 },
  securePill: {
    backgroundColor: GREEN,
    borderRadius: 999,
    paddingHorizontal: 10,
    paddingVertical: 4,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    marginBottom: 25,
  },
  securePillText: { color: '#fff', fontSize: 12, fontWeight: '600' },

  // location block (copied from car)
  locationBlock: {
    backgroundColor: '#F8FAFC',
    borderRadius: 16,
    borderWidth: 1,
    borderColor: 'rgba(15,23,42,0.04)',
    padding: 12,
    marginBottom: 12,
  },
  smallLabel: {
    fontSize: 11.5,
    color: '#94A3B8',
    marginBottom: 4,
  },
  locationRow: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    borderWidth: 1,
    borderColor: 'rgba(148,163,184,0.25)',
    paddingHorizontal: 12,
    minHeight: 54,
    gap: 8,
  },
  locationInput: {
    flex: 1,
    fontSize: 15,
    color: '#0F172A',
    paddingVertical: 6,
  },

  suggestionBox: {
    position: 'absolute',
    top: 100,
    left: 0,
    right: 0,
    backgroundColor: '#FFFFFF',
    borderRadius: 14,
    borderWidth: 0.5,
    borderColor: '#E2E8F0',
    zIndex: 99,
    elevation: 10, // 👈 add this
  },
  suggestionItem: {
    paddingHorizontal: 12,
    paddingVertical: 9,
    borderBottomWidth: 0.5,
    borderColor: '#EDF2F7',
  },
  suggestionText: { color: '#0F172A' },
  noResult: { padding: 10, textAlign: 'center', color: '#94A3B8' },

  // DATE cards (same as car)
  dateRow: {
    flexDirection: 'row',
    gap: 12,
  },
  dateCard: {
    flex: 1,
    backgroundColor: '#FFFFFF',
    borderRadius: 14,
    borderWidth: 1,
    borderColor: 'rgba(148,163,184,0.25)',
    paddingHorizontal: 12,
    paddingVertical: 8,
    shadowColor: '#000',
    shadowOpacity: 0.01,
    shadowRadius: 6,
    shadowOffset: { width: 0, height: 3 },
  },
  dateLabel: {
    fontSize: 12,
    fontWeight: '600',
    color: '#94A3B8',
    textTransform: 'uppercase',
    marginBottom: 6,
    letterSpacing: 0.4,
  },
  dateContent: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  dateIconWrap: {
    width: 30,
    height: 30,
    borderRadius: 10,
    backgroundColor: '#F1F5F9',
    justifyContent: 'center',
    alignItems: 'center',
  },
  dateMainText: {
    fontSize: 14,
    fontWeight: '700',
    color: '#0F172A',
  },
  dateSubText: {
    fontSize: 11,
    color: '#94A3B8',
    marginTop: 1,
  },

  // iOS date pickers
  iosDatePickerContainer: {
    backgroundColor: '#fff',
    borderRadius: 12,
    marginTop: 8,
    padding: 10,
    shadowColor: '#000',
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  iosButtonContainer: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
    paddingTop: 8,
    borderTopWidth: 1,
    borderTopColor: '#f0f0f0',
    marginTop: 8,
  },
  iosButton: {
    backgroundColor: '#09B368',
    paddingHorizontal: 16,
    paddingVertical: 6,
    borderRadius: 6,
  },
  iosButtonText: { color: '#fff', fontWeight: '600' },

  // duration
  label: {
    fontSize: 15,
    fontWeight: '700',
    color: '#0F172A',
    marginBottom: 5,
  },
  durationRow: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
  },
  durationChip: {
    backgroundColor: '#F8FAFC',
    borderRadius: 999,
    paddingHorizontal: 15,
    paddingVertical: 8,
  },
  durationChipActive: {
    backgroundColor: 'rgba(9,179,104,0.08)',
    borderColor: 'rgba(9,179,104,0.4)',
    borderWidth: 1,
  },
  durationText: {
    fontSize: 13,
    color: '#0F172A',
  },
  durationTextActive: {
    color: '#055F3B',
    fontWeight: '600',
  },

  // bike chips (same as before but matched)
  bikeChip: {
    width: 130,
    backgroundColor: '#F8FAFC',
    borderRadius: 14,
    padding: 8,
    marginRight: 10,
    alignItems: 'center',
    gap: 6,
    borderWidth: 1,
    borderColor: 'transparent',
  },
  
quickRow: {
    marginTop: 16,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '700',
    color: '#0F172A',
    marginBottom: 10,
    marginLeft: 16,
  },
  actionChip: {
    backgroundColor: '#FFFFFF',
    flexDirection: 'row',
    alignItems: 'center',
    gap: 7,
    paddingVertical: 9,
    paddingHorizontal: 13,
    borderRadius: 16,
    shadowColor: '#000',
    shadowOpacity: 0.02,
    shadowRadius: 4,
  },
  bikeChipActive: {
    backgroundColor: '#FFFFFF',
    borderColor: 'rgba(9,179,104,0.35)',
    shadowColor: '#000',
    shadowOpacity: 0.02,
    shadowRadius: 12,
    shadowOffset: { width: 0, height: 6 },
  },
  bikeChipImg: { width: 70, height: 45, resizeMode: 'contain' },
  bikeChipText: { fontSize: 13, textAlign: 'center', color: '#475569' },
  bikeChipTextActive: { color: '#0F172A', fontWeight: '600' },

  textArea: {
    backgroundColor: '#F8FAFC',
    borderRadius: 10,
    borderWidth: 1,
    borderColor: 'rgba(15,23,42,0.05)',
    minHeight: 84,
    padding: 10,
    textAlignVertical: 'top',
    fontSize: 12.5,
  },
  submitBtn: {
    marginTop: 15,
    backgroundColor: GREEN,
    borderRadius: 999,
    paddingVertical: 11,
    alignItems: 'center',
  },
  submitText: { color: '#FFFFFF', fontSize: 15, fontWeight: '700' },

  // quote section
  quoteTitle: {
    marginTop: 20,
    marginLeft: 23,
    fontSize: 16,
    fontWeight: '700',
    color: '#000',
  },
  quoteTextWrapperMain: {
    width: '100%',
    flexDirection: 'row',
    alignContent: 'center',
    marginBottom: 10,
  },
  quoteCard: {
    marginHorizontal: 20,
    marginTop: 10,
    backgroundColor: 'white',
    borderRadius: 10,
    paddingVertical: 25,
    paddingHorizontal: 20,
    shadowColor: '#000',
    shadowOpacity: 0.25,
    shadowRadius: 3.55,
    shadowOffset: { width: 0, height: 0 },
    elevation: 4,
  },
  quoteNumberCircle: {
    width: 60,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 10,
    position: 'absolute',
    opacity: 0.8,
    bottom: -70,
  },
  quoteNumber: { fontWeight: '700', fontSize: 100, color: '#DDF7E8' },
  quoteHeading: {
    fontWeight: '700',
    fontSize: 17,
    color: '#404040',
    marginLeft: 65,
    marginTop: 5,
  },
  quoteBody: {
    fontWeight: '400',
    fontSize: 15,
    color: '#4D4C4C',
    lineHeight: 18,
    textAlign: 'center',
    marginTop: 10,
  },
  quoteBodyMain: { width: '100%' },
  paginationDots: {
    marginTop: 15,
    flexDirection: 'row',
    justifyContent: 'center',
    marginBottom: 20,
  },
  dot: {
    width: 10,
    height: 10,
    borderRadius: 5,
    backgroundColor: '#D9D9D9',
    marginHorizontal: 5,
  },
  activeDot: { backgroundColor: '#2FCD72' },

  groupCard: {
    backgroundColor: '#FFFFFF',
    marginHorizontal: 14,
    marginTop: 16,
    borderRadius: 20,
    padding: 14,
  },
  sectionTitleInside: {
    fontSize: 18,
    fontWeight: '700',
    color: '#0F172A',
    marginBottom: 10,
  },
  featureGrid: {
    gap: 10,
  },
  featureItem: {
    backgroundColor: '#F8FAFC',
    borderRadius: 16,
    padding: 10,
    gap: 5,
  },
  iconWrap: {
    width: 30,
    height: 30,
    borderRadius: 999,
    backgroundColor: 'rgba(9,179,104,0.12)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  featureTitle: {
    fontWeight: '600',
    color: '#0F172A',
    fontSize: 15,
  },
  featureBody: {
    fontSize: 12,
    color: '#94A3B8',
  },
  cityWrap: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
  },
  cityChip: {
    flexDirection: 'row',
    gap: 4,
    backgroundColor: 'rgba(9,179,104,0.1)',
    borderRadius: 999,
    paddingHorizontal: 12,
    paddingVertical: 5,
    alignItems: 'center',
  },
  cityText: {
    fontSize: 14,
    color: '#0F172A',
    fontWeight: '500',
  },
  faqSec: { backgroundColor: '#0F172A', marginTop: 16, padding: 16 },
  faqTitle: {
    fontSize: 18,
    fontWeight: '700',
    color: '#FFFFFF',
    marginBottom: 12,
  },
  faqItem: {
    borderBottomColor: 'rgba(226,232,240,0.1)',
    borderBottomWidth: 1,
    paddingVertical: 10,
  },
  faqHead: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  faqQ: { color: '#FFFFFF', fontSize: 14, flex: 1, marginRight: 10 },
  faqA: { color: '#CBD5F5', fontSize: 12.5, marginTop: 6, lineHeight: 18 },

  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(15,23,42,0.4)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalCard: {
    width: 300,
    backgroundColor: '#FFFFFF',
    borderRadius: 18,
    padding: 16,
    alignItems: 'center',
  },
  modalTitle: {
    fontSize: 16,
    fontWeight: '700',
    color: '#0F172A',
    marginBottom: 6,
  },
  modalBody: {
    textAlign: 'center',
    color: '#94A3B8',
    fontSize: 12.5,
    marginBottom: 14,
  },
  modalBtn: {
    backgroundColor: GREEN,
    borderRadius: 999,
    paddingHorizontal: 20,
    paddingVertical: 10,
  },
  modalBtnText: {
    color: '#fff',
    fontWeight: '700',
  },
});
