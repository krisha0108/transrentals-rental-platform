// TokenHistoryScreen.js
import React, { useEffect, useState } from 'react';
import { View, Text, FlatList, ActivityIndicator, StyleSheet, Alert, Image, TouchableOpacity } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import api from '../api';
import Ionicons from 'react-native-vector-icons/Ionicons';
import { useNavigation } from '@react-navigation/native';
export default function TokenHistoryScreen() {
  const [loading, setLoading] = useState(true);
  const [history, setHistory] = useState([]);
const navigation = useNavigation();
  useEffect(() => {
    (async () => {
      try {
        const customerData = await AsyncStorage.getItem('customer');
        const customer = JSON.parse(customerData);
        const { data } = await api.get('/spin/history', {
          params: { customer_id: customer.id }
        });
        setHistory(data.history || []);
      } catch (e) {
        console.log('History error', e?.response?.data || e.message);
        Alert.alert('Error', 'Could not load token history');
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  if (loading) {
    return (
      <View style={styles.center}>
        <ActivityIndicator size="large" />
      </View>
    );
  }

  return (
    <View style={styles.container}>
         <View style={styles.header}>
                            <TouchableOpacity onPress={() => navigation.goBack()}>
                              <Ionicons name="arrow-back" size={24} color="#404040" />
                            </TouchableOpacity>
                            <Text style={styles.headerText}>Token History</Text>
                          </View>
      {history.length === 0 ? (
        <Text style={styles.empty}>No token history found</Text>
      ) : (
        <FlatList
          data={history}
          keyExtractor={(item) => item.id.toString()}
          renderItem={({ item }) => (
            <View style={styles.row}>
              <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}>
               <Image source={require('../../assets/spinner-win.png')} style={{width: 50, height: 50}}/>
               </View>
               <View style={{ flex: 1, marginLeft: 10 }}>
                 <Text style={styles.source}>{item.source}</Text>
            
               <Text style={styles.date}>
                {new Date(item.created_at).toLocaleString()}
              </Text>
             
              </View>
               {/* <Text style={styles.tokens}>+{item.tokens} tokens</Text> */}
                 <TouchableOpacity style={styles.rewardBtn} >
                             <Image
                               source={{ uri: 'https://app.transrentals.in/assets/images/coin-back.png' }}
                               style={{ width: 20, height: 20, marginRight: 4 }}
                             />
                             <Text style={styles.rewardText}>+{item.tokens}</Text>
                           </TouchableOpacity>
            </View>
          )}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1,  backgroundColor: '#f6f7fb' },
   header: {
    height: 60,
    backgroundColor: '#F9F7F7',
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 20,
    marginBottom:10,
    elevation: 5,  // Adds shadow to the header
  },
  headerText: {
    color: '#404040',
    fontSize: 20,
    marginLeft: 10,  // Adjust space between back button and title
  },
  center: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  empty: { textAlign: 'center', marginTop: 20, color: '#64748b' },
  row: {
    display: 'flex', flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    backgroundColor: '#fff', borderRadius: 12, marginHorizontal:16, paddingHorizontal: 16,paddingVertical:10, marginBottom: 16, shadowColor: '#000', shadowOpacity: 0.05, shadowRadius: 8, elevation: 2,
    // paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#e5e7eb'
  },
  tokens: { fontWeight: 'bold', fontSize: 16, color: '#16a34a' },
  source: { color: '#232830ff', fontSize: 16 },
  date: { fontSize: 12, color: '#94a3b8' },
    rewardBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#f0fdf4',
    borderRadius: 8,
    paddingVertical: 4,
    paddingHorizontal: 8
  },
  rewardText: { color: '#16a34a', fontWeight: '700' }
});
