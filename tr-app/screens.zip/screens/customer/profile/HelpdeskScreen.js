import React, {useState, useEffect} from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  Image,
  FlatList,
  StyleSheet,
  ScrollView,
  Alert,
} from 'react-native';
// import * as ImagePicker from 'expo-image-picker';
import {launchImageLibrary} from 'react-native-image-picker';
import {RefreshControl} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import {Modal} from 'react-native';
import {useNavigation} from '@react-navigation/native';
import Ionicons from 'react-native-vector-icons/Ionicons';
import {SafeAreaView} from 'react-native-safe-area-context';
import api from '../../api';
const HelpDeskScreen = () => {
  const [heading, setHeading] = useState('');
  const [problem, setProblem] = useState('');
  const [imageUri, setImageUri] = useState(null);
  const [refreshing, setRefreshing] = useState(false);
  const [tickets, setTickets] = useState([]);
  const [loading, setLoading] = useState(true);
  const [imageFile, setImageFile] = useState(null);
  const [modalVisible, setModalVisible] = useState(false);
  const [submitLoading, setSubmitLoading] = useState(false);
  const navigation = useNavigation();

  const fetchTickets = async () => {
    try {
      setRefreshing(true);
      const customerData = await AsyncStorage.getItem('customer');
      const customer = JSON.parse(customerData);
      const customerId = customer.id;

      const response = await api.get(
        `/customer/helpdesk/tickets?customer_id=${customerId}`,
      );
      console.log('Ticket response:', response.data);
      if (response.data.tickets) {
        setTickets(response.data.tickets);
      }
    } catch (error) {
      console.error('Error fetching tickets:', error.message);
    } finally {
      setRefreshing(false);
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchTickets();
  }, []);

  const pickImage = () => {
    launchImageLibrary({mediaType: 'photo'}, response => {
      if (response.assets && response.assets.length > 0) {
        const asset = response.assets[0];
        setImageUri(asset.uri);
        setImageFile({
          uri: asset.uri,
          type: asset.type,
          name: asset.fileName || 'ticket_image.jpg',
        });
      }
    });
  };
  const handleRefresh = async () => {
    await fetchTickets(); // refetch data
  };

  const handleSubmit = async () => {
    try {
      setSubmitLoading(true);
      const customerData = await AsyncStorage.getItem('customer');
      const customer = JSON.parse(customerData);
      const customerId = customer.id;

      const formData = new FormData();
      formData.append('heading', heading);
      formData.append('problem', problem);
      formData.append('customer_id', customerId);
      if (imageFile) {
        formData.append('image', imageFile);
      }

      const response = await api.post('/customer/helpdesk/store', formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      });

      // const result = await response.json();
      if (response.data.message === 'Ticket submitted successfully!') {
        Alert.alert('Success', 'Your ticket has been submitted');
        setHeading('');
        setProblem('');
        setImageUri(null);
        setImageFile(null);
        fetchTickets(); // Refresh list
        setModalVisible(false);
      } else {
        Alert.alert('Error', 'Something went wrong!');
      }
    } catch (error) {
      console.error('Ticket submission error:', error);
    } finally {
      setSubmitLoading(false); // Stop loading
    }
  };

  return (
    <SafeAreaView style={{flex: 1}}>
      <View style={{flex: 1}}>
        <View style={styles.header}>
          <TouchableOpacity onPress={() => navigation.goBack()}>
            <Ionicons name="arrow-back" size={24} color="#404040" />
          </TouchableOpacity>
          <Text style={styles.headerText}>Helpdesk</Text>
          <TouchableOpacity
            style={styles.newTicketBtn}
            onPress={() => setModalVisible(true)}>
            <Text style={styles.newTicketBtnText}>+ Add</Text>
          </TouchableOpacity>
        </View>

        <ScrollView
          style={styles.scrollView}
          refreshControl={
            <RefreshControl
              refreshing={refreshing}
              onRefresh={handleRefresh}
              colors={['#ff3333ff']}
              tintColor="#ff3333ff"
            />
          }
          showsVerticalScrollIndicator={false}>
          <Text style={styles.sectionTitle}>My Tickets</Text>
          
          {tickets.length === 0 ? (
            <View style={styles.emptyContainer}>
              <Text style={styles.emptyText}>No tickets found</Text>
              <Text style={styles.emptySubText}>Create your first ticket to get started</Text>
            </View>
          ) : (
            tickets.map(ticket => (
              <View key={ticket.id} style={styles.card}>
                <View style={styles.cardHeader}>
                  <Text style={styles.cardHeading}>{ticket.heading}</Text>
                  <View style={styles.statusBadge}>
                    <Text style={styles.statusText}>{ticket.status}</Text>
                  </View>
                </View>
                
                <View style={styles.cardContent}>
                  <Text style={styles.problemText}>{ticket.problem}</Text>
                  
                  <View style={styles.imageContainer}>
                  {ticket.image && (
  <Image
    source={{ uri: `https://app.transrentals.in/storage/${ticket.image}` }}
    style={styles.ticketImage}
    resizeMode="contain"
  />
)}
                  </View>
                </View>
              </View>
            ))
          )}
          
          <View style={styles.bottomPadding} />
        </ScrollView>
      </View>

      <Modal visible={modalVisible} animationType="slide" transparent={true}>
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <Text style={styles.title}>Submit Ticket</Text>

            <TextInput
              style={styles.input}
              placeholder="Ticket Heading"
              placeholderTextColor="#333"
              value={heading}
              onChangeText={setHeading}
            />
            <TextInput
              style={[styles.input, styles.textarea]}
              placeholder="Describe your issue"
              placeholderTextColor="#333"
              value={problem}
              onChangeText={setProblem}
              multiline
            />

            <TouchableOpacity style={styles.uploadBtn} onPress={pickImage}>
              <Text style={styles.uploadBtnText}>
                {imageUri ? 'Image Selected' : 'Choose File'}
              </Text>
            </TouchableOpacity>
            {imageUri && (
              <Image source={{uri: imageUri}} style={styles.previewImage} />
            )}

            <TouchableOpacity
              style={[
                styles.submitBtn,
                submitLoading && {backgroundColor: '#ccc'},
              ]}
              onPress={handleSubmit}
              disabled={submitLoading}>
              <Text style={styles.submitBtnText}>
                {submitLoading ? 'Submitting...' : 'Submit Ticket'}
              </Text>
            </TouchableOpacity>

            <TouchableOpacity
              onPress={() => setModalVisible(false)}
              style={{marginTop: 10}}>
              <Text style={{color: 'red', textAlign: 'center'}}>Cancel</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    backgroundColor: '#fff',
  },
  header: {
    height: 60,
    backgroundColor: '#F9F7F7',
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 20,
    marginBottom: 10,
    elevation: 5,
    justifyContent: 'space-between',
  },
  title: {
    fontWeight: 'bold',
    fontSize: 17,
    marginBottom: 10,
  },
  headerText: {
    color: '#404040',
    fontSize: 20,
    paddingRight: 90,
  },
  input: {
    borderWidth: 1,
    borderColor: '#ddd',
    borderRadius: 6,
    padding: 10,
    marginBottom: 10,
  },
  textarea: {
    height: 80,
  },
  uploadBtn: {
    backgroundColor: '#eee',
    padding: 10,
    borderRadius: 6,
    alignItems: 'center',
    marginBottom: 10,
  },
  uploadBtnText: {
    color: '#333',
  },
  previewImage: {
    width: 100,
    height: 100,
    borderRadius: 6,
    marginBottom: 10,
  },
  submitBtn: {
    backgroundColor: '#007bff',
    padding: 12,
    borderRadius: 6,
    alignItems: 'center',
    marginBottom: 20,
  },
  submitBtnText: {
    color: '#fff',
    fontWeight: 'bold',
  },
  sectionTitle: {
    width: '100%',
    fontSize: 20,
    color: '#404040',
    fontWeight: 'bold',
    marginBottom: 8,
    paddingLeft: 20,
    marginTop: 20,
  },
  card: {
    backgroundColor: '#fff',
    marginHorizontal: 20,
    marginVertical: 8,
    borderRadius: 12,
    padding: 16,
    elevation: 3,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.1,
    shadowRadius: 3.84,
  },
  cardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  cardHeading: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#404040',
    flex: 1,
  },
  statusBadge: {
    backgroundColor: '#28a745',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 20,
  },
  statusText: {
    color: '#fff',
    fontSize: 12,
    fontWeight: 'bold',
  },
  cardContent: {
    gap: 12,
  },
  problemText: {
    fontSize: 14,
    color: '#666',
    lineHeight: 20,
  },
  imageContainer: {
    alignItems: 'center',
  },
  noImageText: {
    fontSize: 12,
    color: '#999',
    fontStyle: 'italic',
  },
  ticketImage: {
    width: '100%',
    height: 150,
    resizeMode: 'cover',
    borderRadius: 4,
  },
  newTicketBtn: {
    backgroundColor: '#28a745',
    padding: 9,
    borderRadius: 5,
    alignItems: 'center',
    marginBottom: 10,
    marginRight: 10,
    marginTop: 10,
    width: '100',
    height: '40',
  },
  newTicketBtnText: {
    color: '#fff',
    fontWeight: 'bold',
    fontSize: 16,
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalContent: {
    backgroundColor: '#fff',
    padding: 20,
    width: '90%',
    borderRadius: 10,
    elevation: 5,
  },
  scrollView: {
    flex: 1,
  },
  emptyContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 60,
    marginHorizontal: 20,
  },
  emptyText: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#666',
    marginBottom: 8,
  },
  emptySubText: {
    fontSize: 14,
    color: '#999',
    textAlign: 'center',
  },
  bottomPadding: {
    height: 20,
  },
});

export default HelpDeskScreen;
