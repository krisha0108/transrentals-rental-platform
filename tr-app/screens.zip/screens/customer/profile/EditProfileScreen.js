import React, { useState, useEffect ,useRef } from 'react';
import { View, Text, TextInput, TouchableOpacity, ActivityIndicator, Image,  StyleSheet ,Alert } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useNavigation } from '@react-navigation/native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { launchImageLibrary } from 'react-native-image-picker';
import Icon from 'react-native-vector-icons/Ionicons'; // <-- Import back icon
import axios from 'axios';
import api from '../../api';
const EditProfileScreen = () => {
  const [customer, setCustomer] = useState(null);
  const [loading, setLoading] = useState(false);  
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
const [hidePassword, setHidePassword] = useState(true);
  const [password, setPassword] = useState('');
  const [phone, setPhone] = useState('');
  const [profileImage, setProfileImage] = useState(null); // State to store the profile image
  const navigation = useNavigation();

  useEffect(() => {
    const fetchCustomerData = async () => {
      const customerData = await AsyncStorage.getItem('customer');
      console.log("customer data", customerData);
      if (customerData) {
        const customer = JSON.parse(customerData);
        setCustomer(customer);
        setName(customer.name);
        setEmail(customer.email);
    if (customer.phone) {
  setPhone(customer.phone);
}
        console.log(customer.image);

        if (customer.image) {
         
          setProfileImage(`https://app.transrentals.in/storage/profile_images/${customer.image}`);
        }
      }
      setLoading(false);
    };

    fetchCustomerData();
  }, []);
  
 const handleSaveProfile = async () => {
    const formData = new FormData();
    formData.append('customer_id', customer.id);

if (password.trim() !== '') {
  formData.append('password', password);
}
 
    if (name !== customer.name) formData.append('name', name);
    if (email !== customer.email) formData.append('email', email);
if (phone) formData.append('phone', phone); 

    // const phone = customer.phone;
    formData.append('phone', phone); 
    

    if (profileImage && profileImage !== customer.image) {
      const localUri = profileImage;
      const filename = localUri.split('/').pop();
      const type = `image/jpeg`;

      formData.append('image', {
        uri: localUri,
        type,
        name: filename,
      });
    }

    try {
      setLoading(true); 

      const token = await AsyncStorage.getItem('token'); 

      if (!token) {
        alert('Authorization token not found. Please log in again.');
        return;
      }

      const response = await api.post('/update-profile', formData, {
  headers: {
    'Content-Type': 'multipart/form-data',
    Authorization: `Bearer ${token}`,
  },
});

// const result = response.data;
      // console.log('Raw Response Text:', resultText);

      try {
        const result = response.data;
        console.log('Parsed Response:', result);

        if (result.success) {
          alert(result.message);

     
          const updatedCustomer = { ...customer, name, email,phone: result.customer.phone, has_password: result.has_password, image: result.customer.image || profileImage };
          await AsyncStorage.setItem('customer', JSON.stringify(updatedCustomer));
          setCustomer(updatedCustomer); 
          setName(updatedCustomer.name);
          setEmail(updatedCustomer.email);
          setPhone(updatedCustomer.phone);
          setProfileImage(`https://app.transrentals.in/storage/profile_images/${updatedCustomer.image}`);
        } else {
          alert('Failed to update profile');
        }
      } catch (error) {
        console.error('Error parsing response:', error);
        alert('The response is not in valid JSON format. Please try again later.');
      }

    } catch (error) {
      console.log(error);
      alert('Something went wrong. Please try again.');
    } finally {
      setLoading(false); 
    }
  };

  const handleImagePick = () => {
    launchImageLibrary({ mediaType: 'photo', quality: 0.5 }, (response) => {
      if (response.didCancel) {
        console.log('Image picker canceled');
      } else if (response.errorCode) {
        console.log('Image picker error: ', response.errorMessage);
      } else {
        setProfileImage(response.assets[0].uri); 
      }
    });
  };

  if (loading) {
    return (
      <SafeAreaView style={styles.container}>
        <ActivityIndicator size="large" color="#0000ff" />
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
     
      <View style={styles.headerContainer}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backButton}>
          <Icon name="arrow-back" size={24} color="#000" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Edit Profile</Text>
      </View>

  
     
       <TouchableOpacity style={styles.avatarWrapper} onPress={handleImagePick}>
        {profileImage ? (
          <Image source={{ uri: profileImage }} style={styles.avatarImage} resizeMode="cover" />
        ) : (
          <Image source={require('../../../assets/logp-1.png')} style={styles.avatarImage} resizeMode="cover" />
        )}
      
        <View style={styles.editIconWrapper}>
          <Icon name="pencil" size={18} color="#000" />
        </View>
      </TouchableOpacity>

      <Text style={styles.label}>Name </Text>
      <TextInput
        style={styles.input}
        placeholder="Name"
        value={name}
        onChangeText={setName}
      />

      <Text style={styles.label}>Email </Text>
      <TextInput
        style={styles.input}
        placeholder="Email"
        value={email}
        onChangeText={setEmail}
        keyboardType="email-address"
      />

      <Text style={styles.label}>Phone</Text>
<TextInput
  style={styles.input}
  placeholder="Phone"
  value={phone}
  onChangeText={setPhone}
  keyboardType="phone-pad"
/>
         <Text style={styles.label}>{customer?.has_password ? 'Enter New Password' : 'Create Password'} </Text>
      <View style={styles.inputPass}>
        <TextInput
        style={styles.inputpassword}
          placeholder="Create Password"
          value={password}
          onChangeText={setPassword}
          secureTextEntry={hidePassword}
          color="#000"
        />
        <TouchableOpacity onPress={() => setHidePassword(!hidePassword)} style={{ padding: 10 }}>
          <Icon name={hidePassword ? 'eye-off' : 'eye'} size={20} color="gray" />
        </TouchableOpacity>
      </View>
      <TouchableOpacity style={styles.button} onPress={handleSaveProfile}>
        <Text style={styles.buttonText}>Save Changes</Text>
      </TouchableOpacity>

    </SafeAreaView>
  );
};


const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: '#fff',
  },
  headerContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 15,
  },
  backButton: {
    marginRight: 10,
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#000',
  },
  avatarWrapper: {
    alignSelf: 'center',
    marginVertical: 20,
    position: 'relative',
  },
  avatarImage: {
    width: 100,
    height: 100,
    borderRadius: 50,
    borderWidth: 1,
    borderColor: '#ccc',
  },
  editIconWrapper: {
    position: 'absolute',
    bottom: 8,
    right: 0,
    backgroundColor: '#fff',
    borderRadius: 20,
    padding: 5,
    borderWidth: 1,
    borderColor: '#000',
  },
  input: {
    height: 45,
    borderColor: '#ccc',
    borderWidth: 1,
    borderRadius: 6,
    marginBottom: 10,
    paddingHorizontal: 15,
  },
  inputpassword: {
    width: '85%',
  },
  button: {
    backgroundColor: '#09B368',
    paddingVertical: 12,
    borderRadius: 10,
    alignItems: 'center',
    marginTop: 10,
  },
  buttonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
  },
  label: {
    fontSize: 16,
    padding: 5,
  },
  avatarImage: {
    width: 100,
    height: 100,
    borderRadius: 50,
    marginBottom: 10,
    borderWidth: 1,
   
  },
  avatarText: {
    fontSize: 16,
    color: '#09B368',
  },
   otpModal: {
    position: 'absolute',
    top: '30%',
    left: 0,
    right: 0,
    padding: 20,
    backgroundColor: 'white',
    borderRadius: 10,
    justifyContent: 'center',
    alignItems: 'center',
  },
  otpModalText: {
    fontSize: 18,
    marginBottom: 15,
  },
  otpInputContainer: {
    flexDirection: 'row',
    marginBottom: 15,
  },
  otpBox: {
    width: 50,
    height: 55,
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 10,
    fontSize: 22,
    textAlign: 'center',
    fontWeight: '600',
    backgroundColor: '#fff',
    margin: 5,
  },
  verifyButton: {
    backgroundColor: '#09B368',
    height: 54,
    borderRadius: 8,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 12,
  },
  verifyText: {
    color: '#fff',
    fontSize: 18,
    fontWeight: '600',
  },
  inputPassText: {
    height: 45,
    borderColor: '#ccc',
  },
  inputPass: {
    flexDirection: 'row', 
    borderWidth: 1,       
    borderColor: '#ddd',
    borderRadius: 8,
    marginBottom: 20,
    backgroundColor: '#fff',
    justifyContent: 'space-between',
    paddingHorizontal: 10,
    height: 45,
  },
});

export default EditProfileScreen;
