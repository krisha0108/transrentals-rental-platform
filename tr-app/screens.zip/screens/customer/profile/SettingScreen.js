import React, {useState, useEffect} from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  Image,
  StyleSheet,
  Linking,
  SafeAreaView,
  ScrollView,
  RefreshControl,
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import Icon from 'react-native-vector-icons/Feather';
import Ionicons from 'react-native-vector-icons/Ionicons';
import {useNavigation} from '@react-navigation/native';
import {Share} from 'react-native';
import ProfileCheckModal from './ProfileCheckModal';
import { GoogleSignin } from '@react-native-google-signin/google-signin';
import DeviceInfo from 'react-native-device-info';
// import { SafeAreaView } from 'react-native-safe-area-context';

const LATEST_VERSION = '8.0';
const SettingScreen = ({navigation}) => {
  const currentVersion = DeviceInfo.getVersion();
  const [customer, setCustomer] = useState(null);
  const [loading, setLoading] = useState(true);
  const [isUpdateAvailable, setIsUpdateAvailable] = useState(false);
  const [refreshing, setRefreshing] = useState(false);

  const onRefresh = async () => {
    setRefreshing(true);
    try {
      const customerData = await AsyncStorage.getItem('customer');
      if (customerData) {
        const parsedCustomer = JSON.parse(customerData);
        setCustomer(parsedCustomer);
      }
    } catch (error) {
      console.log('Error refreshing customer data:', error);
    }
    setRefreshing(false);
  };
  const handleShareApp = async () => {
    try {
      const result = await Share.share({
        message:
          'TransRentals - Your trusted vehicle rental service! Rent cars, bikes, trucks with ease. Visit https://play.google.com/store/apps/details?id=com.transrentals.app&pcampaignid=web_share  to download our app and get started!',
        url: 'https://transrentals.in/',
        title: 'TransRentals - Vehicle Rentals Made Easy',
      });

      if (result.action === Share.sharedAction) {
        if (result.activityType) {
          console.log('Shared with activity type: ', result.activityType);
        } else {
          console.log('Shared successfully');
        }
      } else if (result.action === Share.dismissedAction) {
        console.log('Share dismissed');
      }
    } catch (error) {
      alert('Error sharing app: ' + error.message);
    }
  };
  useEffect(() => {
    const fetchCustomerData = async () => {
      const customerData = await AsyncStorage.getItem('customer');
      console.log('Customer Data:', customerData);
      if (customerData) {
        const parsedCustomer = JSON.parse(customerData);
        setCustomer(parsedCustomer);
      }
    };

    fetchCustomerData();
    GoogleSignin.configure({
  webClientId: '365663447950-o996ep372bp2ejippsphe3ktjpen221e.apps.googleusercontent.com',
});
  }, []);

  const handlePress = () => {
    Linking.openURL('https://backrcoin.org/');
  };

  const handleClose = () => {
    if (navigation.canGoBack()) {
      navigation.goBack();
    } else {
      navigation.navigate('CustomerDashboard');
    }
  };

const handleLogout = async () => {
  try {
    // Sign out from Google first
    const user = await GoogleSignin.getCurrentUser();
    if (user) {
      await GoogleSignin.revokeAccess();
      await GoogleSignin.signOut();
      console.log(':white_check_mark: Google user signed out');
    }
    // Now clear app storage
    await AsyncStorage.multiRemove(['customer', 'customer_id', 'token']);
    // Navigate away
    navigation.replace('Login');
  } catch (error) {
    console.log(':x: Logout error:', error);
  }
};

  const imageUrl = customer?.image
    ? `https://app.transrentals.in/storage/profile_images/${customer.image}`
    : null;

  console.log('Image URL:', imageUrl);

  return (
    <SafeAreaView>
    <ScrollView
      contentContainerStyle={{paddingBottom: 50, paddingHorizontal: 20}}
      refreshControl={
        <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
      }>
        <ProfileCheckModal />
      <View style={styles.topbar}>
        <TouchableOpacity style={styles.backBtn} onPress={handleClose}>
          <Icon name="x-circle" size={26} color="#000" />
        </TouchableOpacity>
      </View>
      <View style={styles.profileSection}>
        <View style={styles.avatarWrapper}>
          {imageUrl ? (
            <Image
              source={{uri: imageUrl}}
              style={{
                width: '100%',
                height: '100%',
                borderWidth: 1,
                borderRadius: 50,
              }}
            />
          ) : (
            <Image
              source={require('../../../assets/logp-1.png')}
              style={{
                width: '100%',
                height: '100%',
                borderWidth: 1,
                borderRadius: 50,
              }}
            />
          )}
        </View>
        {customer && (
          <>
            <Text style={styles.nameIcon}>
              {String(customer?.name || 'No Name')}
            </Text>
            <Text style={styles.email}>
              {String(customer?.email || 'Email not submitted')}
            </Text>
          </>
        )}
      </View>

      <TouchableOpacity
        style={styles.editBtn}
        onPress={() => navigation.navigate('EditProfileScreen')}>
        <Text style={styles.EditText}>Edit Profile</Text>
      </TouchableOpacity>

      <View style={styles.handleProfilemain}>
        {/* <TouchableOpacity style={styles.handleProfileParent}>
          <View style={styles.handleProfile}>
            <View
              style={{
                marginRight: 6,
                justifyContent: 'center',
                alignItems: 'center',
                backgroundColor: '#F8F8F8',
                borderRadius: 50,
                padding: 5,
              }}>
              <Image
                source={require('../../../assets/profile-circle.png')}
                style={{width: 24, height: 24}}
              />
            </View>
            <Text style={styles.EditprofText}>My Profile</Text>
          </View>

          <View></View>
        </TouchableOpacity> */}

        {/* <TouchableOpacity
          style={styles.handleProfileParent}
          onPress={handlePress}>
          <View style={styles.handleProfile}>
            <View
              style={{
                marginRight: 6,
                justifyContent: 'center',
                alignItems: 'center',
                backgroundColor: '#F8F8F8',
                borderRadius: 50,
                padding: 5,
              }}>
              <Image
                source={require('../../../assets/backerCoin2.png')}
                style={{width: 24, height: 24}}
              />
            </View>
            <Text style={styles.EditprofText}>Backr Coin</Text>
          </View>
          <View></View>
        </TouchableOpacity> */}
        <TouchableOpacity style={styles.handleProfileParent} onPress={() => navigation.navigate('BackrTokensScreen')}>
          <View style={styles.handleProfile}>
            <View
              style={{
                marginRight: 6,
                justifyContent: 'center',
                alignItems: 'center',
                backgroundColor: '#F8F8F8',
                borderRadius: 50,
                padding: 5,
              }}>
              <Image
                source={require('../../../assets/backerCoin2.png')}
                style={{width: 24, height: 24}}
              />
            </View>
            <Text style={styles.EditprofText}>Backr Coin</Text>
          </View>
          <View></View>
        </TouchableOpacity>

   <TouchableOpacity style={styles.handleProfileParent} onPress={() => navigation.navigate('HelpdeskScreen')}>

          <View style={styles.handleProfile}>
            <View
              style={{
                marginRight: 6,
                justifyContent: 'center',
                alignItems: 'center',
                backgroundColor: '#F8F8F8',
                borderRadius: 50,
                padding: 5,
              }}>
              <Image
                source={require('../../../assets/helpdesk.png')}
                style={{width: 24, height: 24}}
              />
            </View>
            <Text style={styles.EditprofText}>Helpdesk</Text>
          </View>
          <View></View>
        </TouchableOpacity>
        <TouchableOpacity style={styles.handleProfileParent}   onPress={() => navigation.navigate('ExpensesScreen')}>
          <View style={styles.handleProfile}>
            <View
              style={{
                marginRight: 6,
                justifyContent: 'center',
                alignItems: 'center',
                backgroundColor: '#F8F8F8',
                borderRadius: 50,
                padding: 5,
              }}>
              <Image
                source={require('../../../assets/payments.png')}
                style={{width: 23, height: 23}}
              />
            </View>
            <Text style={styles.EditprofText}>Payments</Text>
          </View>
          <View></View>
        </TouchableOpacity>
        <TouchableOpacity style={styles.handleProfileParent}   onPress={() => navigation.navigate('MyBookings')}>
          <View style={styles.handleProfile}>
            <View
              style={{
                marginRight: 6,
                justifyContent: 'center',
                alignItems: 'center',
                backgroundColor: '#F8F8F8',
                borderRadius: 50,
                padding: 5,
              }}>
              <Image
                source={require('../../../assets/mybooking.png')}
                style={{width: 23, height: 23}}
              />
            </View>
            <Text style={styles.EditprofText}>My Bookings</Text>
          </View>
          <View></View>
        </TouchableOpacity>
      </View>

      <View style={styles.socialMain}>
        <Text
          style={{
            fontSize: 14,
            marginBottom: 6,
            color: '#404040',
            opacity: 0.6,
            marginVertical: 10,
          }}>
          FOLLOW US
        </Text>
        <TouchableOpacity
          style={styles.socialSub}
          onPress={() =>
            Linking.openURL('http://instagram.com/transrentals_in/')
          }>
          <View style={styles.handleProfile}>
            <View
              style={{
                marginRight: 6,
                justifyContent: 'center',
                alignItems: 'center',
                backgroundColor: '#F8F8F8',
                borderRadius: 50,
                padding: 6,
                marginTop: 6,
              }}>
              <Image
                source={require('../../../assets/insta.png')}
                style={{width: 25, height: 25}}
              />
            </View>
            <Text style={styles.EditprofText}>Instagram</Text>
          </View>

          <View></View>
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.socialSub}
          onPress={() =>
            Linking.openURL('https://www.facebook.com/Transrentalsindia/')
          }>
          <View style={styles.handleProfile}>
            <View
              style={{
                marginRight: 6,
                justifyContent: 'center',
                alignItems: 'center',
                backgroundColor: '#F8F8F8',
                borderRadius: 50,
                padding: 6,
              }}>
              <Image
                source={require('../../../assets/facebook.png')}
                style={{width: 25, height: 25}}
              />
            </View>
            <Text style={styles.EditprofText}>Facebook</Text>
          </View>

          <View></View>
        </TouchableOpacity>
        <TouchableOpacity
          style={styles.socialSub}
          onPress={() =>
            Linking.openURL('https://www.linkedin.com/company/transrentals/')
          }>
          <View style={styles.handleProfile}>
            <View
              style={{
                marginRight: 6,
                justifyContent: 'center',
                alignItems: 'center',
                backgroundColor: '#F8F8F8',
                borderRadius: 50,
                padding: 6,
              }}>
              <Image
                source={require('../../../assets/linkedin.png')}
                style={{width: 25, height: 25}}
              />
            </View>
            <Text style={styles.EditprofText}>Linkedin</Text>
          </View>

          <View></View>
        </TouchableOpacity>
      </View>
      <View style={styles.socialMain}>
        <Text
          style={{
            fontSize: 14,
            marginBottom: 6,
            color: '#404040',
            opacity: 0.6,
            marginVertical: 10,
          }}>
          OTHER INFORMATION
        </Text>

        <TouchableOpacity style={styles.socialSub} onPress={handleShareApp}>
          <View style={styles.handleProfile}>
            <View
              style={{
                marginRight: 6,
                justifyContent: 'center',
                alignItems: 'center',
                backgroundColor: '#F8F8F8',
                borderRadius: 50,
                paddingVertical: 10,
                paddingHorizontal: 8,
                marginTop: 8,
              }}>
              <Image
                source={require('../../../assets/shareApp.png')}
                style={{width: 20, height: 18}}
              />
            </View>
            <Text style={styles.EditprofText}>Share the app</Text>
          </View>

          <View></View>
        </TouchableOpacity>
        <TouchableOpacity
          style={styles.socialSub}
          onPress={() => navigation.navigate('AboutUsScreen')}>
          <View style={styles.handleProfile}>
            <View
              style={{
                marginRight: 6,
                justifyContent: 'center',
                alignItems: 'center',
                backgroundColor: '#F8F8F8',
                borderRadius: 50,
                padding: 10,
              }}>
              <Image
                source={require('../../../assets/AboutUss.png')}
                style={{width: 18, height: 18}}
              />
            </View>
            <Text style={styles.EditprofText}>About us</Text>
          </View>

          <View></View>
        </TouchableOpacity>
        <TouchableOpacity style={styles.socialSub} onPress={handleLogout}>
          <View style={styles.handleProfile}>
            <View
              style={{
                marginRight: 6,
                justifyContent: 'center',
                alignItems: 'center',
                backgroundColor: '#F8F8F8',
                borderRadius: 50,
                padding: 10,
              }}>
              <Image
                source={require('../../../assets/LogOut.png')}
                style={{width: 18, height: 18}}
              />
            </View>
            <Text style={styles.EditprofText}>Log Out</Text>
          </View>

          <View></View>
        </TouchableOpacity>
      </View>

      <TouchableOpacity style={styles.Logo}>
        <View style={styles.logoContainer}>
          <View>
            <Image
              style={styles.LogoImage}
              source={require('../../../assets/LogoGreySc.png')}
              resizeMode="contain"
            />
          </View>
          <Text style={styles.LogoText}>App Version 2.4</Text>
        </View>
      </TouchableOpacity>
    </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
  },
  profileSection: {
    alignItems: 'center',
    marginBottom: 10,
  },
  avatarWrapper: {
    position: 'relative',
    height: 80,
    width: 80,
    borderWidth: 1,
    borderRadius: 50,
    justifyContent: 'center',
  },

  editIcon: {
    position: 'absolute',
    bottom: 0,
    right: 0,
    backgroundColor: '#fff',
    borderRadius: 50,
    padding: 5,
  },
  nameIcon: {
    fontSize: 20,
    fontWeight: '500',
    marginTop: 10,
    color: '#404040',
  },
  email: {
    fontSize: 14,
    color: '#777',
  },
  UpdateSec: {
    fontSize: 14,
    backgroundColor: '#C5E2E2',
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    borderRadius: 12,
    marginBottom: 10,
    paddingVertical: 20,
    paddingHorizontal: 10,
  },
  Updatecon: {
    flexDirection: 'row',
  },
  UpdateText: {
    width: '50%',
    fontSize: 18,
    fontWeight: '500',
    marginLeft: 2,
  },
  UpdateVer: {
    color: '#09B368',
    fontSize: 20,
    fontWeight: '500',
  },
  editBtn: {
    marginBottom: 20,
    marginTop: 10,
    borderWidth: 1,
    borderColor: '#000',
    borderRadius: 6,
    paddingVertical: 10,
    justifyContent: 'center',
    alignItems: 'center',
    flexDirection: 'row',
  },
  EditprofText: {
    fontSize: 20,
    fontWeight: '500',
    color: '#404040',
  },
  EditText: {
    fontSize: 14,
    fontWeight: '500',
    color: '#404040',
  },
  handlePrivacy: {
    marginVertical: 10,
    gap: 5,
  },

  handleProfile: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 10,
    justifyContent: 'space-between',
  },
  handleProfileParent: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 5,
    justifyContent: 'space-between',
  },
  socialSub: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 2,
    justifyContent: 'space-between',
  },
  EditprofText: {
    fontSize: 16,
  },
  linkText: {
    color: 'blue',
    fontSize: 16,
  },
  backText: {
    color: '#000',
    fontSize: 16,
    marginTop: 10,
  },
  logoutBtn: {
    marginTop: 10,
    borderColor: '#ccc',
    paddingVertical: 10,
    justifyContent: 'flex-start',
    alignItems: 'center',
    flexDirection: 'row',
  },
  backBtn: {
    paddingVertical: 10,
    justifyContent: 'flex-start',
    alignItems: 'center',
    flexDirection: 'row',
    opacity: 0.5,
  },
  logoutText: {
    color: '#000',
    fontSize: 18,
    fontWeight: '600',
  },
  animatedDrawer: {
    position: 'absolute',
    left: 0,
    top: 0,
    bottom: 0,
    width: 300,
    backgroundColor: '#fff',
    paddingHorizontal: 20,
    paddingTop: 40,
    borderTopRightRadius: 30,
    borderBottomRightRadius: 30,
    zIndex: 10,
    elevation: 5,
    height: '100%',
  },
  topbar: {
    paddingLeft: '92%',
    width: '100%',
  },
  Logo: {
    padding: 15,
    width: '100%',
    justifyContent: 'center',
    alignItems: 'center',
  },
  LogoText: {
    color: '#9E9E9E',
    fontSize: 14,
  },
  logoContainer: {
    alignItems: 'center',
    width: '100%',
  },
  LogoImage: {
    width: 200,
  },
});

export default SettingScreen;
