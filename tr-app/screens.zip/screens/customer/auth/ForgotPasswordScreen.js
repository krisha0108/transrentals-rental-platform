// import React, { useState } from 'react';
// import { View, Text, TextInput, TouchableOpacity, StyleSheet, Alert } from 'react-native';
// import axios from 'axios';

// export default function ForgotPasswordScreen({ navigation }) {
//   const [step, setStep] = useState(1);
//   const [email, setEmail] = useState('');
//   const [otp, setOtp] = useState('');
//   const [password, setPassword] = useState('');
//   const [confirmPassword, setConfirmPassword] = useState('');

//   const baseURL = '/customer/forgot-password';

//   const sendOtp = async () => {
//     try {
//       await axios.post(`${baseURL}/send-otp`, { email });
//       Alert.alert('OTP sent to your email.');
//       setStep(2);
//     } catch (err) {
//       Alert.alert('Error', err.response?.data?.message || 'Failed to send OTP');
//     }
//   };

//   const verifyOtp = async () => {
//     try {
//       await axios.post(`${baseURL}/verify-otp`, { email, otp });
//       Alert.alert('OTP verified.');
//       setStep(3);
//     } catch (err) {
//       Alert.alert('Error', err.response?.data?.message || 'Invalid OTP');
//     }
//   };

//   const resetPassword = async () => {
  
      
//     if (!password || password !== confirmPassword) {
//       return Alert.alert('Error', "Passwords don't match");
//     }

//     try {
//       await axios.post(`${baseURL}/reset`, {
//         email,
//         password,
//         password_confirmation: confirmPassword,
//       });
//       Alert.alert('Success', 'Password reset successfully!');
//       navigation.replace('Login');
//     } catch (err) {
//       Alert.alert('Error', err.response?.data?.message || 'Failed to reset password');
//     }
//   };

//   return (
//     <View style={styles.container}>
//       <Text style={styles.title}>Forgot Password</Text>

//       {step === 1 && (
//         <>
//           <Text style={styles.label}>Enter your Email</Text>
//           <TextInput style={styles.input} value={email} onChangeText={setEmail} keyboardType="email-address" />
//           <TouchableOpacity style={styles.button} onPress={sendOtp}>
//             <Text style={styles.buttonText}>Send OTP</Text>
//           </TouchableOpacity>
//         </>
//       )}

//       {step === 2 && (
//         <>
//           <Text style={styles.label}>Enter OTP</Text>
//           <TextInput style={styles.input} value={otp} onChangeText={setOtp} keyboardType="numeric" />
//           <TouchableOpacity style={styles.button} onPress={verifyOtp}>
//             <Text style={styles.buttonText}>Verify OTP</Text>
//           </TouchableOpacity>
//         </>
//       )}

//       {step === 3 && (
//         <>
//           <Text style={styles.label}>New Password</Text>
//           <TextInput style={styles.input} value={password} onChangeText={setPassword} secureTextEntry />
//           <Text style={styles.label}>Confirm Password</Text>
//           <TextInput style={styles.input} value={confirmPassword} onChangeText={setConfirmPassword} secureTextEntry />
//           <TouchableOpacity style={styles.button} onPress={resetPassword}>
//             <Text style={styles.buttonText}>Reset Password</Text>
//           </TouchableOpacity>
//         </>
//       )}
//     </View>
//   );
// }

// const styles = StyleSheet.create({
//   container: { flex: 1, padding: 20, justifyContent: 'center', backgroundColor: '#f9f9f9' },
//   title: { fontSize: 24, fontWeight: '700', marginBottom: 30, textAlign: 'center' },
//   label: { fontSize: 16, marginBottom: 8 },
//   input: {
//     borderWidth: 1, borderColor: '#ccc', padding: 10,
//     borderRadius: 8, marginBottom: 20, backgroundColor: '#fff',color:'#000'
//   },
//   button: {
//     backgroundColor: '#09B368',
//     paddingVertical: 14,
//     borderRadius: 8,
//     alignItems: 'center',
//     marginTop: 10,
//   },
//   buttonText: { color: '#fff', fontSize: 18, fontWeight: 'bold' },
// });
import React, { useState, useRef } from 'react';
import {
  View, Text, TextInput, TouchableOpacity, StyleSheet, Alert, ScrollView
} from 'react-native';
import Icon from 'react-native-vector-icons/Feather';
import axios from 'axios';
import api from '../../api';

export default function ForgotPasswordScreen({ navigation }) {
  const [step, setStep] = useState(1);
  const [email, setEmail] = useState('');
  const [otp, setOtp] = useState(['', '', '', '']);
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [passwordVisible, setPasswordVisible] = useState(false);
  const [confirmVisible, setConfirmVisible] = useState(false);


  const otpRefs = [useRef(), useRef(), useRef(), useRef()];

  const sendOtp = async () => {
    try {
      await api.post(`/customer/forgot-password/send-otp`, { email });
      Alert.alert('OTP sent to your email.');
      setStep(2);
    } catch (err) {
      Alert.alert('Error', err.response?.data?.message || 'Failed to send OTP');
    }
  };

  const verifyOtp = async () => {
    const enteredOtp = otp.join('');
    if (enteredOtp.length < 4) {
      return Alert.alert('Error', 'Please enter 4-digit OTP');
    }

    try {
      await api.post(`/customer/forgot-password/verify-otp`, {
        email,
        otp: enteredOtp
      });
      Alert.alert('OTP verified.');
      setStep(3);
    } catch (err) {
      Alert.alert('Error', err.response?.data?.message || 'Invalid OTP');
    }
  };

  const resetPassword = async () => {
    if (!password || password !== confirmPassword) {
      return Alert.alert('Error', "Passwords don't match");
    }

    try {
      await api.post(`/customer/forgot-password/reset`, {
        email,
        password,
        password_confirmation: confirmPassword,
      });
      Alert.alert('Success', 'Password reset successfully!');
      navigation.replace('Login');
    } catch (err) {
      Alert.alert('Error', err.response?.data?.message || 'Failed to reset password');
    }
  };

  const handleOtpChange = (value, index) => {
    const newOtp = [...otp];
    newOtp[index] = value;
    setOtp(newOtp);
    if (value && index < 3) {
      otpRefs[index + 1].current.focus();
    }
  };

  return (
    <ScrollView contentContainerStyle={styles.scrollContainer}>
      <View style={styles.card}>
        <Text style={styles.title}>Forgot Password</Text>

        {step === 1 && (
          <>
            <Text style={styles.label}>Enter your email</Text>
            <TextInput
              style={styles.input}
              placeholder="Enter your email"
              value={email}
              onChangeText={setEmail}
              keyboardType="email-address"
              autoCapitalize="none"
              placeholderTextColor="#999"
            />
            <TouchableOpacity style={styles.button} onPress={sendOtp}>
              <Text style={styles.buttonText}>Send OTP</Text>
            </TouchableOpacity>
          </>
        )}

        {step === 2 && (
          <>
            <Text style={styles.label}>Enter OTP</Text>
            <View style={styles.otpContainer}>
              {otp.map((digit, index) => (
                <TextInput
                  key={index}
                  ref={otpRefs[index]}
                  style={styles.otpBox}
                  keyboardType="numeric"
                  maxLength={1}
                  value={digit}
                  onChangeText={(value) => handleOtpChange(value, index)}
                />
              ))}
            </View>
            <TouchableOpacity style={styles.button} onPress={verifyOtp}>
              <Text style={styles.buttonText}>Verify OTP</Text>
            </TouchableOpacity>
          </>
        )}

        {step === 3 && (
          <>
            <Text style={styles.label}>New Password</Text>
            <View style={styles.passwordContainer}>
              <TextInput
                style={styles.passwordInput}
                value={password}
                onChangeText={setPassword}
                secureTextEntry={!passwordVisible}
                placeholder="Enter new password"
                placeholderTextColor="#999"
              />
              <TouchableOpacity onPress={() => setPasswordVisible(!passwordVisible)}>
                <Icon name={passwordVisible ? 'eye' : 'eye-off'} size={20} color="#888" />
              </TouchableOpacity>
            </View>

            <Text style={styles.label}>Confirm Password</Text>
            <View style={styles.passwordContainer}>
              <TextInput
                style={styles.passwordInput}
                value={confirmPassword}
                onChangeText={setConfirmPassword}
                secureTextEntry={!confirmVisible}
                placeholder="Confirm password"
                placeholderTextColor="#999"
              />
              <TouchableOpacity onPress={() => setConfirmVisible(!confirmVisible)}>
                <Icon name={confirmVisible ? 'eye' : 'eye-off'} size={20} color="#888" />
              </TouchableOpacity>
            </View>

            <TouchableOpacity style={styles.button} onPress={resetPassword}>
              <Text style={styles.buttonText}>Reset Password</Text>
            </TouchableOpacity>
          </>
        )}

        <TouchableOpacity onPress={() => navigation.replace('Login')}>
          <Text style={styles.backToLogin}>Remember your password? <Text style={styles.backToLoginLink}>Back to Login</Text></Text>
        </TouchableOpacity>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  scrollContainer: {
    flexGrow: 1,
    backgroundColor: '#F9F7F7', // yellow border like your screenshot
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  card: {
    backgroundColor: '#fff',
    width: '100%',
    maxWidth: 400,
    borderRadius: 12,
    padding: 24,
    shadowColor: '#000',
    shadowOpacity: 0.1,
    shadowOffset: { width: 0, height: 2 },
    shadowRadius: 6,
    elevation: 4,
  },
  title: {
    fontSize: 22,
    fontWeight: '700',
    textAlign: 'center',
    color: '#333',
    marginBottom: 20,
  },
  label: {
    fontSize: 16,
    fontWeight: '600',
    marginBottom: 6,
    color: '#333',
  },
  input: {
    height: 48,
    borderRadius: 8,
    backgroundColor: '#fff',
    borderColor: '#ddd',
    borderWidth: 1,
    paddingHorizontal: 12,
    fontSize: 16,
    marginBottom: 20,
    color: '#000',
  },
  button: {
    backgroundColor: '#09B368',
    borderRadius: 8,
    paddingVertical: 14,
    alignItems: 'center',
    marginTop: 10,
  },
  buttonText: {
    fontSize: 17,
    color: '#fff',
    fontWeight: 'bold',
  },
  otpContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 20,
  },
  otpBox: {
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 8,
    width: 50,
    height: 50,
    textAlign: 'center',
    fontSize: 20,
    backgroundColor: '#fff',
    color: '#000',
  },
  passwordContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 8,
    paddingHorizontal: 10,
    marginBottom: 20,
    backgroundColor: '#fff',
  },
  passwordInput: {
    flex: 1,
    height: 50,
    color: '#000',
  },
  backToLogin: {
    textAlign: 'center',
    marginTop: 20,
    fontSize: 15,
    color: '#888',
  },
  backToLoginLink: {
    color: '#0a9c5a',
    fontWeight: '600',
  },
});
