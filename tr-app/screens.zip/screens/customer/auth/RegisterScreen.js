import React, { useState, useEffect } from "react";
import { View, Text, TextInput, TouchableOpacity, StyleSheet, SafeAreaView, Alert, Image , ActivityIndicator} from "react-native";
import axios from "axios";
import Icon from 'react-native-vector-icons/Feather';
import { GoogleSignin, statusCodes } from '@react-native-google-signin/google-signin';
import messaging from '@react-native-firebase/messaging';
import AsyncStorage from '@react-native-async-storage/async-storage';
import api from '../../api';

export default function RegisterScreen({ navigation }) {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    password: ""
  });
  const [passwordVisible, setPasswordVisible] = useState(false);
  const [loading, setLoading] = useState(false);
  const handleChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };
useEffect(() => {
    GoogleSignin.configure({
      webClientId: '365663447950-o996ep372bp2ejippsphe3ktjpen221e.apps.googleusercontent.com', // Get this from Google Cloud Console
      offlineAccess: true,
    });
  }, []);

  const handleSendOtp = async () => {
    const { name, email, phone, password } = formData;
    if (!name || !email || !phone || !password) {
        return Alert.alert("Error", "All fields are required.");
    }
    setLoading(true);

    try {
        const res = await api.post("/send-otp", {
            name, 
            email, 
            phone, 
            password
        });

        if (res.data.status === 'success') {
            navigation.navigate("OtpScreen", { token: res.data.token, name, email, phone, password });
        } else {
            Alert.alert("Error", res.data.message);
        }
    } catch (err) {
        console.error("Register Error:", err);
        // Alert.alert("Error", "Something went wrong.");
        // ✅ Handle specific Laravel validation or custom error
    if (err.response && err.response.data && err.response.data.message) {
      Alert.alert("Error", err.response.data.message);
    } else {
      Alert.alert("Error", "Something went wrong.");
    }
    } finally {
    setLoading(false); // Stop loader
  }
};
const handleGoogleLogin = async () => {
  try {
    await GoogleSignin.hasPlayServices(); // Ensure Google Play Services are available
    const userInfo = await GoogleSignin.signIn(); // Sign in the user with Google
    
    // Log the user info for debugging
    console.log('Google User Info:', userInfo);

    // Send Google user info to Laravel backend
    const response = await api.post("/google-login", {
      email: userInfo.data.user.email,
      name: userInfo.data.user.name,
      idToken: userInfo.data.idToken, // Send the ID token for backend verification
    });

    if (response.data.status === 'success') {
console.log('customer data:' ,response.data );
        // Get FCM token
  const fcmToken = await messaging().getToken();
  console.log('Got FCM token:', fcmToken);
  // Send FCM token to backend to update existing customer record
  try {
    await api.post('/save-fcm-token', {
      email: userInfo.data.user.email,
      fcm_token: fcmToken,
    });
    console.log('FCM token sent to backend successfully');
  } catch (err) {
    console.log('Error sending FCM token to backend:', err.message);
  }
    await AsyncStorage.clear();
  await AsyncStorage.setItem("customer", JSON.stringify(response.data.customer));
  const customerData = await AsyncStorage.getItem('customer');
  console.log('customer from dash data:', customerData);
  await AsyncStorage.setItem("customer_id", JSON.stringify(response.data.customer.id));
  await AsyncStorage.setItem("token", response.data.token);
      Alert.alert("Success", "Register successful!");
      navigation.replace("CustomerDashboard");
    } else {
      Alert.alert("Error", response.data.message);
    }
  } catch (error) {
    if (error.code === statusCodes.SIGN_IN_CANCELLED) {
      Alert.alert("Error", "Sign-in was cancelled.");
    } else if (error.code === statusCodes.IN_PROGRESS) {
      Alert.alert("Error", "Google Sign-In is in progress.");
    } else {
      console.error("Google login failed:", error);
      if (error.code === statusCodes.DEVELOPER_ERROR) {
        Alert.alert("Error", "Developer Error: Make sure your Google Play services and OAuth setup are correct.");
      } else {
        Alert.alert("Error", "Google login failed. Please try again.");
      }
    }
  }
};
  return (
    <SafeAreaView style={styles.container}>
      <Text style={styles.heading}>Register</Text>
      <View style={styles.formContainer}>
         <Text style={styles.title}>Username</Text>
        <TextInput placeholder="Name" value={formData.name} onChangeText={(text) => handleChange('name', text)} style={styles.input} />
           <Text style={styles.title}>Email</Text>
        <TextInput placeholder="Email" value={formData.email} keyboardType="email-address" onChangeText={(text) => handleChange('email', text)} style={styles.input} />
           <Text style={styles.title}>Mobile Number</Text>
        <TextInput placeholder="Phone" value={formData.phone} keyboardType="phone-pad" onChangeText={(text) => handleChange('phone', text)} style={styles.input}  />
         
           <Text style={styles.title}>Password</Text>
       
           <View style={styles.passwordContainer}> 
        <TextInput placeholder="Enter Password"
        style={styles.passwordText}
         secureTextEntry={!passwordVisible} 
         value={formData.password}
          onChangeText={(text) => handleChange('password', text)} />
                 <TouchableOpacity
            style={styles.eyeIcon}
            onPress={() => setPasswordVisible(!passwordVisible)} // Toggle password visibility
          >
            <Icon name={passwordVisible ? 'eye' : 'eye-off'} size={20} color="#000" marginTop="10" />
          </TouchableOpacity>
           </View> 
       <TouchableOpacity
  style={[
    styles.registerButton,
    loading && { backgroundColor: '#A9A9A9' } // Grey when loading
  ]}
  onPress={handleSendOtp}
  disabled={loading} // Disable when loading
>
  {loading ? (
    <View style={{ flexDirection: 'row', alignItems: 'center' }}>
      <Text style={[styles.registerButtonText, { marginRight: 10 }]}>Please wait</Text>
      <ActivityIndicator size="small" color="#fff" />
    </View>
  ) : (
    <Text style={styles.registerButtonText}>Register</Text>
  )}
</TouchableOpacity>
         <TouchableOpacity style={styles.googleButton} onPress={handleGoogleLogin}>
                     <Image source={require('../../../assets/google-logo.png')}   style={{ width: 30, height: 30,}}/>
                     <Text style={styles.googleButtonText}>Continue with Google</Text>
                   </TouchableOpacity>
      </View>
       <View style={styles.LoginContainer}>
                  <Text style={styles.loginText}>
                  Already Have An Account?{" "}
                    <Text style={styles.loginLink} onPress={() => navigation.navigate('Login')}>
                      Login
                    </Text>
                  </Text>
                </View>
    </SafeAreaView>
  );
}
const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#F9F7F7", paddingVertical: 0, paddingHorizontal: 20, },
  heading: { fontSize: 26, fontWeight: "700", marginTop: 50, marginBottom: 30, color: "#404040", fontFamily: 'Manrope' },
  formContainer: { gap: 10, padding: 10 },
  input: {
    height: 45, backgroundColor: "#fff", borderWidth: 0.5,
    borderColor: "#ccc", borderRadius: 8, paddingHorizontal: 16,
    color: '#404040',
  },
  registerButton: {
    backgroundColor: "#09B368", height: 50,
    borderRadius: 8, justifyContent: "center", alignItems: "center", marginTop: 20
  },
  registerButtonText: { color: "#fff", fontSize: 18, fontWeight: "600" },
  title: { fontSize: 16, fontWeight: "700", textAlign: "left", fontFamily: 'Manrope', color: "#404040" },
  LoginContainer: {
    alignItems: "center",
    marginTop: 30,
  },
 loginText: {
    fontWeight: "600",
    fontSize: 16,
    color: "#404040",
  },
 loginLink: {
    color: "#09B368",
  },
  googleButton: {
    paddingVertical: 8,
    borderWidth:1,
    flexDirection:'row',
    gap : 16,
    borderColor:'#000',
    alignItems: "center",
    justifyContent: "center",
    borderRadius: 8,
    marginTop: 16,
  },
  googleButtonText: {
    color: "#000",
    fontSize: 16,
    fontWeight: "600",
  },
  passwordContainer: {
    flexDirection: 'row', // Vertically center both input and icon
    borderWidth: 1,        // Border for the password input container
    borderColor: '#ddd',
    borderRadius: 8,
    marginBottom: 20,
    backgroundColor: '#fff',
    justifyContent: 'space-between',
    paddingHorizontal: 10,
    height: 45,
  },
  passwordText: {
width: '100%',
color: '#000',
  },
  eyeIcon:{
position: 'absolute',
right: 10,
  },
  
});