import React, { useState, useEffect } from "react";
import { View, Text, TextInput, TouchableOpacity, StyleSheet, SafeAreaView, Alert , Image, ActivityIndicator} from "react-native";
import axios from "axios";
import { GoogleSignin, statusCodes } from '@react-native-google-signin/google-signin';
import AsyncStorage from '@react-native-async-storage/async-storage';
import messaging from '@react-native-firebase/messaging';
import Icon from 'react-native-vector-icons/Feather';
import api from '../../api';
export default function LoginScreen({ navigation }) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
const [passwordVisible, setPasswordVisible] = useState(false);
  // Configure Google Sign-In
  useEffect(() => {
    GoogleSignin.configure({
      webClientId: '365663447950-o996ep372bp2ejippsphe3ktjpen221e.apps.googleusercontent.com', // Get this from Google Cloud Console
      offlineAccess: true,
    });
  }, []);
  // Handle normal login
  const handleLogin = async () => {
    if (!email || !password) {
      Alert.alert("Error", "Please enter both email and password.");
      return;
    }
    setLoading(true); 
    try {
      const response = await api.post("/login", {
        email,
        password
      });
      if (response.data.status === 'success') {
        // Get FCM token
  const fcmToken = await messaging().getToken();
  console.log('Got FCM token:', fcmToken);
  // Send FCM token to backend to update existing customer record
  try {
    await api.post('/save-fcm-token', {
      email,
      fcm_token: fcmToken,
    });
    console.log('FCM token sent to backend successfully');
  } catch (err) {
    console.log('Error sending FCM token to backend:', err.message);
  }
  await AsyncStorage.clear();
  await AsyncStorage.setItem("customer", JSON.stringify(response.data.customer));
  await AsyncStorage.setItem("customer_id", JSON.stringify(response.data.customer.id));
  await AsyncStorage.setItem("token", response.data.token);
        // Navigate to the customer dashboard on successful login
        Alert.alert("Success", response.data.message);
        navigation.replace("CustomerDashboard");
      } else {
        // Show error if login fails
        Alert.alert("Error", response.data.message);
      }
    } catch (error) {
      console.error("Login Error:", error);
      Alert.alert("Error", "Something went wrong during login.");
    } finally {
    setLoading(false); // 👉 Stop loader
  }
  };
  // Handle Google login
  const handleGoogleLogin = async () => {
  try {
    await GoogleSignin.hasPlayServices(); // Ensure Google Play Services are available
    const userInfo = await GoogleSignin.signIn(); // Sign in the user with Google
    // Log the user info for debugging
    console.log('Google User Info:', userInfo);
    // Send Google user info to Laravel backend
    const response = await api.post("/google-login", {
      email: userInfo.data.user.email,
      name: userInfo.data.user.name,
      idToken: userInfo.data.idToken,
    });
  console.log('customerdata',response.data);
    if (response.data.status === 'success') {
       // Get FCM token
  const fcmToken = await messaging().getToken();
  console.log('Got FCM token:', fcmToken);
  // Send FCM token to backend to update existing customer record
  try {
    await api.post('/save-fcm-token', {
      email: userInfo.data.user.email,
      fcm_token: fcmToken,
    });
    console.log('FCM token sent to backend successfully');
  } catch (err) {
    console.log('Error sending FCM token to backend:', err.message);
  }
        await AsyncStorage.clear();
  await AsyncStorage.setItem("customer", JSON.stringify(response.data.customer));
  await AsyncStorage.setItem("customer_id", JSON.stringify(response.data.customer.id));
  await AsyncStorage.setItem("token", response.data.token);
      Alert.alert("Success", "login successful!");
      navigation.replace("CustomerDashboard");
    } else {
      Alert.alert("Error", response.data.message);
    }
  } catch (error) {
    if (error.code === statusCodes.SIGN_IN_CANCELLED) {
      Alert.alert("Error", "Sign-in was cancelled.");
    } else if (error.code === statusCodes.IN_PROGRESS) {
      Alert.alert("Error", "Google Sign-In is in progress.");
    } else {
      console.log("Google login failed:", JSON.stringify(error, null, 2));
      console.error("Google login failed:", error);
      if (error.code === statusCodes.DEVELOPER_ERROR) {
        Alert.alert("Error", "Developer Error: Make sure your Google Play services and OAuth setup are correct.");
      } else {
        Alert.alert("Error", "Google login failed. Please try again.");
      }
    }
  }
};
  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.mainContent}>
        <Text style={styles.loginHeader}>Log In</Text>
        <View style={styles.form}>
          <Text style={styles.formheading}>Enter your email</Text>
          <TextInput
            style={styles.input}
            placeholder="Enter your email"
            value={email}
            onChangeText={setEmail}
            keyboardType="email-address"
          />
          <Text style={styles.formheading}>Password</Text>
          {/* <TextInput
            style={styles.input}
            placeholder="Enter your password"
            value={password}
            onChangeText={setPassword}
            secureTextEntry
          /> */}
           <View style={styles.passwordContainer}>
                  <TextInput placeholder="Enter Password"
                  style={styles.passwordText}
                   secureTextEntry={!passwordVisible}
                   value={password}
                    onChangeText={setPassword} />
                           <TouchableOpacity
                      style={styles.eyeIcon}
                      onPress={() => setPasswordVisible(!passwordVisible)} // Toggle password visibility
                    >
                      <Icon name={passwordVisible ? 'eye' : 'eye-off'} size={20} color="#000" marginTop="10" />
                    </TouchableOpacity>
                     </View>
                      <TouchableOpacity onPress={() => navigation.navigate('ForgotPassword')}>
   <Text style={{ color: '#09B368' }}>
     Forgot Password?
   </Text>
 </TouchableOpacity>
         <TouchableOpacity
  style={[styles.button, loading && { backgroundColor: '#A9A9A9' }]}
  onPress={handleLogin}
  disabled={loading} // 👉 disable button when loading
>
  {loading ? (
    <View style={{ flexDirection: 'row', alignItems: 'center' }}>
      <Text style={[styles.buttonText, { marginRight: 10 }]}>Please wait</Text>
      <ActivityIndicator size="small" color="#fff" />
    </View>
  ) : (
    <Text style={styles.buttonText}>Login</Text>
  )}
</TouchableOpacity>
          {/* Google Login Button */}
          <TouchableOpacity style={styles.googleButton} onPress={handleGoogleLogin}>
            <Image source={require('../../../assets/google-logo.png')}   style={{ width: 30, height: 30,}}/>
            <Text style={styles.googleButtonText}>Continue with Google</Text>
          </TouchableOpacity>
          <View style={styles.registerContainer}>
            <Text style={styles.registerText}>
              Don't have an account?{" "}
              <Text
                style={styles.registerLink}
                onPress={() => navigation.navigate('Register')}
              >
                Register
              </Text>
            </Text>
          </View>
        </View>
      </View>
    </SafeAreaView>
  );
}
const styles = StyleSheet.create({
  container: {
    backgroundColor: "#F9F7F7",
    flex: 1,
  },
  mainContent: {
    paddingHorizontal: 24,
    paddingTop: 40,
  },
  loginHeader: {
    fontSize: 24,
    color: "#404040",
    marginBottom: 32,
  },
  form: {
    gap: 14,
  },
   passwordContainer: {
    flexDirection: 'row', // Vertically center both input and icon
    borderWidth: 1,        // Border for the password input container
    borderColor: '#ddd',
    borderRadius: 8,
    marginBottom: 20,
    backgroundColor: '#fff',
    justifyContent: 'space-between',
    paddingHorizontal: 10,
    height: 45,
  },
  passwordText: {
width: '100%',
color: '#000',
  },
  eyeIcon:{
position: 'absolute',
right: 10,
  },
  formheading: {
    fontFamily: 'Manrope',
    fontWeight: '700',
    color: '#404040',
    fontSize: 16,
  },
  input: {
    height: 45,
    borderWidth: 0.5,
    borderColor: "#ddd",
    backgroundColor: "#FFFFFF",
    paddingHorizontal: 16,
    fontSize: 18,
    fontWeight: "600",
    color: "#404040",
    borderRadius: 8,
  },
  button: {
    height: 54,
    backgroundColor: "#09B368",
    alignItems: "center",
    justifyContent: "center",
    borderRadius: 8,
    marginTop: 16,
  },
  buttonText: {
    color: "#FFFFFF",
    fontSize: 21,
    fontWeight: "600",
  },
  googleButton: {
    paddingVertical: 8,
    borderWidth:1,
    flexDirection:'row',
    gap : 16,
    borderColor:'#000',
    alignItems: "center",
    justifyContent: "center",
    borderRadius: 8,
    marginTop: 16,
  },
  googleButtonText: {
    color: "#000",
    fontSize: 16,
    fontWeight: "600",
  },
  registerContainer: {
    alignItems: "center",
    marginTop: 40,
  },
  registerText: {
    fontWeight: "600",
    fontSize: 18,
    color: "#404040",
  },
  registerLink: {
    color: "#09B368",
  },
});