// EarnBackrTasksScreen.js
import React from 'react';
import { View, Text, StyleSheet, SafeAreaView, ScrollView, TouchableOpacity, Image } from 'react-native';
import Icon from 'react-native-vector-icons/Ionicons';
import { useNavigation } from '@react-navigation/native';

const tasks = [
  {
    id: 1,
    title: 'Complete a Booking',
    desc: 'Earn 50 Backr tokens for every booking you complete.',
    reward: 50,
    icon: 'car-outline',
    color: '#2563eb',
    action: () => {}
  //   action: (navigation) => {
  //   navigation.navigate('BookingPage'); // Replace 'BookingPage' with your target route name
  // }
  },
  // {
  //   id: 2,
  //   title: 'Refer a Friend',
  //   desc: 'Invite your friends and earn 100 Backr tokens when they complete their first booking.',
  //   reward: 100,
  //   icon: 'people-outline',
  //   color: '#16a34a',
  //   action: () => {}
  // },
  // {
  //   id: 3,
  //   title: 'Leave a Review',
  //   desc: 'Share your experience and earn 20 Backr tokens.',
  //   reward: 20,
  //   icon: 'star-outline',
  //   color: '#f59e0b',
  //   action: () => {}
  // },
  // {
  //   id: 4,
  //   title: 'Upload Profile Photo',
  //   desc: 'Add a profile photo and earn 10 Backr tokens instantly.',
  //   reward: 10,
  //   icon: 'camera-outline',
  //   color: '#ec4899',
  //   action: () => {}
  // },
  {
    id: 5,
    title: 'Complete Daily Spin Task',
    desc: 'Try your luck and win Backr coins! you can speen every 24 hours.',
    reward: 10,
    icon: 'gift-outline',
    color: '#eb2828',
    action: () => {}
  }
];

export default function EarnBackrTasksScreen() {
  const navigation = useNavigation();

  return (
    <SafeAreaView style={styles.safe}>
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backBtn}>
          <Icon name="arrow-back" size={24} color="#000" />
        </TouchableOpacity>
        <Text style={styles.title}>Earn Backr</Text>
        <View style={{ width: 40 }} /> {/* spacer */}
      </View>

      <ScrollView contentContainerStyle={styles.scroll}>
        {tasks.map(task => (
          <View key={task.id} style={styles.taskCard}>
            <View style={[styles.iconWrap, { backgroundColor: task.color + '22' }]}>
              <Icon name={task.icon} size={26} color={task.color} />
            </View>
            <View style={{ flex: 1 }}>
              <Text style={styles.taskTitle}>{task.title}</Text>
              <Text style={styles.taskDesc}>{task.desc}</Text>
            </View>
            <TouchableOpacity style={styles.rewardBtn} onPress={task.action}>
              <Image
                source={{ uri: 'https://app.transrentals.in/assets/images/coin-back.png' }}
                style={{ width: 20, height: 20, marginRight: 4 }}
              />
              <Text style={styles.rewardText}>+{task.reward}</Text>
            </TouchableOpacity>
          </View>
        ))}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: '#f6f7fb' },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 16,
    backgroundColor: '#fff',
    elevation: 2
  },
  backBtn: {
    padding: 6,
    borderRadius: 8
  },
  title: { fontSize: 18, fontWeight: '700', color: '#0f172a' },
  scroll: { padding: 16 },
  taskCard: {
    flexDirection: 'row',
    backgroundColor: '#fff',
    borderRadius: 12,
    padding: 14,
    marginBottom: 12,
    alignItems: 'center',
    elevation: 1
  },
  iconWrap: {
    width: 44,
    height: 44,
    borderRadius: 9999,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12
  },
  taskTitle: { fontWeight: '700', fontSize: 15, color: '#0f172a' },
  taskDesc: { fontSize: 13, color: '#64748b', marginTop: 2 },
  rewardBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#f0fdf4',
    borderRadius: 8,
    paddingVertical: 4,
    paddingHorizontal: 8
  },
  rewardText: { color: '#16a34a', fontWeight: '700' }
});
