// BackrTokensScreen.js
import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  View, Text, StyleSheet, SafeAreaView, ScrollView, RefreshControl,
  Animated, Easing, Image, TextInput, TouchableOpacity, Modal, Alert,
  ActivityIndicator, KeyboardAvoidingView, Platform
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import api, { API_BASE_URL } from '../api';
import Icon from 'react-native-vector-icons/Ionicons'; // <-- Import back icon
import { useNavigation } from '@react-navigation/native';

const Coin = ({ size = 110 }) => {
  const spin = useRef(new Animated.Value(0)).current;
  useEffect(() => {
    const loop = Animated.loop(
      Animated.timing(spin, { toValue: 1, duration: 5000, easing: Easing.linear, useNativeDriver: true })
    );
    loop.start();
    return () => loop.stop();
  }, [spin]);
  const rotateY = spin.interpolate({ inputRange: [0, 1], outputRange: ['0deg', '360deg'] });
  const translateY = spin.interpolate({ inputRange: [0, 0.5, 1], outputRange: [0, -6, 0] });
  const frontUri = `https://app.transrentals.in/assets/images/coin-front.png`;
  const backUri = `https://app.transrentals.in/assets/images/coin-back.png`;
  return (
    <View style={styles.coinWrap}>
      <Animated.View style={[styles.coin, { width: size, height: size, transform: [{ rotateY }, { translateY }] }]}>
        <Image source={{ uri: frontUri }} style={styles.coinFace} />
        <Image source={{ uri: backUri }} style={[styles.coinFace, styles.coinBack]} />
      </Animated.View>
    </View>
  );
};

const Stat = ({ label, value }) => (
  <View style={styles.statCard}>
    <Text style={styles.statValue}>{value ?? 0}</Text>
    <Text style={styles.statLabel}>{label}</Text>
  </View>
);

const Section = ({ title, children, right }) => (
  <View style={styles.section}>
    <View style={styles.sectionHead}>
      <Text style={styles.sectionTitle}>{title}</Text>
      {right}
    </View>
    {children}
  </View>
);

export default function BackrTokensScreen() {
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  const [customerId, setCustomerId] = useState(null);
  const [wallet, setWallet] = useState('');
  const [initialWallet, setInitialWallet] = useState('');
const hasWallet = useMemo(() => !!initialWallet?.trim(), [initialWallet]);
  const [earned, setEarned] = useState(0);
  const [redeemed, setRedeemed] = useState(0);
  const [remaining, setRemaining] = useState(0);
const [pendingModalVisible, setPendingModalVisible] = useState(false);
const [pendingAmount, setPendingAmount] = useState(0);
const [countdown, setCountdown] = useState(10);
  const [modalVisible, setModalVisible] = useState(false);
  const [redeemValue, setRedeemValue] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [savingWallet, setSavingWallet] = useState(false);
const navigation = useNavigation();
  const canSaveWallet = useMemo(
    () => wallet?.trim().length > 0 && wallet !== initialWallet,
    [wallet, initialWallet]
  );
const progress = useRef(new Animated.Value(0)).current;
const timerRef = useRef(null);
const startPendingCountdown = () => {
  setCountdown(10);
  progress.setValue(0);

  // 10s linear progress
  Animated.timing(progress, {
    toValue: 1,
    duration: 10000,
    easing: Easing.linear,
    useNativeDriver: false,
  }).start();

  // 10s countdown
  if (timerRef.current) clearInterval(timerRef.current);
  timerRef.current = setInterval(() => {
    setCountdown((c) => {
      if (c <= 1) {
        clearInterval(timerRef.current);
        setPendingModalVisible(false);
        return 0;
      }
      return c - 1;
    });
  }, 1000);
};

useEffect(() => {
  return () => {
    if (timerRef.current) clearInterval(timerRef.current);
  };
}, []);

  const bootstrap = async () => {
    try {
      const customerData = await AsyncStorage.getItem('customer');
      if (!customerData) throw new Error('No customer found in storage.');
      const customer = JSON.parse(customerData);
      setCustomerId(customer.id);
      await fetchData(customer.id, false);
    } catch (e) {
      console.log('bootstrap error:', e);
      Alert.alert('Error', 'Could not load customer.');
      setLoading(false);
    }
  };

  const fetchData = async (cid, silent = true) => {
    try {
      if (!silent) setLoading(true);
      const { data } = await api.get('/backr', { params: { customer_id: cid } });
      const w = data?.customer?.solana_wallet || '';
      console.log('wallet:' , data);
      setWallet(w);
      setInitialWallet(w);
      setEarned(data?.tokens?.earned_tokens ?? 0);
      setRedeemed(data?.tokens?.redeemed_tokens ?? 0);
      setRemaining(data?.tokens?.remaining_tokens ?? 0);
    } catch (e) {
      console.log('GET /api/backr error:', e?.response?.data || e.message);
      Alert.alert('Error', 'Failed to load Backr data.');
    } finally {
      if (!silent) setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    bootstrap();
  }, []);

  const onRefresh = () => {
    if (!customerId) return;
    setRefreshing(true);
    fetchData(customerId, true);
  };

  const handleSaveWallet = async () => {
    if (!wallet?.trim()) {
      Alert.alert('Wallet required', 'Please enter your Solana wallet address.');
      return;
    }
    if (wallet.trim().length > 44) {
      Alert.alert('Invalid Wallet', 'Wallet address must be up to 44 characters.');
      return;
    }
    try {
      setSavingWallet(true);
      await api.post('/backr/update-wallet', {
        customer_id: customerId,
        solana_wallet: wallet.trim(),
      });
      setInitialWallet(wallet.trim());
      Alert.alert('Saved', 'Solana wallet updated.');
    } catch (e) {
      console.log('POST /backr/update-wallet error:', e?.response?.data || e.message);
      const msg = e?.response?.data?.message || 'Could not update wallet. Please try again.';
      Alert.alert('Error', msg);
    } finally {
      setSavingWallet(false);
    }
  };

  const openRedeem = () => {
    if (!wallet?.trim()) {
      Alert.alert('Wallet required', 'Please submit your Solana wallet address before redeeming tokens.');
      return;
    }
    if (!remaining || remaining <= 0) {
      Alert.alert('No tokens', 'You have no backer tokens to redeem.');
      return;
    }
    setRedeemValue('');
    setModalVisible(true);
  };

  const submitRedeem = async () => {
    const val = Number(redeemValue);
    if (!val || val < 1) {
      Alert.alert('Invalid amount', 'Enter a token amount of at least 1.');
      return;
    }
    if (val > remaining) {
      Alert.alert('Too many tokens', 'You cannot redeem more than your available tokens.');
      return;
    }
    try {
      setSubmitting(true);
      await api.post('/backr/redeem', {
        customer_id: customerId,
        redeem_value: val,
      });
      setModalVisible(false);
       setPendingAmount(val);
  setPendingModalVisible(true);
  startPendingCountdown();
      fetchData(customerId, true);
    } catch (e) {
      console.log('POST /backr/redeem error:', e?.response?.data || e.message);
      const msg =
        e?.response?.data?.errors?.redeem_value?.[0] ||
        e?.response?.data?.errors?.redeem_error?.[0] ||
        e?.response?.data?.message ||
        'Could not submit redemption. Please try again.';
      Alert.alert('Error', msg);
    } finally {
      setSubmitting(false);
    }
  };

  if (loading) {
    return (
      <SafeAreaView style={styles.safe}>
        <View style={styles.center}>
          <ActivityIndicator size="large" />
          <Text style={{ marginTop: 8 }}>Loading Backr…</Text>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.safe}>
      <ScrollView
        contentContainerStyle={styles.scrollContent}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} />}
      >
        <View style={styles.headerRow}>
            <View style={{ display: 'flex', flexDirection: 'row', justifyContent: 'center', alignItems: 'center', gap: 10,}}>
              <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backButton}>
                      <Icon name="arrow-back" size={24} color="#000" />
                    </TouchableOpacity>
          <Text style={styles.title}>Backr Tokens</Text>
          </View>
          {/* <TouchableOpacity style={styles.newBookingBtn} onPress={() => {}}>
            <Text style={styles.newBookingText}>New Booking</Text>
          </TouchableOpacity> */}
        </View>

        <View style={styles.topCard}>
            <TouchableOpacity
  onPress={() => navigation.navigate('TokenHistoryScreen')}
  style={{ marginTop: 10, alignSelf: 'flex-end' }}
>
  <Text style={{ color: '#2563eb', fontWeight: '600' }}>View Token History</Text>
</TouchableOpacity>
          <Coin size={110} />

        {hasWallet ? (
  // ✅ Already submitted -> just show centered wallet address
  <View style={styles.walletDisplay}>
    <Text style={styles.walletLabel}>Solana Wallet</Text>
    <Text style={styles.walletAddress}>{initialWallet}</Text>

    {/* (Optional) Copy button */}
    {/* If you want copy-to-clipboard, add @react-native-clipboard/clipboard and use it here */}
    {/* <TouchableOpacity onPress={() => Clipboard.setString(initialWallet)} style={styles.copyBtn}>
      <Text style={styles.copyBtnText}>Copy</Text>
    </TouchableOpacity> */}
  </View>
) : (
  // ❗Not submitted -> show input + save button
  <View style={styles.walletRow}>
    <Text style={styles.walletLabel}>Solana Wallet</Text>
    <TextInput
      placeholder="Enter your Solana wallet"
      value={wallet}
      onChangeText={setWallet}
      style={styles.walletInput}
      maxLength={44}
      autoCapitalize="none"
      autoCorrect={false}
    />
    <TouchableOpacity
      disabled={!canSaveWallet || savingWallet}
      onPress={handleSaveWallet}
      style={[styles.saveBtn, (!canSaveWallet || savingWallet) && { opacity: 0.6 }]}
    >
      {savingWallet ? <ActivityIndicator /> : <Text style={styles.saveBtnText}>Save</Text>}
    </TouchableOpacity>
  </View>
)}

          <View style={styles.statsRow}>
            <Stat label="Total Earned" value={earned} />
            <Stat label="Total Redeemed" value={redeemed} />
            <Stat label="Remaining" value={remaining} />
          </View>
        </View>

        <Section
          title="Earned Backr Tokens"
          right={<TouchableOpacity onPress={() => {}}><Text style={styles.link}>How it works?</Text></TouchableOpacity>}
        >
          <Text style={styles.bodyText}>Earn tokens whenever you complete a booking. More bookings = more Backr.</Text>
          <TouchableOpacity style={[styles.ctaBtn, { backgroundColor: '#16a34a' }]} onPress={() => navigation.navigate('EarnBackrTasksScreen')}>
            <Text style={styles.ctaText}>Earn Backr</Text>
          </TouchableOpacity>
        </Section>

        <Section title="Redeem Backr Tokens">
          <Text style={styles.bodyText}>You can redeem <Text style={styles.bold}>{remaining}</Text> tokens.</Text>
          <TouchableOpacity style={[styles.ctaBtn, { backgroundColor: '#059669' }]} onPress={openRedeem}>
            <Text style={styles.ctaText}>Redeem Now</Text>
          </TouchableOpacity>
        </Section>
      </ScrollView>

      <Modal visible={modalVisible} transparent animationType="fade" onRequestClose={() => setModalVisible(false)}>
        <KeyboardAvoidingView style={styles.modalWrap} behavior={Platform.select({ ios: 'padding', android: undefined })}>
          <View style={styles.modalCard}>
            <TouchableOpacity style={styles.modalClose} onPress={() => setModalVisible(false)}>
              <Text style={styles.modalCloseText}>×</Text>
            </TouchableOpacity>

            <View style={{ alignItems: 'center', marginBottom: 12 }}>
              <Image source={{ uri: `https://app.transrentals.in/assets/images/coin-back.png` }} style={{ width: 60, height: 60, marginBottom: 8 }} />
              <Text style={styles.modalTitle}>Redeem Your Backr</Text>
              <Text style={styles.modalSub}>You can redeem <Text style={styles.bold}>{remaining}</Text> tokens</Text>
            </View>

            <Text style={styles.inputLabel}>Token amount</Text>
            <TextInput
              placeholder="Enter token amount"
              keyboardType="numeric"
              value={redeemValue}
              onChangeText={setRedeemValue}
              style={styles.input}
            />

            <TouchableOpacity style={[styles.ctaBtn, { marginTop: 12 }]} onPress={submitRedeem} disabled={submitting}>
              {submitting ? <ActivityIndicator color="#fff" /> : <Text style={styles.ctaText}>Submit Redeem Request</Text>}
            </TouchableOpacity>
          </View>
        </KeyboardAvoidingView>
      </Modal>

      {/* Pending toast modal */}
<Modal
  visible={pendingModalVisible}
  transparent
  animationType="fade"
  onRequestClose={() => setPendingModalVisible(false)}
>
  <View style={styles.pendingModalWrap}>
    <Animated.View style={styles.pendingCard}>
      <View style={{ marginBottom: 8, alignItems: 'center' }}>
        <Image
          source={{ uri: `https://app.transrentals.in/assets/images/coin-back.png` }}
          style={{ width: 52, height: 52, marginBottom: 6 }}
        />
        <Text style={styles.pendingTitle}>Request Submitted</Text>
        <Text style={styles.pendingSub}>
          Your <Text style={styles.bold}>{pendingAmount}</Text> tokens redeem request is{' '}
          <Text style={styles.bold}>pending</Text>.
        </Text>
        <Text style={[styles.pendingSub, { marginTop: 4 }]}>
          Please wait for admin approval.
        </Text>
      </View>

      {/* Progress bar */}
      <View style={styles.progressTrack}>
        <Animated.View
          style={[
            styles.progressFill,
            {
              width: progress.interpolate({
                inputRange: [0, 1],
                outputRange: ['0%', '100%'],
              }),
            },
          ]}
        />
      </View>

      {/* Countdown + OK */}
      <View style={styles.pendingFooter}>
        <Text style={styles.countdownText}>{countdown}s</Text>
        <TouchableOpacity
          onPress={() => {
            if (timerRef.current) clearInterval(timerRef.current);
            setPendingModalVisible(false);
          }}
          style={styles.okBtn}
        >
          <Text style={styles.okBtnText}>OK</Text>
        </TouchableOpacity>
      </View>
    </Animated.View>
  </View>
</Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: '#f6f7fb' },
  scrollContent: { padding: 16, paddingBottom: 24 },
  center: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  headerRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 15 },
  title: { fontSize: 20, fontWeight: '700', color: '#0f172a' },
  newBookingBtn: { paddingHorizontal: 14, paddingVertical: 8, borderRadius: 8, backgroundColor: '#2563eb' },
  newBookingText: { color: '#fff', fontWeight: '600' },
  topCard: { backgroundColor: '#fff', borderRadius: 12, padding: 16, shadowColor: '#000', shadowOpacity: 0.05, shadowRadius: 8, elevation: 2, marginBottom: 16 },
  coinWrap: { alignItems: 'center', marginBottom: 12, marginTop:12, },
  coin: { justifyContent: 'center', alignItems: 'center' },
  coinFace: { width: 110, height: 110, borderRadius: 999 },
  coinBack: { position: 'absolute', top: 0, left: 0, opacity: 0.0 },
  walletRow: { marginTop: 8 },
  walletLabel: { fontWeight: '600', color: '#111827', marginBottom: 6 },
  walletInput: { borderWidth: 1, borderColor: '#e5e7eb', paddingHorizontal: 12, paddingVertical: 10, borderRadius: 10, backgroundColor: '#fafafa' },
  saveBtn: { marginTop: 10, alignSelf: 'flex-start', paddingHorizontal: 14, paddingVertical: 10, backgroundColor: '#4f46e5', borderRadius: 10 },
  saveBtnText: { color: '#fff', fontWeight: '600' },
  statsRow: { flexDirection: 'row', gap: 10, marginTop: 16 },
  statCard: { flex: 1, backgroundColor: '#0ea5e9' + '11', borderRadius: 12, paddingVertical: 14, alignItems: 'center' },
  statValue: { fontSize: 20, fontWeight: '700', color: '#0f172a' , textAlign: 'center' },
  statLabel: { marginTop: 4, color: '#475569' , textAlign:'center' },
  section: { backgroundColor: '#fff', borderRadius: 12, padding: 16, marginBottom: 16, shadowColor: '#000', shadowOpacity: 0.05, shadowRadius: 8, elevation: 2 },
  sectionHead: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 6 },
  sectionTitle: { fontSize: 16, fontWeight: '700', color: '#111827' },
  link: { color: '#2563eb', fontWeight: '600' },
  bodyText: { color: '#334155', lineHeight: 20 },
  ctaBtn: { marginTop: 10, backgroundColor: '#2563eb', paddingVertical: 12, borderRadius: 10, alignItems: 'center' },
  ctaText: { color: '#fff', fontWeight: '700' },
  bold: { fontWeight: '700' },
  modalWrap: { flex: 1, backgroundColor: 'rgba(0,0,0,0.45)', alignItems: 'center', justifyContent: 'center', padding: 18 },
  modalCard: { backgroundColor: '#fff', borderRadius: 12, width: '100%', padding: 16 },
  modalClose: { position: 'absolute', right: 10, top: 6, zIndex: 2 },
  modalCloseText: { fontSize: 28, color: '#64748b' },
  modalTitle: { fontSize: 18, fontWeight: '800', color: '#0f172a' },
  modalSub: { color: '#475569', marginTop: 2 },
  inputLabel: { marginTop: 10, marginBottom: 6, fontWeight: '600', color: '#111827' },
  input: { borderWidth: 1, borderColor: '#e5e7eb', paddingHorizontal: 12, paddingVertical: 10, borderRadius: 10, backgroundColor: '#fafafa' },
  walletDisplay: { marginTop: 8, alignItems: 'center', justifyContent: 'center' },
walletAddress: { marginTop: 6, fontSize: 16, fontWeight: '700', color: '#0f172a', textAlign: 'center' },
// copyBtn: { marginTop: 10, paddingHorizontal: 12, paddingVertical: 8, borderRadius: 8, backgroundColor: '#475569' },
// copyBtnText: { color: '#fff', fontWeight: '600' },
pendingModalWrap: {
  flex: 1,
  backgroundColor: 'rgba(0,0,0,0.45)',
  alignItems: 'center',
  justifyContent: 'flex-end',
  padding: 16,
},
pendingCard: {
  width: '100%',
  backgroundColor: '#0f172a', // slate-900 for that “god level” feel
  borderRadius: 14,
  padding: 16,
  shadowColor: '#000',
  shadowOpacity: 0.2,
  shadowRadius: 12,
  elevation: 8,
},
pendingTitle: {
  fontSize: 16,
  fontWeight: '800',
  color: '#fff',
},
pendingSub: {
  color: '#cbd5e1', // slate-300
  textAlign: 'center',
},
progressTrack: {
  height: 8,
  backgroundColor: 'rgba(255,255,255,0.12)',
  borderRadius: 999,
  overflow: 'hidden',
  marginTop: 12,
},
progressFill: {
  height: '100%',
  backgroundColor: '#22c55e', // green
  borderRadius: 999,
},
pendingFooter: {
  marginTop: 12,
  flexDirection: 'row',
  alignItems: 'center',
  justifyContent: 'space-between',
},
countdownText: { color: '#94a3b8', fontWeight: '700' }, // slate-400
okBtn: {
  paddingHorizontal: 16,
  paddingVertical: 10,
  backgroundColor: '#22c55e',
  borderRadius: 10,
},
okBtnText: { color: '#0b1220', fontWeight: '800' },
});
