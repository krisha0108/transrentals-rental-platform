// BookingDetails_redesign_light.js
// Redesigned BookingDetails screen (Light premium look)
// NOTE: I kept ALL existing logic, state names and functions intact. Only UI and styles were reworked.

import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  Image,
  Dimensions,
  RefreshControl,
  TouchableOpacity,
  Platform,
  Pressable,
  SafeAreaView,
} from 'react-native';
import Icon from 'react-native-vector-icons/Feather';
import MaterialIcons from 'react-native-vector-icons/MaterialIcons';
import Ionicons from 'react-native-vector-icons/Ionicons';
import { useRoute, useNavigation } from '@react-navigation/native';
import ShimmerPlaceHolder from 'react-native-shimmer-placeholder';
import LinearGradient from 'react-native-linear-gradient';
import { Picker } from '@react-native-picker/picker';
import api from '../../api';

const { width } = Dimensions.get('window');

const BookingDetails = () => {
  const route = useRoute();
  const navigation = useNavigation();
  const { bookingId } = route.params;

  // ---------- LOGIC (UNCHANGED) ----------
  const [booking, setBooking] = useState(null);
  const [loading, setLoading] = useState(true);
  const [quotations, setQuotations] = useState([]);
  const [refreshing, setRefreshing] = useState(false);
  const [priceSort, setPriceSort] = useState('default');
  const [sortedQuotations, setSortedQuotations] = useState([]);

  const truncateText = (text, maxLength) => {
    if (!text) return '';
    return text.length > maxLength ? text.substring(0, maxLength) + '...' : text;
  };

  const confirmedQuote = quotations.find(q => q.payment_status === 'advance_done');

  const fetchData = async () => {
    setLoading(true);
    try {
      const response = await api.get(`/customer-booking-detail/${bookingId}`);
      const data = response.data;

      console.log('✅ Booking data:', data);

      if (data.success) {
        setBooking(data.booking);
        setQuotations(data.quotations);
      } else {
        console.warn('⚠️ Booking fetch success=false:', data.message);
      }
    } catch (err) {
      console.error('❌ Booking fetch error:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, [bookingId]);

  useEffect(() => {
    setSortedQuotations(quotations);
  }, [quotations]);

  useEffect(() => {
    if (!quotations) return;
    let sorted = [...quotations];
    if (priceSort === 'low_to_high') {
      sorted.sort((a, b) => parseFloat(a.price) - parseFloat(b.price));
    } else if (priceSort === 'high_to_low') {
      sorted.sort((a, b) => parseFloat(b.price) - parseFloat(a.price));
    }
    setSortedQuotations(sorted);
  }, [priceSort, quotations]);

  const onRefresh = () => {
    setRefreshing(true);
    fetchData();
    setRefreshing(false);
  };

  const handleBackPress = () => {
    if (navigation.canGoBack()) {
      navigation.goBack();
    } else {
      navigation.navigate('CustomerDashboard');
    }
  };

  // ---------- UI HELPERS (UNCHANGED) ----------
  const parseFirstImage = (quote) => {
    let firstImage = require('../../../assets/logp-1.png');

    try {
      const images = JSON.parse(quote?.service_images || '[]');
      if (images.length > 0) {
        let firstImagePath = images[0].replace(/\\/g, '/');
        if (!firstImagePath.startsWith('http')) {
          firstImagePath = `https://app.transrentals.in/storage/${firstImagePath}`;
        }
        firstImage = { uri: firstImagePath };
      }
    } catch (e) {
      // keep default
    }

    return firstImage;
  };

  const handleImageError = () => {
    // fallback handled by parseFirstImage default asset
  };

  // ---------- CARD RENDER (STRUCTURE PRESERVED, LOOK CHANGED) ----------
  const renderQuoteCard = (quote, index) => {
    const firstImage = parseFirstImage(quote);
    const isSelected = confirmedQuote && confirmedQuote.id === quote.id;

    return (
      <Pressable
        key={quote.id ?? index}
        onPress={() => navigation.navigate('ViewQuote', { quoteId: quote.id })}
        style={({ pressed }) => [
          redesignStyles.quoteCard,
          isSelected && redesignStyles.quoteCardSelected,
          pressed && redesignStyles.quoteCardPressed,
        ]}
      >
        <Image source={firstImage} style={redesignStyles.quoteImage} resizeMode="contain" onError={handleImageError} />

        <View style={redesignStyles.quoteContent}>
          <View style={redesignStyles.qTop}>
            <Text style={redesignStyles.qTitle} numberOfLines={2}>{quote?.service_name ?? 'Service Name'}</Text>

            <View style={redesignStyles.qPriceWrap}>
              <Text style={redesignStyles.qPrice}>₹{quote?.price ?? '0'}</Text>
              <Text style={redesignStyles.qPriceLabel}>All inclusive</Text>
            </View>
          </View>

          <Text style={redesignStyles.qVendor} numberOfLines={1}>{quote?.vendor?.name ?? 'Vendor Name'}</Text>

          <View style={redesignStyles.qTagsRow}>
            {quote?.vehicle_type && (
              <View style={redesignStyles.qTagPill}>
                <Ionicons name="car-sport" size={12} color="#0B6E4F" />
                <Text style={redesignStyles.qTagText}>{truncateText(quote.vehicle_type, 14)}</Text>
              </View>
            )}

            <View style={redesignStyles.qTagPill}>
              <Ionicons name="time" size={12} color="#0B6E4F" />
              <Text style={redesignStyles.qTagText}>Instant</Text>
            </View>

            <View style={redesignStyles.qTagPill}>
              <Ionicons name="shield-checkmark" size={12} color="#0B6E4F" />
              <Text style={redesignStyles.qTagText}>Verified</Text>
            </View>
          </View>

          <View style={redesignStyles.qFooter}>
            <Text style={redesignStyles.qBenefit}>Free cancellation · 24/7 support</Text>

          
          </View>
        </View>

        {isSelected && (
          <View style={redesignStyles.selectedRibbon}>
            <Ionicons name="checkmark-circle" size={14} color="#fff" />
            <Text style={redesignStyles.selectedRibbonText}>SELECTED</Text>
          </View>
        )}
      </Pressable>
    );
  };

  // ---------- EMPTY BOOKING (unchanged structure but nicer visuals) ----------
  if (!booking && !loading) {
    return (
      <SafeAreaView style={redesignStyles.container}>
        <View style={redesignStyles.headerTop}>
          <TouchableOpacity onPress={handleBackPress} style={redesignStyles.headerLeftTop}>
            <Ionicons name="arrow-back" size={22} color="#0F172A" />
          </TouchableOpacity>

          <Text style={redesignStyles.headerTitle}>Booking Details</Text>

          <View style={redesignStyles.headerRightTop} />
        </View>

        <ScrollView
          contentContainerStyle={redesignStyles.emptyScroll}
          refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} colors={['#0B6E4F']} />}
        >
          <View style={redesignStyles.emptyWrap}>
            <View style={redesignStyles.emptyCircle}>
              <Ionicons name="document-text" size={56} color="#DDEFEA" />
            </View>
            <Text style={redesignStyles.emptyTitle}>Booking Not Found</Text>
            <Text style={redesignStyles.emptyDesc}>We could not find the booking you are looking for. It may have been removed.</Text>

            <TouchableOpacity style={redesignStyles.refreshBtn} onPress={onRefresh}>
              <Ionicons name="refresh" size={16} color="#0B6E4F" />
              <Text style={redesignStyles.refreshBtnText}>Try Again</Text>
            </TouchableOpacity>
          </View>
        </ScrollView>
      </SafeAreaView>
    );
  }

  // ---------- MAIN RENDER ----------
  return (
    <SafeAreaView style={redesignStyles.container}>
      {/* Top header with subtle gradient */}
      <LinearGradient colors={["#FFFFFF", "#F4FCF8"]} start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }} style={redesignStyles.headerTop}>
        <TouchableOpacity onPress={handleBackPress} style={redesignStyles.headerLeftTop}>
          <Ionicons name="arrow-back" size={22} color="#0F172A" />
        </TouchableOpacity>

        <View style={redesignStyles.headerCenterTop}>
          <Text style={redesignStyles.headerTitle}>Booking Details</Text>
          <Text style={redesignStyles.headerSub}>{booking?.service_type || 'Service'} · {sortedQuotations.length} quotes</Text>
        </View>

        <TouchableOpacity style={redesignStyles.headerRightTop} onPress={() => {}}>
          <Ionicons name="share-social" size={18} color="#0F172A" />
        </TouchableOpacity>
      </LinearGradient>

      <ScrollView
        style={redesignStyles.scroll}
        showsVerticalScrollIndicator={false}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} colors={['#0B6E4F']} />}
        contentContainerStyle={{ paddingBottom: 140 }}
      >
        {/* Booking summary card */}
     <View style={redesignStyles.summaryCardWrap}>
  <View style={redesignStyles.summaryCard}>
    <View style={redesignStyles.iconWrap}>
      <Ionicons name="car-sport-outline" size={22} color="#3d4241ff" />
    </View>

    <View style={redesignStyles.routeContainer}>
      {/* Pickup and Destination Row */}
      <View style={redesignStyles.routeRow}>
        <View style={redesignStyles.routeItem}>
          <Text style={redesignStyles.label}>Pickup</Text>
          <Text style={redesignStyles.value} numberOfLines={1}>
            {booking?.location_name || 'Pickup location'}
          </Text>
        </View>

        <Ionicons
          name="arrow-forward"
          size={18}
          color="#10B981"
          style={{ marginHorizontal: 12 }}
        />

        <View style={redesignStyles.routeItem}>
          <Text style={redesignStyles.label}>Destination</Text>
          <Text style={redesignStyles.value} numberOfLines={1}>
            {booking?.destination || 'Destination'}
          </Text>
        </View>
      </View>

      {/* Date and Time Row */}
      <View style={redesignStyles.metaRow}>
        <View style={redesignStyles.metaItem}>
          <Ionicons name="calendar-outline" size={14} color="#64748B" />
          <Text style={redesignStyles.metaText}>
            {booking
              ? new Date(booking.journey_datetime).toLocaleDateString('en-GB', {
                  day: 'numeric',
                  month: 'short',
                  year: 'numeric',
                })
              : '-'}
          </Text>
        </View>

        <View style={redesignStyles.metaItem}>
          <Ionicons name="time-outline" size={14} color="#64748B" />
          <Text style={redesignStyles.metaText}>
            {booking
              ? new Date(booking.journey_datetime).toLocaleTimeString('en-US', {
                  hour: '2-digit',
                  minute: '2-digit',
                  hour12: true,
                })
              : '-'}
          </Text>
        </View>
      </View>
    </View>
  </View>
</View>


        {/* Quotes header with sort */}
       <View style={redesignStyles.quotesHeader}>
  <View>
    <Text style={redesignStyles.quotesTitle}>Available Quotes</Text>
    <Text style={redesignStyles.quotesSub}>
      {confirmedQuote ? 'You selected a quote' : 'Compare and choose the best quote'}
    </Text>
  </View>

  <TouchableOpacity
    style={redesignStyles.sortBox}
    onPress={() => setPriceSort(prev => (prev === 'low_to_high' ? 'high_to_low' : 'low_to_high'))}
  >
    <Ionicons
      name={priceSort === 'low_to_high' ? 'arrow-down' : 'arrow-up'}
      size={18}
      color="#16A34A"
    />
    <Text style={redesignStyles.sortText}>
      {priceSort === 'low_to_high' ? 'Low to High' : 'High to Low'}
    </Text>
  </TouchableOpacity>
</View>


        {/* body */}
        <View style={redesignStyles.bodyWrap}>
          {loading ? (
            <View style={redesignStyles.skeletonList}>
              {[1, 2].map((_, i) => (
                <View key={i} style={redesignStyles.skelCard}>
                  <ShimmerPlaceHolder style={redesignStyles.skelImage} autoRun />
                  <View style={redesignStyles.skelRight}>
                    <ShimmerPlaceHolder style={[redesignStyles.skelLine, { width: '70%' }]} autoRun />
                    <ShimmerPlaceHolder style={[redesignStyles.skelLine, { width: '50%' }]} autoRun />
                    <ShimmerPlaceHolder style={[redesignStyles.skelLine, { width: '40%' }]} autoRun />
                  </View>
                </View>
              ))}
            </View>
          ) : quotations.length === 0 ? (
            <View style={redesignStyles.emptyQuotes}>
              <Image source={require('../../../assets/NoQuotes.png')} style={redesignStyles.emptyImage} />
              <Text style={redesignStyles.emptyTitleText}>No Quotes Yet</Text>
              <Text style={redesignStyles.emptySubText}>Vendors haven't sent any quotes for your journey yet.</Text>
              <TouchableOpacity style={redesignStyles.refreshBtn} onPress={onRefresh}>
                <Ionicons name="refresh" size={16} color="#0B6E4F" />
                <Text style={redesignStyles.refreshBtnText}>Refresh Quotes</Text>
              </TouchableOpacity>
            </View>
          ) : (
            <View style={redesignStyles.quotesList}>
              {sortedQuotations
                .filter(q => {
                  if (!confirmedQuote) return true;
                  return q.id === confirmedQuote.id;
                })
                .map((q, idx) => renderQuoteCard(q, idx))}
            </View>
          )}
        </View>
      </ScrollView>

      {/* Sticky bottom - redesigned */}
      
    </SafeAreaView>
  );
};

// ---------- REDESIGNED STYLES ----------
const redesignStyles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F6F8F9',
  },

  // Header
  headerTop: {
    height: Platform.OS === 'ios' ? 96 : 86,
    paddingTop: Platform.OS === 'ios' ? 36 : 20,
    paddingHorizontal: 16,
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'transparent',
    borderBottomWidth: 0,
  },
  headerLeftTop: {
    width: 44,
    height: 44,
    borderRadius: 12,
    justifyContent: 'center',
    alignItems: 'center',
  },
  headerCenterTop: {
    flex: 1,
    alignItems: 'center',
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: '900',
    color: '#0F172A',
  },
  headerSub: {
    fontSize: 12,
    color: '#64748B',
    marginTop: 4,
  },
  headerRightTop: {
    width: 44,
    height: 44,
    justifyContent: 'center',
    alignItems: 'center',
  },

  scroll: { flex: 1 },

  // Summary card
  summaryCardWrap: {
    paddingHorizontal: 16,
    marginTop: 8,
  },
  summaryCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#fff',
    borderRadius: 14,
    padding: 14,
    elevation: 4,
    shadowColor: '#000',
    shadowOpacity: 0.06,
    shadowRadius: 12,
  },
  summaryLeft: {
    width: 56,
    alignItems: 'center',
    justifyContent: 'center',
  },
  badge: {
    width: 48,
    height: 48,
    borderRadius: 12,
    backgroundColor: '#0B6E4F',
    alignItems: 'center',
    justifyContent: 'center',
    elevation: 2,
  },
  summaryMiddle: { flex: 1, paddingLeft: 6 },
  pickupLabel: { fontSize: 10, color: '#64748B', fontWeight: '800', letterSpacing: 0.6 },
  pickupValue: { fontSize: 15, color: '#0F172A', fontWeight: '800', marginTop: 4 },
  destLabel: { fontSize: 10, color: '#64748B', fontWeight: '800', letterSpacing: 0.6 },
  // destValue: { fontSize: 15, color: '#0F172A', fontWeight: '800', marginTop: 4 },

  summaryRight: { width: 56, alignItems: 'flex-end' },
  editBtn: { backgroundColor: '#F0FDF4', padding: 8, borderRadius: 10, borderWidth: 1, borderColor: '#DCFCE7' },

// summaryCardWrap: {
//   marginVertical: 10,
//   paddingHorizontal: 16,
// },

// summaryCard: {
//   flexDirection: 'row',
//   alignItems: 'flex-start',
//   backgroundColor: '#fff',
//   borderRadius: 16,
//   padding: 14,
//   shadowColor: '#000',
//   shadowOpacity: 0.08,
//   shadowOffset: { width: 0, height: 3 },
//   shadowRadius: 6,
//   elevation: 4,
// },

iconWrap: {
  width: 40,
  height: 40,
  borderRadius: 12,
  backgroundColor: '#ECFDF5',
  justifyContent: 'center',
  alignItems: 'center',
  marginRight: 12,
},

routeContainer: {
  flex: 1,
},

routeRow: {
  flexDirection: 'row',
  alignItems: 'center',
  justifyContent: 'space-between',
  marginBottom: 10,
},

routeItem: {
  flex: 1,
},

label: {
  fontSize: 12,
  color: '#94A3B8',
  textTransform: 'uppercase',
  letterSpacing: 0.5,
  fontWeight: '600',
},

value: {
  fontSize: 15,
  fontWeight: '500',
  color: '#0F172A',
  marginTop: 2,
},

metaRow: {
  flexDirection: 'row',
  alignItems: 'center',
  justifyContent: 'space-between',
  marginTop: 4,
},

metaItem: {
  flexDirection: 'row',
  alignItems: 'center',
  gap: 6,
},

metaText: {
  fontSize: 13,
  color: '#475569',
  fontWeight: '500',
},


  // Quotes header
  quotesHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginHorizontal: 16,
    marginTop: 14,
  },
  quotesTitle: { fontSize: 18, fontWeight: '900', color: '#0F172A' },
  quotesSub: { color: '#64748B', fontSize: 13, marginTop: 4 },
 sortBox: {
  flexDirection: 'row',
  alignItems: 'center',
  backgroundColor: '#F1F5F9',
  paddingHorizontal: 10,
  paddingVertical: 6,
  borderRadius: 10,
  gap: 6,
},
sortText: {
  color: '#334155',
  fontSize: 13,
  fontWeight: '500',
},

  picker: { flex: 1, marginLeft: 8 },

  bodyWrap: { marginTop: 10, paddingHorizontal: 16 },

  // Skeletons
  skeletonList: { gap: 12 },
  skelCard: {
    flexDirection: 'row',
    backgroundColor: '#fff',
    borderRadius: 12,
    overflow: 'hidden',
    marginBottom: 12,
    alignItems: 'center',
    padding: 12,
    elevation: 2,
  },
  skelImage: { width: 94, height: 94, borderRadius: 10, marginRight: 12 },
  skelRight: { flex: 1 },
  skelLine: { height: 12, borderRadius: 8, marginBottom: 10 },

  // Empty quotes
  emptyQuotes: { alignItems: 'center', paddingVertical: 36 },
  emptyImage: { width: 140, height: 140, resizeMode: 'contain', marginBottom: 12 },
  emptyTitleText: { fontSize: 18, fontWeight: '800', color: '#0F172A' },
  emptySubText: { textAlign: 'center', color: '#64748B', marginTop: 8, marginBottom: 12 },

  refreshBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#F0FDF4',
    borderRadius: 10,
    paddingHorizontal: 14,
    paddingVertical: 10,
    borderWidth: 1,
    borderColor: '#DCFCE7',
  },
  refreshBtnText: { marginLeft: 8, color: '#0B6E4F', fontWeight: '800' },

  // Quote card redesigned
  quotesList: { marginTop: 6, paddingBottom: 8 },
  quoteCard: {
    flexDirection: 'row',
    backgroundColor: '#fff',
    borderRadius: 14,
    overflow: 'hidden',
    marginBottom: 12,
    elevation: 3,
    shadowColor: '#000',
    shadowOpacity: 0.06,
    shadowRadius: 12,
    position: 'relative',
  },
  quoteCardPressed: { opacity: 0.95 },
  quoteCardSelected: { borderWidth: 2, borderColor: '#0B6E4F' },
  quoteImage: { width: 80, height: 80, borderTopLeftRadius: 14, borderBottomLeftRadius: 14 ,marginTop:30,marginLeft:10},
  quoteContent: { flex: 1, padding: 12, justifyContent: 'space-between' },
  qTop: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start' },
  qTitle: { fontSize: 15, fontWeight: '900', color: '#0F172A', flex: 1, marginRight: 8 },
  qPriceWrap: { alignItems: 'flex-end' },
  qPrice: { fontSize: 16, fontWeight: '900', color: '#0B6E4F' },
  qPriceLabel: { fontSize: 11, color: '#94A3B8', marginTop: 2 },
  qVendor: { marginTop: 6, color: '#64748B', fontWeight: '700' },
  qTagsRow: { flexDirection: 'row', flexWrap: 'wrap', marginTop: 8 },
  qTagPill: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#F0FEF7',
    paddingHorizontal: 8,
    paddingVertical: 6,
    borderRadius: 999,
    marginRight: 8,
    borderWidth: 1,
    borderColor: '#E6F6EA',
  },
  qTagText: { marginLeft: 6, fontSize: 11, color: '#0B6E4F', fontWeight: '800' },
  qFooter: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  qBenefit: { color: '#64748B', fontSize: 12 },
  qAction: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 14, paddingVertical: 8, borderRadius: 10 },
  qActionPrimary: { backgroundColor: '#0B6E4F' },
  qActionSelected: { backgroundColor: '#F0FDF4', borderWidth: 1, borderColor: '#0B6E4F' },
  qActionText: { color: '#fff', fontWeight: '800', marginRight: 8 },
  qActionTextSelected: { color: '#0B6E4F' },

  selectedRibbon: { position: 'absolute', top: 10, right: 10, backgroundColor: '#0B6E4F', paddingHorizontal: 10, paddingVertical: 6, borderRadius: 20, flexDirection: 'row', alignItems: 'center' },
  selectedRibbonText: { color: '#fff', marginLeft: 6, fontSize: 11, fontWeight: '900' },

  // Sticky bottom
  stickyWrap: { position: 'absolute', left: 0, right: 0, bottom: 14, alignItems: 'center' },
  sticky: {
    width: width - 32,
    height: 64,
    backgroundColor: '#fff',
    borderRadius: 14,
    paddingHorizontal: 16,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    elevation: 8,
    shadowColor: '#000',
    shadowOpacity: 0.08,
    shadowRadius: 12,
  },
  stickyMain: { fontWeight: '900', color: '#0F172A' },
  stickySub: { color: '#64748B', fontSize: 12 },
  stickyBtn: { backgroundColor: '#0B6E4F', paddingHorizontal: 16, paddingVertical: 10, borderRadius: 10 },
  stickyBtnText: { color: '#fff', fontWeight: '900' },
  summaryMiddleRow: {
  marginTop: 10,
  paddingHorizontal: 16,
},
locationRow: {
  flexDirection: 'row',
  alignItems: 'center',
  justifyContent: 'space-between',
  marginBottom: 12,
},
locationItem: {
  flex: 1,
},
pickupLabel: {
  fontSize: 12,
  color: '#94A3B8',
  fontWeight: '600',
  marginBottom: 2,
},
pickupValue: {
  fontSize: 14,
  fontWeight: '600',
  color: '#0F172A',
},
destLabel: {
  fontSize: 12,
  color: '#94A3B8',
  fontWeight: '600',
  marginBottom: 2,
  textAlign: 'right',
},
destValue: {
  fontSize: 14,
  fontWeight: '600',
  color: '#0F172A',
  textAlign: 'right',
},

});

export default BookingDetails;
