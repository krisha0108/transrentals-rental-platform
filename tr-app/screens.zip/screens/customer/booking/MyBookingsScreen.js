// screens/customer/booking/MyBookingsScreen.js
import React, { useEffect, useState } from "react";
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  Dimensions,
  RefreshControl,
  
  TouchableOpacity,
  Image,
} from "react-native";
import Ionicons from "react-native-vector-icons/Ionicons";
import ShimmerPlaceHolder from "react-native-shimmer-placeholder";
import LinearGradient from "react-native-linear-gradient";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { useNavigation } from "@react-navigation/native";
import api from "../../api";
import ProfileCheckModal from "../profile/ProfileCheckModal";
 import { SafeAreaView } from 'react-native-safe-area-context';
const { width } = Dimensions.get("window");

const TABS = [
  { key: "Open", label: "Open", status: "Open" },
  { key: "Confirmed", label: "Upcoming", status: "Confirmed" },
  { key: "Ongoing", label: "Ongoing", status: "Ongoing" },
  { key: "Completed", label: "Completed", status: "Completed" },
  { key: "Dropped", label: "Dropped", status: "Dropped" },
];

const MyBookingsScreen = () => {
  const navigation = useNavigation();
  const [index, setIndex] = useState(0);
  const [bookingsData, setBookingsData] = useState({});
  const [loading, setLoading] = useState(false);

  const fetchBookings = async (status) => {
    setLoading(true);
    const customerData = await AsyncStorage.getItem("customer");
    const customer = JSON.parse(customerData);
    const identifier = customer?.id || customer?.email;

    try {
      const response = await api.post("/customer-bookings-by-status", {
        identifier,
        status,
      });
      const data = response.data;
      setBookingsData((prev) => ({
        ...prev,
        [status]: data.success ? data.bookings : [],
      }));
    } catch (err) {
      console.error("Booking fetch error:", err.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchBookings(TABS[index].status);
  }, [index]);

  const formatDate = (dateStr) => {
    if (!dateStr) return "-";
    const date = new Date(dateStr);
    const options = { day: "2-digit", month: "short", year: "numeric" };
    return date.toLocaleDateString("en-GB", options);
  };

  const renderEmpty = () => (
    <View style={styles.empty}>
      <Image
        source={require("../../../assets/NoBookings.png")}
        style={styles.emptyImg}
        resizeMode="contain"
      />
      <Text style={styles.emptyText}>No bookings yet</Text>
      <Text style={styles.emptySub}>Your upcoming bookings will appear here.</Text>
    </View>
  );

  const BookingCard = ({ booking }) => {
    const statusColor =
      booking.status === "Completed"
        ? "#E6F5EB"
        : booking.status === "Ongoing"
        ? "#FFF6E6"
        : "#F3F6F7";

    return (
      <TouchableOpacity
        activeOpacity={0.92}
        onPress={() => navigation.navigate("BookingDetail", { bookingId: booking.id })}
        style={styles.cardOuter}
      >
        <LinearGradient
          colors={["#FFFFFF", "#FBFEFC"]}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          style={styles.card}
        >
          {/* Left image */}
          <View style={styles.left}>
            <View style={styles.imageWrap}>
              <Image
                source={
                  booking.service?.image
                    ? { uri: `https://app.transrentals.in/storage/${booking.service.image}` }
                    : require("../../../assets/logp-1.png")
                }
                style={styles.serviceImage}
                resizeMode="cover"
              />
            </View>
            <View style={styles.timePill}>
              <Ionicons name="calendar-outline" size={12} color="#0B6E4F" />
              <Text style={styles.timeText}>{formatDate(booking.journey_datetime)}</Text>
            </View>
          </View>

          {/* Middle details */}
          <View style={styles.middle}>
            <View style={styles.titleRow}>
              <Text style={styles.titleText} numberOfLines={1}>
                {booking.service_name || "Service Name"}
              </Text>
              <View style={[styles.statusPill, { backgroundColor: statusColor }]}>
                <Text style={styles.statusText}>{booking.status}</Text>
              </View>
            </View>

            <Text style={styles.smallText}>Booking ID • #{booking.id}</Text>

            <View style={styles.routeRow}>
              <View style={styles.point}>
                <Ionicons name="location-outline" size={16} color="#007AFF" />
                <Text style={styles.cityText} numberOfLines={1}>
                  {booking.location_name || "Pickup"}
                </Text>
              </View>
              <View style={styles.arrowBox}>
                <Ionicons name="arrow-forward" size={16} color="#9AA6A2" />
              </View>
              <View style={styles.point}>
                {/* <Ionicons name="navigate-outline" size={16} color="#34C759" /> */}
                <Text style={styles.cityText} numberOfLines={1}>
                  {booking.destination || "Destination"}
                </Text>
              </View>
            </View>

            <View style={styles.metaRow}>
              {booking.service_type ? (
                <View style={styles.metaItem}>
                  <Ionicons name="car-sport-outline" size={14} color="#6B7C76" />
                  <Text style={styles.metaText}>{booking.service_type}</Text>
                </View>
              ) : null}
              {booking.trip_type ? (
                <View style={styles.metaItem}>
                  <Ionicons name="swap-horizontal-outline" size={14} color="#6B7C76" />
                  <Text style={styles.metaText}>{booking.trip_type}</Text>
                </View>
              ) : null}
            </View>
          </View>

          {/* Right actions */}
          {/* <View style={styles.right}>
            <TouchableOpacity
              activeOpacity={0.8}
              onPress={() => navigation.navigate("BookingDetail", { bookingId: booking.id })}
              style={styles.viewBtn}
            >
              <Text style={styles.viewBtnText}>View</Text>
            </TouchableOpacity>

            <Text style={styles.smallGrey} numberOfLines={1}>
              ID: #{booking.id}
            </Text>
          </View> */}
        </LinearGradient>
      </TouchableOpacity>
    );
  };

  const renderTabContent = (status) => {
    const bookings = bookingsData[status] || [];
    if (bookings.length === 0 && !loading) return renderEmpty();

    return (
      <View style={{ paddingBottom: 120 }}>
        {bookings.map((b, i) => (
          <BookingCard booking={b} key={`${b.id}-${i}`} />
        ))}
      </View>
    );
  };

  return (
    <SafeAreaView style={styles.screen}>
      <ProfileCheckModal />

      {/* Top header with subtle white card */}
      <View style={styles.topHeader}>
        <TouchableOpacity style={styles.chev} onPress={() => navigation.goBack()}>
          <Ionicons name="chevron-back" size={20} color="#0B6E4F" />
        </TouchableOpacity>

        <View style={styles.headerCenter}>
          <Text style={styles.hTitle}>My Bookings</Text>
          <Text style={styles.hSubtitle}>All your reservations in one place</Text>
        </View>

        {/* <TouchableOpacity style={styles.profileBtn}>
          <Ionicons name="person-circle" size={34} color="#71867F" />
        </TouchableOpacity> */}
      </View>

      {/* Summary strip */}
      {/* <View style={styles.summaryWrap}>
        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.summaryScroll}>
          <View style={styles.summaryCard}>
            <Text style={styles.summaryNumber}>
              {Object.values(bookingsData).flat().length || 0}
            </Text>
            <Text style={styles.summaryLabel}>Total</Text>
          </View>

          <View style={styles.summaryCardMuted}>
            <Text style={styles.summaryNumber}>{(bookingsData["Confirmed"] || []).length}</Text>
            <Text style={styles.summaryLabel}>Upcoming</Text>
          </View>

          <View style={styles.summaryCardMuted}>
            <Text style={styles.summaryNumber}>{(bookingsData["Ongoing"] || []).length}</Text>
            <Text style={styles.summaryLabel}>Ongoing</Text>
          </View>

          <View style={styles.summaryCardMuted}>
            <Text style={styles.summaryNumber}>{(bookingsData["Completed"] || []).length}</Text>
            <Text style={styles.summaryLabel}>Completed</Text>
          </View>
        </ScrollView>
      </View> */}

      {/* Tabs */}
      <View style={styles.tabs}>
        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ paddingHorizontal: 12 }}>
          {TABS.map((t, idx) => {
            const active = idx === index;
            return (
              <TouchableOpacity
                key={t.key}
                onPress={() => setIndex(idx)}
                style={[styles.tabItem, active && styles.tabActive]}
              >
                <Text style={[styles.tabText, active && styles.tabTextActive]}>{t.label}</Text>
                <View style={styles.tabCountWrap}>
                  <Text style={[styles.tabCount, active && styles.tabCountActive]}>
                    {(bookingsData[t.status] || []).length}
                  </Text>
                </View>
              </TouchableOpacity>
            );
          })}
        </ScrollView>
      </View>

      {/* List */}
      <ScrollView
        style={styles.list}
        contentContainerStyle={{ padding: 16, paddingTop: 8 }}
        refreshControl={<RefreshControl refreshing={loading} onRefresh={() => fetchBookings(TABS[index].status)} />}
      >
        {loading ? (
          [1, 2, 3].map((i) => (
            <View key={i} style={styles.skelWrap}>
              <ShimmerPlaceHolder LinearGradient={LinearGradient} autoRun style={styles.skelImage} />
              <View style={{ flex: 1, marginLeft: 12 }}>
                <ShimmerPlaceHolder LinearGradient={LinearGradient} autoRun style={[styles.skelLine, { width: "70%" }]} />
                <ShimmerPlaceHolder LinearGradient={LinearGradient} autoRun style={[styles.skelLine, { width: "45%" }]} />
              </View>
            </View>
          ))
        ) : (
          renderTabContent(TABS[index].status)
        )}
      </ScrollView>
    </SafeAreaView>
  );
};

export default MyBookingsScreen;

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: "#F6F8F7" },

  // top header
  topHeader: {
    height: 86,
    paddingHorizontal: 16,
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#fff",
    borderBottomWidth: 0.5,
    borderBottomColor: "#E8EDEB",
  },
  chev: {
    width: 44,
    height: 44,
    borderRadius: 10,
    justifyContent: "center",
    alignItems: "center",
    marginRight: 6,
    backgroundColor: "#F5FBF8",
  },
  headerCenter: { flex: 1, paddingLeft: 4 },
  hTitle: { fontSize: 18, fontWeight: "700", color: "#153B34" },
  hSubtitle: { fontSize: 12, color: "#7D8B86", marginTop: 2 },

  profileBtn: {
    width: 44,
    height: 44,
    borderRadius: 10,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#FFFFFF",
  },

  // summary strip
  summaryWrap: {
    marginTop: 12,
    paddingHorizontal: 12,
  },
  summaryScroll: {
    paddingVertical: 6,
  },
  summaryCard: {
    width: 110,
    height: 68,
    borderRadius: 12,
    backgroundColor: "#0B6E4F",
    justifyContent: "center",
    padding: 12,
    marginRight: 12,
    shadowColor: "#000",
    shadowOpacity: 0.06,
    shadowRadius: 6,
    elevation: 3,
  },
  summaryCardMuted: {
    width: 110,
    height: 68,
    borderRadius: 12,
    backgroundColor: "#FFFFFF",
    justifyContent: "center",
    padding: 12,
    marginRight: 12,
    borderWidth: 0.5,
    borderColor: "#E6EAE8",
  },
  summaryNumber: { fontSize: 18, fontWeight: "700", color: "#fff" },
  summaryLabel: { fontSize: 12, color: "#fff", marginTop: 2 },

  // tabs
  tabs: {
    marginTop: 12,
    paddingBottom: 6,
  },
  tabItem: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#fff",
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 22,
    marginRight: 10,
    borderWidth: 0.5,
    borderColor: "#E6EAE8",
  },
  tabActive: {
    backgroundColor: "#E9F2EE",
    borderColor: "#0B6E4F",
  },
  tabText: { fontSize: 13, color: "#48544F", marginRight: 8, fontWeight: "600" },
  tabTextActive: { color: "#48544F" },
  tabCountWrap: {
    backgroundColor: "#E9F2EE",
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
  },
  tabCount: { fontSize: 12, color: "#6C7A76", fontWeight: "700" },
  tabCountActive: { color: "#48544F", backgroundColor: "transparent" },

  // list & cards
  list: { flex: 1 },

  cardOuter: {
    marginBottom: 14,
  },
  card: {
    flexDirection: "row",
    padding: 12,
    borderRadius: 14,
    alignItems: "center",
    shadowColor: "#000",
    shadowOpacity: 0.04,
    shadowRadius: 8,
    elevation: 2,
    borderWidth: 0.5,
    borderColor: "#ECEFEA",
  },

  left: { width: 100, alignItems: "center" },
  imageWrap: {
    width: 72,
    height: 72,
    borderRadius: 12,
    
    overflow: "hidden",
    borderWidth: 0.5,
    borderColor: "#E6EAE8",
    backgroundColor: "#fff",
  },
  serviceImage: { width: "100%", height: "100%" },
  timePill: {
    marginTop: 8,
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 6,
    paddingVertical: 4,
    borderRadius: 12,
    backgroundColor: "#F3FBF8",
    borderWidth: 0.5,
    borderColor: "#E9F2EE",
    marginleft:10,
  },
  timeText: { marginLeft: 6, fontSize: 12, color: "#0B6E4F", fontWeight: "600" },

  middle: { flex: 1, paddingHorizontal: 12 },
  titleRow: { flexDirection: "row", justifyContent: "space-between", alignItems: "center" },
  titleText: { fontSize: 15, fontWeight: "700", color: "#163B33", maxWidth: width - 280 },
  statusPill: { paddingHorizontal: 8, paddingVertical: 4, borderRadius: 10 },
  statusText: { fontSize: 12, fontWeight: "700", color: "#0B6E4F" },

  smallText: { fontSize: 12, color: "#7D8B86", marginTop: 4 },

routeRow: {
  flexDirection: "row",
  alignItems: "center",
  justifyContent: "space-between",
  marginTop: 10,
},
point: {
  flexDirection: "row",
  alignItems: "center",
  gap: 5,
},
arrowBox: {
  width: 24,
  alignItems: "center",
  justifyContent: "center",
},
cityText: {
  fontSize: 14,
  color: "#111",
  fontWeight: "600",
},


  metaRow: { flexDirection: "row", marginTop: 10, alignItems: "center" },
  metaItem: { flexDirection: "row", alignItems: "center", marginRight: 14 },
  metaText: { marginLeft: 6, fontSize: 13, color: "#6B7C76" },

  right: { width: 72, alignItems: "center", justifyContent: "space-between", height: 72 },
  viewBtn: {
    backgroundColor: "#0B6E4F",
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 10,
  },
  viewBtnText: { color: "#fff", fontWeight: "700", fontSize: 13 },
  smallGrey: { fontSize: 11, color: "#9AA6A2" },

  // empty / skeleton
  empty: { alignItems: "center", paddingVertical: 40 },
  emptyImg: { width: 180, height: 140 },
  emptyText: { fontSize: 15, color: "#6B7C76", marginTop: 8, fontWeight: "700" },
  emptySub: { fontSize: 12, color: "#9AA6A2", marginTop: 6 },

  skelWrap: { flexDirection: "row", alignItems: "center", marginBottom: 12 },
  skelImage: { width: 72, height: 72, borderRadius: 10 },
  skelLine: { height: 14, borderRadius: 8, marginTop: 8 },
});
