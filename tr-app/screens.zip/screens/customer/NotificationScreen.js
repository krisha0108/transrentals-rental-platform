import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  ScrollView,
  StyleSheet,SafeAreaView,
  ActivityIndicator,
  Image, TouchableOpacity ,RefreshControl
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import axios from 'axios';
import ShimmerPlaceHolder from 'react-native-shimmer-placeholder';
// import moment from 'moment';
import Icon from 'react-native-vector-icons/Ionicons';
import Ionicons from 'react-native-vector-icons/Ionicons';
import notifee from '@notifee/react-native';
import api from '../api';

const NotificationScreen = () => {
  const [notifications, setNotifications] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
const navigation = useNavigation();
const fetchNotifications = async (isRefresh = false) => {
  if (!isRefresh) {
    setLoading(true);
  } else {
    setRefreshing(true);
  }

  try {
    const customerData = await AsyncStorage.getItem('customer');
    const customer = JSON.parse(customerData);
    const response = await api.get(`/customer-notifications/${customer.id}`);

    if (response.data.success) {
      setNotifications(response.data.notifications);
    }
  } catch (error) {
    console.error('Failed to load notifications:', error);
  } finally {
    if (!isRefresh) {
      setLoading(false);
    } else {
      setRefreshing(false);
    }
  }
};

  useEffect(() => {
    fetchNotifications();
    notifee.setBadgeCount(0);
  }, []);

 if (loading || refreshing) {
  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <Ionicons name="arrow-back" size={24} color="#404040" />
        </TouchableOpacity>
        <Text style={styles.headerText}>Notifications</Text>
      </View>

      <ScrollView contentContainerStyle={styles.notificationcontainer}>
        {[...Array(4)].map((_, index) => (
          <View key={index} style={styles.card}>
            <View style={styles.cardHeader}>
              <ShimmerPlaceHolder
                style={{ width: 20, height: 20, borderRadius: 10 }}
                autoRun
              />
              <ShimmerPlaceHolder
                style={{ marginLeft: 8, height: 20, flex: 1, borderRadius: 4 }}
                autoRun
              />
            </View>
            <ShimmerPlaceHolder
              style={{marginLeft: 4, height: 14,width: '100%', marginBottom: 8, borderRadius: 4 }}
              autoRun
            />
            <ShimmerPlaceHolder
              style={{ marginLeft: 4, height: 14,width: '100%', marginBottom: 8, borderRadius: 4  }}
              autoRun
            />
            <ShimmerPlaceHolder
              style={{ height: 160, marginLeft: 4,width: '100%', marginBottom: 8, borderRadius: 4  }}
              autoRun
            />
            <ShimmerPlaceHolder
              style={{ height: 12, width: 80, alignSelf: 'flex-end', borderRadius: 4 }}
              autoRun
            />
          </View>
        ))}
      </ScrollView>
    </SafeAreaView>
  );
}

  return (
      <SafeAreaView style={styles.container}>
       <View style={styles.header}>
                            <TouchableOpacity onPress={() => navigation.goBack()}>
                              <Ionicons name="arrow-back" size={24} color="#404040" />
                            </TouchableOpacity>
                            <Text style={styles.headerText}>Notifications</Text>
                          </View>
    <ScrollView refreshControl={
    <RefreshControl
      refreshing={refreshing}
      onRefresh={() => fetchNotifications(true)}
      tintColor="#007AFF"
    />
  }>
     
    
                  <View style={styles.notificationcontainer}>        
      {notifications.length === 0 ? (
        <Text style={styles.noData}>No notifications found</Text>
      ) : (
        notifications.map((item) => (
          <View key={item.id} style={styles.card}>
            <View style={styles.cardHeader}>
              <Icon name="notifications" size={20} color="#007AFF" />
              <Text style={styles.title}>{item.title}</Text>
            </View>
            <Text style={styles.body}>{item.body}</Text>
            {item.image && (
              <Image source={{ uri: item.image }} style={styles.image} resizeMode='contain' />
            )}
          
<Text style={styles.time}>{item.relative_time}</Text>
          </View>
        ))
      )}
      </View>
    </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  loaderContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  container: {
    paddingBottom: 32,
    height: '100%',
    backgroundColor: '#F9FAFB',
  },
  notificationcontainer: {
    padding: 16,
    backgroundColor: '#F9FAFB',
  },
   header: {
    height: 60,
    backgroundColor: '#F9F7F7',
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 20,
    marginBottom:10,
    elevation: 5,  // Adds shadow to the header
  },
  headerText: {
    color: '#404040',
    fontSize: 20,
    marginLeft: 10,  // Adjust space between back button and title
  },
  noData: {
    textAlign: 'center',
    fontSize: 16,
    color: '#6B7280',
  },
  card: {
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    shadowColor: '#000',
    shadowOpacity: 0.05,
    shadowOffset: { width: 0, height: 2 },
    shadowRadius: 4,
    elevation: 2,
  },
  cardHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 6,
  },
  title: {
    marginLeft: 8,
    fontSize: 16,
    fontWeight: '600',
    color: '#111827',
  },
  body: {
    fontSize: 14,
    color: '#374151',
    marginBottom: 6,
  },
  image: {
    width: '100%',
    height: 160,
    borderRadius: 8,
    marginBottom: 6,
  },
  time: {
    fontSize: 12,
    color: '#6B7280',
    textAlign: 'right',
  },
});

export default NotificationScreen;