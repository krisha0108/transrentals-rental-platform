import React from 'react';
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  TouchableOpacity,
  Linking,
} from 'react-native';
import {useNavigation} from '@react-navigation/native';
import Icon from 'react-native-vector-icons/Feather';

export default function AboutUsScreen() {
  const navigation = useNavigation();
  return (
    <ScrollView
      style={styles.container}
      contentContainerStyle={{paddingBottom: 20}}>
      <View style={styles.headerWrapper}>
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <Icon name="arrow-left" size={22} color="#404040" />
        </TouchableOpacity>
        <Text style={styles.pageTitle}>About US</Text>
      </View>

      <View style={styles.MainSec}>
        <View style={styles.ContentnSec}>
          <Text style={styles.titleText}>About US 2.0</Text>
          <Text style={styles.paragraph}>
            Started in 2015, we are a vehicle rental aggregator offering
            on-demand vehicle rental solutions to cater to all your vehicle
            requirements. Whether you are a corporate or ordinary individual, we
            serve all. We are here to deliver the best vehicle rental service
            possible. We know that the need for transportation is evolving day
            by day, so we travel the extra mile to help you get where you are
            going or transporting goods the best way possible—no matter what
            kind of vehicle you need or for how long.
          </Text>

          <Text style={styles.paragraph}>
            At TransRentals, we believe that transportation is an essential part
            of our life, whether passenger or goods transportation. We want to
            make this part of life more convenient and accessible so you can
            concentrate on more important things. We want to be the medium of
            your journey towards great things in life. Keep Moving, Keep Growing
          </Text>
        </View>

        <View style={styles.footer}>
          <View style={styles.divider} />
          <TouchableOpacity
            onPress={() =>
              Linking.openURL('https://transrentals.in/privacy-policy/')
            }>
            <Text style={styles.footerText}>Privacy Policy</Text>
          </TouchableOpacity>

          <View style={styles.divider} />
          <TouchableOpacity
            onPress={() =>
              Linking.openURL('https://transrentals.in/terms-and-condition/')
            }>
            <Text style={styles.footerText}>Terms & Condition</Text>
          </TouchableOpacity>
        </View>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'white',
  },

  headerText: {
    fontFamily: 'Manrope',
    fontWeight: '600',
    fontSize: 16,
    marginTop: 20,
    color: '#404040',
    paddingHorizontal: 20,
  },
  titleText: {
    fontFamily: 'Manrope',
    fontWeight: '500',
    fontSize: 18,
    marginTop: 10,
    color: '#404040',
    paddingHorizontal: 20,
  },
  paragraph: {
    fontFamily: 'Manrope',
    fontWeight: '500',
    fontSize: 16,
    lineHeight: 20,
    marginTop: 10,
    color: '#595D69',
    paddingHorizontal: 20,
  },
  footerText: {
    fontFamily: 'Manrope',
    fontWeight: '500',
    fontSize: 18,
    marginVertical: 10,
    color: 'rgba(0,0,0,0.8)',
    paddingHorizontal: 20,
  },
  divider: {
    height: 0.5,
    backgroundColor: 'rgba(0,0,0,0.2)',
  },

  pageTitle: {
    fontSize: 20,
    fontWeight: '600',
    color: '#404040',
  },
  headerWrapper: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    paddingHorizontal: 20,
    marginTop: 20,
    marginBottom: 10,
  },
  MainSec: {
    height: '100%',
    justifyContent: 'space-between',
  },
});
